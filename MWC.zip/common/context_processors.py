from django.conf import settings
import os

def global_settings(request):
    # return any necessary values
    global_setting_values = ''
    global_setting_values = {
        'INVOICE_SENT_STATUS': settings.INVOICE_SENT_STATUS,
        'INVOICE_PAID_STATUS': settings.INVOICE_PAID_STATUS,
        'INVOICE_CANCELLED_STATUS': settings.INVOICE_CANCELLED_STATUS,
        'CURRENCY_SYMBOL':settings.CURRENCY_SYMBOL
    }

    if settings.DEBUG:
        global_setting_values['ADDRESS_LOOKUP_API_KEY'] = settings.ADDRESS_LOOKUP_API_KEY
    else:
        global_setting_values['ADDRESS_LOOKUP_API_KEY'] = settings.ADDRESS_LOOKUP_API_KEY

    return global_setting_values