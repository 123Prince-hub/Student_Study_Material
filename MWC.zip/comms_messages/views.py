# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from celery.decorators import task
from braces.views import GroupRequiredMixin, JSONResponseMixin
import ast

import logging
import datetime
import os,re
import requests
import json
import phonenumbers
from django.conf import settings
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.postgres.aggregates import StringAgg
from django.core.mail import send_mail
from django.core import serializers
from django.core.exceptions import ObjectDoesNotExist
from django.db.models import (
    CharField, Value, Case,
    When, IntegerField, Q, F
)
from django.db.models.functions import Concat, Cast, Coalesce
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render, get_object_or_404
from django.urls import reverse, reverse_lazy
from django.utils.html import escape
from common.utilities import (
    current_site_url,
    get_user_franchise,get_user_franchise_id,
    get_all_franchisee_territory,
    create_message_before_celery
)
from django.views.decorators.csrf import csrf_exempt, csrf_protect
from django.views.generic import View
from django.views.generic import ListView, UpdateView

from accounts.models import Franchisor, User, WindowCleaner
from comms_messages.models import ManualMessageTemplate, Message, \
        SMS, Email, Contact
from customers.models import Customer, CommercialList
from franchises.models import Franchise
from jobs.models import Job
from office.tasks import *
from .forms import ManualMessageForm
from django.db import transaction, connection
from django.utils import timezone
from phonenumber_field.phonenumber import PhoneNumber
# Get an instance of a logger
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def send_test_sms(request):  # for testing purpose
    resp = send_sms.delay(settings.TEST_NUMBER, 'Hi from MWC test',
                    'C', receiver_id=None, franchisor_id='')
    return HttpResponse(resp)


def send_test_email(request):  # for testing purpose
    from office.tasks import send_email_mailgun
    to_emails = ['pguyard+mwc@gmail.com']

    response = send_email_mailgun.delay(
        'Mailgun test',
        'pguyard+mwc@gmail.com',
        to_emails,
        'C',
        receiver_id=None,
        franchise_id=None,
        html_body='<h1>mynew<a href="google.com">google</a></h1><img src="#">'
        )
    return HttpResponse(response)


@csrf_exempt
def message_bird_callback(request):
    
    try:
        uuid = request.POST.get('id', None)
        status = request.POST.get('status', None)
        statusErrorCode = request.POST.get('statusErrorCode', None)
        print("uuid: ", uuid)
        try:
            sms = SMS.objects.get(uuid=str(uuid))
        except ObjectDoesNotExist:
            print("MessageBird callback: SMS does not exist. uuid: ", uuid)      # staging/dev have the same callback url as production
            return HttpResponse(status=200)
        sms.status = status
        sms.message_bird_callback_response = request.POST.dict()
        if statusErrorCode is not None and statusErrorCode != '':
            error = {
                0: 'EC_NO_ERROR',
                1: 'EC_UNKNOWN_SUBSCRIBER',
                2: 'EC_UNKNOWN_BASE_STATION',
                3: 'EC_UNKOWN_MSC',
                5: 'EC_UNIDENTIFIED_SUBSCRIBER',
                7: 'EC_UNKNOWN_EQUIPMENT',
                8: 'EC_ROAMING_NOT_ALLOWED',
                9: 'EC_ILLEGAL_SUBSCRIBER',
                10: 'EC_BEARERSERVICE_NOT_PROVISIONED',
                11: 'EC_TELESERVICE_NOT_PROVISIONED',
                12: 'EC_ILLEGAL_EQUIPMENT',
                13: 'EC_CALL_BARRED',
                21: 'EC_FACILITY_NOT_SUPPORTED',
                26: 'EC_SUBSEQUENT_HANDOVER_FAILURE',
                27: 'EC_ABSENT_SUBSCRIBER',
                28: 'EC_ABSENT_SUBSCRIBER_NO_PAGE',
                29: 'EC_ABSENT_SUBSCRIBER_IMSI_DETACHED',
                30: 'EC_CONTROLLING_MSC_FAILURE',
                31: 'EC_SUBSCRIBER_BUSY_FOR_MT_SMS',
                32: 'EC_SM_DELIVERY_FAILURE',
                33: 'EC_MESSAGE_WAITING_LIST_FULL',
                34: 'ECSYSTEM_FAILURE1',
                35: 'ECDATA_MISSING1',
                36: 'ECUNEXPECTED_DATA_VALUE1',
                37: 'ECSYSTEM_FAILURE2',
                38: 'ECDATA_MISSING2',
                39: 'ECUNEXPECTED_DATA_VALUE2',
                40: 'ECUNEXPECTED_DATA_VALUE2',
                71: 'EC_UNKNOWN_ALPHABET',
                72: 'EC_USSD_BUSY',
                101: 'EC_SUBSCRIBER_INSUFFICIENT_BALANCE',
                103: 'EC_SUBSCRIBER_OPTEDOUT',
                104: 'EC_SENDER_UNREGISTERED',
                105: 'EC_CONTENT_UNREGISTERED',
                106: 'EC_CAMPAIGN_VOLUME_EXCEEDED',
                107: 'EC_CAMPAIGN_THROUGHPUT_EXCEEDED',
            }

            if int(statusErrorCode) in error and int(statusErrorCode) != 0:
                sms.error_code = error[int(statusErrorCode)]
                franchise=None
                customer=None
                try:
                    franchise=sms.message.franchise
                except:
                    pass
                try:
                    customer=sms.message.customer
                except:
                    pass
                body="<p><strong>An SMS message has failed</strong></p><p>The message was sent to {0} and the error code is {1}</p>".format(sms.to_number,sms.error_code)
                if franchise:
                    body+="<p>The franchise is {0}</p>".format(franchise.franchise)
                if customer:
                    body+="<p>The customer is {0}</p>".format(customer.address_line_1)
                send_email_mailgun.delay(
                    from_email='noreply@mywindowcleaner.co.uk',
                    to_emails=['pguyard+mwc@gmail.com','bookings@mywindowcleaner.co.uk'],
                    subject="New failed SMS message Alert",
                    html_body=body,
                    receiver_type='',
                    receiver_id=None
                )                  
                
        sms.save()
    except Exception as e:
        print('error in message_bird_callback: ', str(e))        
    return HttpResponse(status=200)


@csrf_exempt
def receiving_message_bird_callback(request):

    uuid = request.GET.get('id', None)
    recipient = request.GET.get('recipient', None)
    sms_originator = request.GET.get('originator', None)
    created_datetime = request.GET.get('createdDatetime', None)
    body = request.GET.get('body', None)

    originator = '+'+str(sms_originator)
    recipient = '+'+str(recipient)

    try:
        franchise = Franchise.objects.get(phone_number=recipient)
    except Franchise.DoesNotExist:
        franchise = None

    if franchise:
        franchise_id = franchise.id
    else:
        franchise_id = None

    try:
        franchisor = Franchisor.objects.get(
            Q(user__mobile_phone=originator) |
            Q(user__home_phone=originator)
        )
    except Franchisor.DoesNotExist:
        franchisor = None

    if franchisor:
        franchisor_id = franchisor.id
    else:
        franchisor_id = None

    try:
        customer_det = Customer.objects.filter(
            Q(mobile_phone=originator) |
            Q(home_phone=originator) | 
            Q(work_phone=originator)
        ).first()
        if customer_det:
            if franchise is not None and franchise == customer_det.booking_road.area.franchise:
                customer = customer_det
            else:
                customer = None            
        else:
            customer = None
    except Customer.DoesNotExist:
        customer = None

    try:
        contact_det = Contact.objects.filter(
            Q(mobile_phone=originator) |
            Q(home_phone=originator)
        )[:1]
        if contact_det:
            contact = contact_det[0]
        else:
            contact = None
    except Contact.DoesNotExist:
        contact = None

    try:
        user_det = User.objects.filter(
            Q(mobile_phone=originator) |
            Q(home_phone=originator)
        )[:1]
        if user_det:
            user = user_det[0]
        else:
            user = None
    except User.DoesNotExist:
        user = None

    with transaction.atomic():

        try:
            new_message = Message(
                outgoing=False,
                sent_time=created_datetime,
                received_time=timezone.now(),
                message_type=Message.SMS_MESSAGE,
                franchise_id=franchise_id,
                franchisor_id=franchisor_id
            )

            if customer:
                new_message.customer_id = customer.id
            elif contact:
                new_message.contact_id = contact.id
            elif user:
                new_message.user_id = user.id

            new_message.save()

            sms = SMS(
                message=new_message,
                to_number=recipient,
                message_text=body,
                status=SMS.DELIVERED,
                uuid=uuid
            )

            
            try:
                number = PhoneNumber.from_string(originator)
                sms.from_number=originator
            except:
                sms.from_text=str(sms_originator)
            sms.save()

        except Exception as e:
            print('Error in receiving_message_bird_callback {0}'.format(e))
            pass

    return HttpResponse('received sms')


@csrf_exempt
def change_status_sent_email(request):
    if request.content_type == "application/json":
        event = json.loads(request.body.decode('utf-8'))
        ChangeStatusSentEmail.delay(event)

    return HttpResponse('status changed')


@csrf_exempt
def mailgun_incoming_mail(request):
    if request.method == 'POST':
        try:
            recipient = request.POST.get('recipient')
            sender = request.POST.get('sender')
            from_email = request.POST.get('from')
            subject = request.POST.get('subject', '')
            body_plain = request.POST.get('body-plain', '')
            stripped_text = request.POST.get('stripped-text', '')
            stripped_signature = request.POST.get('stripped-signature', '')
            body_html = request.POST.get('body-html', '')
            stripped_html = request.POST.get('stripped-html', '')
            attachment_count = request.POST.get('attachment-count')
            attachment_x = request.POST.get('attachment-x')
            timestamp = request.POST.get('timestamp')
            token = request.POST.get('token')
            signature = request.POST.get('signature', '')
            message_headers = request.POST.get('message-headers')
            content_id_map = request.POST.get('content-id-map')
            mailgun_id = request.POST.get('Message-Id', '')
            in_reply_to_mailgun_id = request.POST.get('In-Reply-To', '')

            if mailgun_id != '':
                mailgun_id = mailgun_id.replace("<", "")
                mailgun_id = mailgun_id.replace(">", "")

            if in_reply_to_mailgun_id != '':
                in_reply_to_mailgun_id = in_reply_to_mailgun_id.replace("<", "")
                in_reply_to_mailgun_id = in_reply_to_mailgun_id.replace(">", "")

            print('Mailgun Incoming Email Hooks Called!')

            try:
                franchise = Franchise.objects.get(email=recipient)
            except Franchise.DoesNotExist:
                franchise = None

            if franchise:
                franchise_id = franchise.id
            else:
                franchise_id = None

            try:
                franchisor = Franchisor.objects.get(user__email=recipient)
            except Franchisor.DoesNotExist:
                franchisor = None

            if franchisor:
                franchisor_id = franchisor.id
            else:
                franchisor_id = None

            try:
                customer_det = Customer.objects.filter(
                    Q(email=sender) |
                    Q(cc_email=sender)
                ).first()
                if customer_det:
                    if franchise is not None and franchise != customer_det.booking_road.area.franchise:
                        customer = None
                    else:
                        customer = customer_det
                else:
                    customer = None
            except Customer.DoesNotExist:
                customer = None

            try:
                contact_det = Contact.objects.filter(email=sender)[:1]
                if contact_det:
                    contact = contact_det[0]
                else:
                    contact = None
            except Contact.DoesNotExist:
                contact = None

            try:
                user_det = User.objects.filter(email=sender)[:1]
                if user_det:
                    user = user_det[0]
                else:
                    user = None
            except User.DoesNotExist:
                user = None

            try:
                commercial_list_det = CommercialList.objects.filter(email=sender)[
                    :1]
                if commercial_list_det:
                    commercial_list = commercial_list_det[0]
                else:
                    commercial_list = None
            except CommercialList.DoesNotExist:
                commercial_list = None

            new_message = Message(
                outgoing=False,
                received_time=timezone.now(),
                message_type=Message.EMAIL_MESSAGE,
                franchise_id=franchise_id,
                franchisor_id=franchisor_id
            )

            if customer:
                new_message.customer_id = customer.id
            elif contact:
                new_message.contact_id = contact.id
            elif user:
                new_message.user_id = user.id
            elif commercial_list:
                new_message.commercial_list = commercial_list.id

            new_message.save()
            last_insert_msg_id = new_message.id

            files = []
            # attachments:
            for key in request.FILES:
                files.append(request.FILES[key])

            new_email = Email(
                message=new_message,
                recipients=[recipient],
                subject=subject,
                sender=sender,
                mailgun_id=mailgun_id,
                mailgun_message_status=Email.ACCEPTED,
                attachments=files,
                body_plain=body_plain,
                body_html=body_html,
                stripped_text=stripped_text,
                stripped_signature=stripped_signature,
                in_reply_to_mailgun_id=in_reply_to_mailgun_id,
            )
            new_email.save()

            return HttpResponse('Saved incoming email')

        except Exception as error:
            print('EMail Saved Error---', str(error))
            pass


@csrf_exempt
def type_of_email_templates(request):

    type_of_email = request.POST.get('type_of_email')
    message_type = request.POST.get('message_type')
    franchise_id = get_user_franchise_id(request.user, request)

    try:
        if request.method == 'POST' and request.is_ajax():
            if message_type == '1':
                column_name = 'email_template'
                qs = ManualMessageTemplate.objects.filter(message_type=1).values(
                    'id', 'title', 'subject', 'email_template').order_by('order')
            elif message_type == '2':
                column_name = 'sms_template'
                qs = ManualMessageTemplate.objects.filter(message_type=1).values(
                    'id', 'title', 'subject', 'sms_template').order_by('order')
            else:
                pass

            qs = qs.filter(type_of_email__exact=type_of_email)
            qs = qs.filter(Q(franchise__id=franchise_id) | Q(franchise__isnull=True))

            return JsonResponse({
                'result': list(qs),
                'column_name': column_name
            })
    except Exception as e:
        print('Error in type_of_email_templates:', str(e))
        pass

@csrf_exempt
def get_templates_by_category(request):

    category_id = request.POST.get('category_id')
    message_type = request.POST.get('message_type')
    franchise_id = get_user_franchise_id(request.user, request)

    try:
        if request.method == 'POST' and request.is_ajax():
            if message_type == '1':
                column_name = 'email_template'
                qs = ManualMessageTemplate.objects.filter(message_type=1).values(
                    'id', 'title', 'subject', 'email_template').order_by('order')
            elif message_type == '2':
                column_name = 'sms_template'
                qs = ManualMessageTemplate.objects.filter(message_type=1).values(
                    'id', 'title', 'subject', 'sms_template').order_by('order')
            else:
                pass

            qs = qs.filter(type_of_email__exact=13)
            if category_id != 'all':
                qs = qs.filter(manual_message_template_category__id=category_id)

            qs = qs.filter(Q(franchise__id=franchise_id) | Q(franchise__isnull=True))

            return JsonResponse({
                'result': list(qs),
                'column_name': column_name
            })
    except Exception as e:
        print('Error in type_of_email_templates:', str(e))
        pass

@csrf_exempt
def manual_message_templates(request):
    message_type_ = request.POST.get('message_type')
    customer_id_ = request.POST.get('customer_id')
    user_type_ = request.POST.get('user_type')

    # For Filtering display only manual message category tempaltes
    is_show_manual_msg = request.POST.get('is_show_manual_msg', None)

    # For Filtering display only BTD category tempaltes
    is_show_btd_templates = request.POST.get('is_show_btd_templates', None)

    # FOR FILTERING WC_ID REQUIRED
    wc_id = request.POST.get('window_cleaner_id', None)
    template_data = request.POST.get('template_data')
    template_subject = request.POST.get('template_subject')
    qs = ''
    template_selected_val = request.POST.get('template_selected_val')
    franchise = get_user_franchise(request.user, request)

    def wc_finder(_customer_id):
        customer_job_qs = Job.objects.filter(
            customer_id=_customer_id,
        ).select_related(
            'customer',
            'window_cleaner',
        ).annotate(
            job_id=F('id'),
            job_window_cleaner_booking_road=Concat(
                'customer__booking_road__area__default_cleaner__user__first_name',
                Value(' '),
                'customer__booking_road__area__default_cleaner__user__last_name'),
            job_window_cleaner_id2=F(
                'customer__booking_road__area__default_cleaner_id'),
            job_window_cleaner_status=F(
                'customer__booking_road__area__default_cleaner__user__is_active'),
            job_due_date=F('due_date'),
            wc_bt_default=Concat(
                'customer__bank_transfer_to_default__user__first_name',
                Value(' '),
                'customer__bank_transfer_to_default__user__last_name'
            ),
            wc_bt_default_id=F(
                'customer__bank_transfer_to_default_id'),
            wc_bt_default_status=F(
                'customer__bank_transfer_to_default__user__is_active'),
            wc_bt_job=Concat(
                'bank_transfer_to__user__first_name',
                Value(' '),
                'bank_transfer_to__user__last_name'
            ),
            wc_bt_job_id=F('bank_transfer_to_id'),
            wc_bt_job_status=F('bank_transfer_to__user__is_active'),

        ).order_by(
            'job_due_date'
        ).last()
        return customer_job_qs

    def get_template_data(template_id, user_name, customer='', wc_ob=''):

        templateData = ManualMessageTemplate.objects.values(
            'subject', 'sms_template', 'email_template'
        ).get(id=template_id)

        if templateData is not None:
            if wc_ob != '':
                wc_name = str(wc_ob['user__first_name']) + ' ' + str(wc_ob['user__last_name'])
                wc_acc_no = wc_ob['user__bank_account_number']
                wc_sort_code = wc_ob['user__bank_account_sort_code']
                wc_bank_name = wc_ob['user__bank_name']
                wc_account_holder_name = wc_ob['user__bank_account_holder_name']
                wc_bank_account_notes = wc_ob['user__bank_account_notes']
                templateData['subject'] = templateData['subject'].replace(r'{{WC name}}', wc_name or '')
                templateData['email_template'] = templateData['email_template'].replace(r'{{WC name}}', wc_name or '')
                templateData['email_template'] = templateData['email_template'].replace (r'{{user account number}}', wc_acc_no or '')
                templateData['email_template'] = templateData['email_template'].replace(r'{{user sort code}}', wc_sort_code or '')            
                templateData['email_template'] = templateData['email_template'].replace(r'{{bank name}}', wc_bank_name or '')
                templateData['email_template'] = templateData['email_template'].replace(r'{{bank account holder name}}', wc_account_holder_name or '')
                templateData['email_template'] = templateData['email_template'].replace(r'{{user account notes}}', wc_bank_account_notes or '')
                templateData['email_template'] = templateData['email_template'].replace(r'{{user}}', user_name or '')

                templateData['sms_template'] = templateData['sms_template'].replace(r'{{WC name}}', wc_name or '')
                templateData['sms_template'] = templateData['sms_template'].replace (r'{{user account number}}', wc_acc_no or '')
                templateData['sms_template'] = templateData['sms_template'].replace(r'{{user sort code}}', wc_sort_code or '')            
                templateData['sms_template'] = templateData['sms_template'].replace(r'{{bank name}}', wc_bank_name or '')
                templateData['sms_template'] = templateData['sms_template'].replace(r'{{bank account holder name}}', wc_account_holder_name or '')
                templateData['sms_template'] = templateData['sms_template'].replace(r'{{user account notes}}', wc_bank_account_notes or '')
                templateData['sms_template'] = templateData['sms_template'].replace(r'{{user}}', user_name or '')

            templateData['email_template'] = templateData['email_template'].replace(r'{{franchise_email}}', franchise.email or 'no-reply@mywindowcleaner.co.uk')
            templateData['email_template'] = templateData['email_template'].replace(r'{{franchise_website}}', franchise.web_address or '')
            templateData['email_template'] = templateData['email_template'].replace(r'{{franchise_landline}}', str(franchise.landline) or '')
            templateData['email_template'] = templateData['email_template'].replace(r'{{franchises}}', get_all_franchisee_territory() or '')
            
            if customer != '':
                frequency = customer_details.frequency.frequency_choice
                frequency = str(frequency)
                if frequency != '' and frequency is not None:
                    if frequency == '-1':
                        frequency = 'not sure'
                    elif int(frequency) == 1:
                        frequency = 'once a week'
                    elif int(frequency) == 0:
                        frequency = 'as a one off'
                    else:
                        frequency ='every %s weeks' % str(int(frequency))
                templateData['email_template'] = templateData['email_template'].replace(r'{{customer_email}}', customer_details.email or '')
                templateData['email_template'] = templateData['email_template'].replace(r'{{frequency}}', frequency or '')
            else:
                templateData['email_template'] = templateData['email_template'].replace(r'{{customer_email}}', '')

            templateData['sms_template'] = templateData['sms_template'].replace(r'{{franchise_email}}', franchise.email or 'no-reply@mywindowcleaner.co.uk')
            templateData['sms_template'] = templateData['sms_template'].replace(r'{{franchise_website}}', franchise.web_address or '')
            templateData['sms_template'] = templateData['sms_template'].replace(r'{{franchise_landline}}', str(franchise.landline) or '')
            templateData['sms_template'] = templateData['sms_template'].replace(r'{{franchises}}', get_all_franchisee_territory() or '')
            if customer != '':
                templateData['sms_template'] = templateData['sms_template'].replace(r'{{customer_email}}', customer_details.email or '')
            else:
                templateData['email_template'] = templateData['email_template'].replace(r'{{customer_email}}', '')
            
            templateData['email_template'] = templateData['email_template'].replace("{{user}}",user_name or '')
            templateData['sms_template'] = templateData['sms_template'].replace("{{user}}",user_name or '')

            return templateData

    single_WC = False
    wc_list = []
    total_WC = 0
    try:
        if franchise.first_name_in_messages and franchise.sign_off_my_window_cleaner:
            user_name = 'My Window Cleaner'
        else:
            if franchise.first_name_in_messages:
                user_name = request.user.first_name
            else:
                user_name = request.user.first_name + ' ' + request.user.last_name        
    except AttributeError:
        user_name = ''
    
    try:
        if wc_id is not None and wc_id != '' and wc_id != '0':
            if template_selected_val:
                try:
                    wc_ob = WindowCleaner.objects.select_related(
                        'user'
                        ).filter(
                            id=wc_id
                        ).values(
                            'user__first_name',
                            'user__last_name',
                            'user__bank_account_number',
                            'user__bank_account_sort_code',
                            'user__bank_name',
                            'user__bank_account_holder_name',
                            'user__bank_account_notes'
                        ).first()
                except Exception as e:
                    print("""An exception has occured trying to fetch a WC on BTD template.
                        Message is """, str(e))
                    wc_ob = ''
                customer_details=''
                if user_type_ == 'customer' and customer_id_:
                    customer_details = Customer.objects.get(id=customer_id_)
                templateData = get_template_data(int(template_selected_val),user_name,wc_ob=wc_ob,customer=customer_details)

                return JsonResponse({'msg': 'valid', 'template_data': templateData })
            else:
                return JsonResponse({'msg': 'invalid data'})

        elif user_type_ == 'customer' and customer_id_:
            customer_details = Customer.objects.get(id=customer_id_)
            wc_list = WindowCleaner.objects.filter(
                user__is_active=1, user__groups__name='window_cleaner', franchise=franchise
            ).annotate(
                wc_name=Concat(
                    'user__first_name', Value(' '), 'user__last_name'
                )
            ).values(
                'id', 'wc_name'
            )

            if template_selected_val:
                templateData = get_template_data(int(template_selected_val),user_name,customer=customer_details)
                return JsonResponse({'msg': 'valid', 'template_data': templateData })

        else:
            if template_selected_val:
                templateData = get_template_data(int(template_selected_val), user_name)
                return JsonResponse({'msg': 'valid', 'template_data': templateData })
            
        column_name = ''

        if request.method == 'POST':
            qs = ManualMessageTemplate.objects.filter(message_type=1).values(
                    'id', 'title', 'subject', 'sms_template').order_by('order')

            qs = qs.filter(Q(franchise=franchise) | Q(franchise__isnull=True))

            # For Filtering display only manual message category tempaltes
            if is_show_manual_msg != '' and is_show_manual_msg == 'true':
                qs = qs.filter(type_of_email__exact=13).exclude(id=17)

            print('is_show_btd_templates===', is_show_btd_templates)
            # For Filtering display only BTD category tempaltes
            if is_show_btd_templates != '' and is_show_btd_templates == 'true':
                qs = qs.filter(type_of_email__exact=17)
    
        return JsonResponse({
            'result': list(qs),
            'column_name': column_name,
            'total_WC': total_WC,
            'single_WC': single_WC,
            'wc_list': list(wc_list)
        })

    except Exception as e:
        print('error in manual_message_templates: ', str(e))
        pass


@csrf_exempt
def terms_conditions_templates(request):

    if request.method == 'POST' and request.is_ajax():

        user_name = request.user.first_name + ' ' + request.user.last_name
        message_type = request.POST.get('message_type')
        template_selected_val = request.POST.get('template_selected_val')
        response_dict = {}

        franchise_id = get_user_franchise_id(request.user, request)

        def get_template_data(template_id):
            return ManualMessageTemplate.objects.filter(id=template_id).first()

        if template_selected_val:
            new_template_data = get_template_data(int(template_selected_val))
            response_dict['message_type'] = message_type
            response_dict['template_subject'] = new_template_data.subject
            if message_type == '1':
                response_dict['template_data'] = new_template_data.email_template

            elif message_type == '2':
                response_dict['template_data'] = new_template_data.sms_template
            
            if response_dict['template_data'] is not None:
                response_dict['template_data'] = response_dict['template_data'].replace(r'{{user}}', user_name)
                
            return JsonResponse(response_dict)

        if request.method == 'POST':
            if message_type == '1':
                qs = ManualMessageTemplate.objects.filter(
                    Q(franchise__id=franchise_id) | Q(franchise__isnull=True),
                    type_of_email=12,
                    message_type=1
                ).values(
                    'id', 'title', 'subject', 'email_template'
                ).order_by('order')
                response_dict['result'] = list(qs)
                response_dict['column_name'] = 'email_template'
            elif message_type == '2':
                qs = ManualMessageTemplate.objects.filter(
                    Q(franchise__id=franchise_id) | Q(franchise__isnull=True),
                    type_of_email=12,
                    message_type=1
                ).values(
                    'id', 'title', 'subject', 'sms_template'
                ).order_by('order')
                qs.filter(Q(franchise__id=franchise_id) | Q(franchise__isnull=True))
                response_dict['result'] = list(qs)
                response_dict['column_name'] = 'sms_template'
            else:
                pass

        return JsonResponse(response_dict)


def send_tnc_email_or_sms(request):

    from office.tasks import send_email_mailgun
    user = request.user
    franchise = get_user_franchise(user, request)
    latest_job = wc_name = ''
    email_regex = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    if request.method == 'POST' and request.is_ajax():

        user_id = request.POST.get('user_id', '')
        contact_id = request.POST.get('contact_id', '')
        customer_id = request.POST.get('customer_id', '')
        user_type = request.POST.get('user_type', '')
        wc_name = request.POST.get('WC_name', '')
        tnc_new_customer_id = request.POST.get('tnc_new_customer_id', '')
        try:
            if request.POST.get('message_type') == 'email':
                receiver_type = customer = receiver_id = address = wc = wc_bank_details = job = single_WC = current_wc = wc_list = ''
                if user_id != '':
                    receiver_type = 'U'
                    receiver_id = user_id
                elif contact_id != '':
                    receiver_type = 'CO'
                    receiver_id = contact_id
                elif customer_id != '':
                    receiver_type = 'C'
                    receiver_id = customer_id
                else:
                    receiver_type = customer = receiver_id = address = wc = wc_bank_details = job = single_WC = current_wc = wc_list = ''
                    # print('else',request.POST.get('user_type'))
                    # return JsonResponse({'data':'compose message part under development'})
                user_name = request.user.first_name + ' ' + request.user.last_name
                from_email = franchise.email or 'no-reply@mywindowcleaner.co.uk'
                to_emails = request.POST.get('email').split(',')
                subject = request.POST.get('subject')
                html_content = request.POST.get('message_email')
                # html_content = html_content + '\n' + user_name
                cc_mail = request.POST.get('ccemail')

                to_email_list = json.loads(request.POST.get('email_JSON', ''))
                ccemail_list = json.loads(request.POST.get('ccemail_JSON', ''))
                bccemail_list = json.loads(request.POST.get('bccemail_JSON', ''))

                is_email_valid_or_not = is_cc_email_valid_or_not = True
                if len(to_email_list) > 0:
                    for to_email in to_email_list:
                        if(not re.search(email_regex,to_email)):
                            is_email_valid_or_not = False

                if len(ccemail_list) > 0:
                    for cc_email in ccemail_list:
                        if(not re.search(email_regex,cc_email)):
                            is_cc_email_valid_or_not = False
                                    
                if not is_email_valid_or_not or not is_cc_email_valid_or_not:
                    return JsonResponse({
                        'flag':'error',
                        'data':'Looks like email address is not valid!',
                    })

                args = {}
                attachments = []
                if franchise.t_and_c_attachment_file != '' and franchise.t_and_c_attachment_file is not None:
                    attachments.append(franchise.t_and_c_attachment_file.name)
                args['attachments'] = attachments
                if ccemail_list:
                    args['cc'] = ccemail_list
                if bccemail_list:
                    args['bcc'] = bccemail_list
                current_site_url_str = current_site_url(request)
                # print(request.POST)

                if customer_id != '':
                    customer_query_set = Customer.objects.get(id=customer_id)
                    if customer_query_set.told_terms_conditions == False:
                        customer_query_set.told_terms_conditions = True
                        customer_query_set.save()                    
                
                if html_content != '' and html_content is not None:
                    send_email_mailgun.delay(
                        subject, from_email, to_email_list,
                        receiver_type, receiver_id=receiver_id,
                        franchise_id=franchise.id, current_site=current_site_url_str,
                        html_body=html_content, args=args,
                        new_customer_id=tnc_new_customer_id
                    )
                    return JsonResponse({
                        'flag': 'success', 'data': 'Email has been sent successfully!'
                    })
                else:
                    return JsonResponse({
                        'flag': 'success', 'data': 'It seems there are email or SMS content is blank. Please check!'
                    })

            elif request.POST.get('message_type') == 'sms':
                receiver_type = customer = receiver_id = ''
                to_number = request.POST.get('mobile')
                message = request.POST.get('message_sms')
                if user_id != '':
                    receiver_type = 'U'
                    receiver_id = user_id
                elif contact_id != '':
                    receiver_type = 'CO'
                    receiver_id = contact_id
                elif customer_id != '':
                    receiver_type = 'C'
                    receiver_id = customer_id
                else:
                    print('else', request.POST.get('user_type'))
                    # return JsonResponse({'data':'unknown user_id'})

                is_to_number_valid_or_not = True
                try:
                    to_number_valid = phonenumbers.parse(to_number, "GB")
                    if not phonenumbers.is_valid_number(to_number_valid):
                        is_to_number_valid_or_not = False
                except Exception as e:
                    print('Number Error', str(e))
                    is_to_number_valid_or_not = False

                if not is_to_number_valid_or_not:
                    return JsonResponse({
                        'flag':'error',
                        'data':'Looks like phone number is not valid!',
                    })

                user_name = request.user.first_name + ' ' + request.user.last_name
                # message = message.replace("{{User}}",user_name)
                message = message + ' ' + user_name
                """ print(to_number, message, receiver_type, receiver_id)
                return False """
                current_site_url_str = current_site_url(request)

                if message != '' and message is not None:
                    send_sms.delay(
                        to_number, message, receiver_type,
                        receiver_id, franchise_id=franchise.id,
                        franchisor_id='', current_site=current_site_url_str,
                        new_customer_id=tnc_new_customer_id
                    )                    
                    return JsonResponse({
                        'flag': 'success',
                        'data': 'SMS has been sent successfully!'
                    })
                else:
                    return JsonResponse({
                        'flag': 'success', 'data': 'It seems there are email or SMS content is blank. Please check!'
                    })
            
            elif request.POST.get('message_type') == 'tnc_previously_sent':

                previous_cust_address = request.POST.get('previous_cust_address')
                told_tnc_notes = request.POST.get('told_tnc_notes')
                customer = Customer.objects.get(id=int(customer_id))
                customer.told_terms_conditions_previous_address = None
                if previous_cust_address is not None:
                    customer.told_terms_conditions_previous_address_id = previous_cust_address
                customer.told_terms_conditions_notes = told_tnc_notes
                customer.save()

                return JsonResponse({
                    'flag': 'success',
                    'data': 'SMS has been sent successfully!'
                })


        except Exception as e:
            return JsonResponse(
                {'flag': 'error', 'data': str(e)}
            )
    else:
        return JsonResponse({'flag': 'error', 'data': 'not ajax'})


class UpdateMessageNotesAjax(
    JSONResponseMixin,
    GroupRequiredMixin,
    LoginRequiredMixin,
    View
        ):

    group_required = [
        u'franchisee',
        u'franchise_admin', 
        u'franchisor',
        u'customer_care'
        ]

    def post(self, request, *args, **kwargs):
        try:
            message_id = request.POST.get('message_id', None)
            message_notes = request.POST.get('message_notes', '')
            message = Message.objects.get(pk=message_id)
            message.message_notes = message_notes
            message.save()
            json_dict = {
                'message': "Notes have been updated.",
                'result': "success"
            }
        except ObjectDoesNotExist:
            json_dict = {
                    'message': "Error: This message cannot be found.",
                    'result': "failure"
                }
        return self.render_json_response(json_dict)

class UpdateFranchiseNotesAjax(
    JSONResponseMixin,
    GroupRequiredMixin,
    LoginRequiredMixin,
    View
        ):

    group_required = [
        u'franchisee',
        u'franchise_admin', 
        u'franchisor',
        u'customer_care'
        ]

    def post(self, request, *args, **kwargs):
        user = request.user
        franchise_id = get_user_franchise_id(user, request)

        try:
            inbox_notes = request.POST.get('inbox_notes', '')
            franchise = Franchise.objects.get(pk=franchise_id)
            franchise.inbox_notes = inbox_notes
            franchise.save()
            json_dict = {
                'message': "Notes have been updated.",
                'result': "success"
            }
        except ObjectDoesNotExist:
            json_dict = {
                    'message': "Error: This message cannot be found.",
                    'result': "failure"
                }
        return self.render_json_response(json_dict)

class ListManualTemplates(LoginRequiredMixin, ListView):
    model = ManualMessageTemplate
    paginate_by: 20
    template_name = 'manualmessagetemplate_list.html'
    context_object_name = 'templates'
    queryset = ManualMessageTemplate.objects.filter(
        checked=False,
        # type_of_email=13,
        message_type=1
    )

    def get_context_data(self, **kwargs):
        context = super(ListManualTemplates, self).get_context_data(**kwargs)
        context['types'] = ManualMessageTemplate.TYPE_OF_EMAIL_CHOICES
        return context


class EditManualMessage(LoginRequiredMixin, UpdateView):
    model = ManualMessageTemplate
    form_class = ManualMessageForm
    template_name = 'manualmessagetemplate_edit.html'
    success_url = reverse_lazy('manual_message_templates_list')

    def form_valid(self, form):
        return super(EditManualMessage, self).form_valid(form)

    def form_invalid(self, form):
        return super(EditManualMessage, self).form_invalid(form)


class CustomerMessages(ListView):
    template_name = 'customer_messages.html'
    context_object_name = 'messages'
    model = Message
    paginate_by = 5

    def get_queryset(self):        
        customer = self.kwargs['customer']
        messages = Message.objects.filter(
            customer=customer
                ).select_related(
                    'email',
                    'sms',
                    'customer'
                    ).annotate(
                    order_time=Coalesce(F('sent_time'),
                                        F('received_time')
                                )
                    ).order_by('-order_time')
        if 'show' in self.request.GET and self.request.GET['show'] == 'all':
            self.paginate_by = messages.count()

        return messages
