from django.urls import path
from . import views
from django.contrib.auth import views as auth_view

urlpatterns = [
    path('', views.home, name='home'),

    #  ****************************  User Registration Urls  ********************************
    path('UserRegister/', views.UserRegister, name='UserRegister'),

    #  ****************************  User Login Urls  ********************************
    path('UserLogin/', auth_view.LoginView.as_view(template_name="dashboard/login.html"), name='UserLogin'),

    #  ****************************  User Logout Urls  ********************************
    path('UserLogout/', auth_view.LogoutView.as_view(template_name="dashboard/logout.html"), name='UserLogout'),

    #  ****************************  User Profile Urls  ********************************
    path('profile/', views.profile, name='profile'),

    #  ****************************  Notes Urls  ********************************
    path('notes/', views.notes, name='notes'),
    path('delete_note/<int:pk>/', views.delete_note, name='delete_note'),
    path('note_detail/<int:pk>/', views.NotesDetailView.as_view(), name='note_detaill'),

    #  ****************************  Homeworks Urls  ********************************
    path('homework/', views.homework, name='homework'),
    path('delete_homework/<int:pk>/', views.delete_homework, name='delete_homework'),
    path('update_homework/<int:pk>/', views.update_homework, name='update_homework'),

    #  ****************************  Youtube Urls  ********************************
    path('youtube/', views.youtube, name='youtube'),

    #  ****************************  Todo Urls  ********************************
    path('todo/', views.todo, name='todo'),
    path('update_todo/<int:pk>/', views.update_todo, name='update_todo'),
    path('delete_todo/<int:pk>/', views.delete_todo, name='delete_todo'),

    #  ****************************  Books Urls  ********************************
    path('books/', views.books, name='books'),

    #  ****************************  Dictionary Urls  ********************************
    path('dictionary/', views.dictionary, name='dictionary'),

    #  ****************************  Wikipedia Urls  ********************************
    path('wiki/', views.wiki, name='wiki'),

    #  ****************************  Conversion Urls  ********************************
    path('conversion/', views.conversion, name='conversion'),
]