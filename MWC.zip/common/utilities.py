import datetime
from operator import truediv
import boto3
from botocore.exceptions import ClientError
import csv, json
from datetime import timedelta
import decimal
from html import unescape
from loremipsum import get_sentences
import pytz
import re
from random import randint, random, randrange
import requests
import copy

from django.conf import settings
from django.core.files.base import ContentFile
from django.db import models, connection
from django.db.models import Q
from django.db.models.aggregates import Count
from django.contrib.auth.models import Group
from django.contrib.humanize.templatetags.humanize import intcomma
from django.utils import formats, timezone
from django.utils.html import strip_tags, mark_safe

from accounts.models import WindowCleaner, User
from accounts.models import Franchisor
from franchises.models import Setting
from franchises.models import FranchiseVatRate
from comms_messages.models import Message, SMS, Email, Contact, CommercialList
from customers.models import (
    Customer, BusinessSource, BookWithChoice,
    PropertyType, FrequencyChoice, DefaultTimeSlot, AlternateTimeSlot
)
from franchises.models import Franchise
from jobs.models import (
    CleaningMethod,
    JobTask, AccessMethod, JobStatus, MoneyType, Job,
    PaymentStatus, TimeSlot
)
from office.models import BankHolidays

def currency_short(amount):
    """ doesn't return decimal if .00 """    
    if (amount is not None and amount != ''):
        val = decimal.Decimal(amount.replace(",",""))
        if val//1==val/1: # .00
            return "{:f}".format(val)
        else:
            return "{:.2f}".format(val)
    else:
        return amount


def currency_short_with_negative(amount):
    """ simple tag to return GBP currency - doesn't support localization """

    # TODO: Temporary fix on staging but this is waiting for a push so can remove amount != 'None' at next push to production
    if amount != 'None' and (isinstance(amount, str) == True or amount is not None):
        amount = round(float(amount), 2)
    else:
        return "£0"

    if amount < 0.0:
        amount_with_leading_zero = "-£%s%s" % (intcomma(int(abs(amount))), ("%0.2f" % amount)[-3:])
        return amount_with_leading_zero.rstrip('0').rstrip('.')
    else:
        amount_with_leading_zero = "£%s%s" % (intcomma(int(amount)), ("%0.2f" % amount)[-3:])
        return amount_with_leading_zero.rstrip('0').rstrip('.')


def get_sec(time_str):
    h, m, s = str(time_str).split(':')
    return int(h) * 3600 + int(m) * 60 + int(s)


def convert_time_to_hours_minute(number):
    total_seconds = number
    intervals = (
        ('h', 3600),    # 60 * 60
        ('m', 60),
    )
    result = []
    for name, count in intervals:
        value = int(total_seconds // count)
        if value:
            total_seconds -= value * count
            if value == 1:
                name = name.rstrip('s')
            result.append("{}{}".format(value, name))
    return ''.join(result[:2])


def get_user_franchise(user, request):

    if 'user_franchise_id' in request.session and request.session['user_franchise_id'] is not None:
        franchise = Franchise.objects.get(pk=request.session['user_franchise_id'])
        return franchise
    else:
        try:
            request.session['user_franchise_id'] = user.franchisee.franchise.id
            return user.franchisee.franchise
        except AttributeError:
            try:
                request.session['user_franchise_id'] = user.franchisee.franchise.id
                return user.franchiseadmin.franchise
            except AttributeError:
                try:                    
                    if (len(user.windowcleaner.franchise.all()) > 1):
                        request.session['wc_multi_franchise'] = True
                    else:
                        franchise = ''
                        for franchise in user.windowcleaner.franchise.all():
                            franchise = franchise
                        request.session['user_franchise_id'] = franchise.id
                        request.session['wc_multi_franchise'] = False
                        return franchise                    
                except AttributeError:
                    try:
                        request.session['user_franchise_id'] = user.franchisee.franchise.id
                        return user.canvasser.franchise
                    except AttributeError:
                        try:
                            if 'franchisor_data_display' in request.session:
                                if int(request.session['franchisor_data_values']) != 0:
                                    franchise = Franchise.objects.get(
                                        pk=request.session['franchisor_data_values'])
                                    request.session['user_franchise_id'] = franchise.id
                                    return franchise
                                else:
                                    return None
                            else:
                                return None
                        except Exception as e:
                            print('error in get_user_franchise: ', str(e))
                            return None
    return None



def get_user_franchise_id(user, request):

    """ this gets and sets the user franchise ID in the session 
        so there is no need for multiple db queries on a 
        page where there are multiple checks for user franchise
        This to replace get_user_franchise() above when possible
    """

    if 'user_franchise_id' in request.session and request.session['user_franchise_id'] is not None:
        return int(request.session['user_franchise_id'])
    else:
        try:
            request.session['user_franchise_id'] = user.franchisee.franchise.id
            return user.franchisee.franchise.id
        except AttributeError:
            try:
                request.session['user_franchise_id'] = user.franchiseadmin.franchise.id
                return user.franchiseadmin.franchise.id
            except AttributeError:
                try:
                    request.session['user_franchise_id'] = user.windowcleaner.franchise.id
                    return user.windowcleaner.franchise.id
                except AttributeError:
                    try:
                        request.session['user_franchise_id'] = user.canvasser.franchise.id
                        return user.canvasser.franchise.id
                    except AttributeError:
                        try:
                            if 'franchisor_data_display' in request.session:
                                if int(request.session['franchisor_data_values']) != 0:
                                    franchise = Franchise.objects.get(
                                        pk=request.session['franchisor_data_values'])
                                    request.session['user_franchise_id'] = franchise.id
                                    return franchise.id
                                else:
                                    return None
                            else:
                                return None
                        except Exception as e:
                            print('error in get_user_franchise_id: ', str(e))
                            return None
        return None
# -- check if User Belongs to given group-- #
def has_group(request, group_name):
    if 'has_group_lists' in request.session and request.session['has_group_lists'] is not None:
        return group_name in request.session['has_group_lists']
    else:
        group = Group.objects.get(name=group_name)
        return True if group in request.user.groups.all() else False


def random_business_source():
    count = BusinessSource.objects.all().aggregate(
        count=Count('id'))['count']
    random_index = randint(0, count - 1)
    return BusinessSource.objects.all()[random_index]


def random_franchise():
    count = Franchise.objects.all().aggregate(
        count=Count('id'))['count']
    random_index = randint(0, count - 1)
    return Franchise.objects.all()[random_index]


def random_book_with():
    r = random()
    if r > 0.8:
        bw = BookWithChoice.objects.get(book_with='Email')
        return bw
    count = BookWithChoice.objects.all().aggregate(
        count=Count('id'))['count']
    random_index = randint(0, count - 1)
    return BookWithChoice.objects.all()[random_index]


def random_property_type():
    count = PropertyType.objects.all().aggregate(
        count=Count('id'))['count']
    random_index = randint(0, count - 1)
    return PropertyType.objects.all()[random_index]


def random_frequency():
    r = random()
    if r > 0.9:
        bw = FrequencyChoice.objects.get(frequency_choice=4)
        return bw
    count = FrequencyChoice.objects.all().aggregate(
        count=Count('id'))['count']
    random_index = randint(0, count - 1)
    return FrequencyChoice.objects.all()[random_index]


def random_method():
    count = CleaningMethod.objects.all().aggregate(
        count=Count('id'))['count']
    random_index = randint(0, count - 1)
    return CleaningMethod.objects.all()[random_index]


def random_task():
    count = JobTask.objects.all().aggregate(
        count=Count('id'))['count']
    random_index = randint(0, count - 1)
    return JobTask.objects.all()[random_index]


def random_wc():
    count = WindowCleaner.objects.all().aggregate(
        count=Count('id'))['count']
    random_index = randint(0, count - 1)
    return WindowCleaner.objects.all()[random_index]


def random_access():
    count = AccessMethod.objects.all().aggregate(
        count=Count('id'))['count']
    random_index = randint(0, count - 1)
    return AccessMethod.objects.all()[random_index]


def random_money():
    count = MoneyType.objects.all().aggregate(
        count=Count('id'))['count']
    random_index = randint(0, count - 1)
    return MoneyType.objects.all()[random_index]


def random_alt_commission():
    if random() > 0.95:
        return 12.5
    return None


def random_date(start, end):
    """
    This function will return a random datetime between two datetime
    objects.
    """
    delta = end - start
    int_delta = (delta.days)
    random_day = randrange(int_delta)
    return start + timedelta(days=random_day)


def fill_customers():
    reader = csv.DictReader(open('customers.csv', 'rb'))
    dict_list = []
    for line in reader:
        dict_list.append(line)
    for line in dict_list:
        c = Customer.objects.create(
            title=line['title'],
            first_name=line['first_name'],
            last_name=line['last_name'],
            business_source=random_business_source(),
            # # business_source_notes=line['business_source_notes'],
            customer_since=datetime.datetime.strptime(
                line['customer_since'], "%d/%m/%Y").date(),
            told_policy=True,
            # # told_policy_notes=line['told_policy_notes'],
            told_terms_conditions=True,
            # # told_terms_conditions_date=line['told_terms_conditions_date'],
            # # credit=line['credit'],
            # # prepaid_to=line['prepaid_to'],
            stop_paperless_bills=False,
            # # pause_paperless_bills_until_date=line['pause_paperless_bills_until_date'],
            stop_chasers=False,
            block_auto_bookings=False,
            # # block_auto_bookings_until_date=line['block_auto_bookings_until_date'],
            cancelled=False,
            # # cancelled_reason=line['cancelled_reason'],
            # # date_cancelled=line['date_cancelled'],
            take_off=False,
            # # take_off_reason=line['take_off_reason'],
            # # notes=line['notes'],
            # # important_job_notes=line['important_job_notes'],
            # # last_price=line['last_price'],
            # # last_price_increase_date=line['last_price_increase_date'],
            building_number=line['building_number'],
            building_name=line['building_name'],
            sub_building_name=line['sub_building_name'],
            thoroughfare=line['thoroughfare'],
            address_line_1=line['address_line_1'],
            address_line_2=line['address_line_2'],
            address_line_3=line['address_line_3'],
            post_town=line['post_town'],
            county=line['county'],
            postcode=line['postcode'],
            organisation_name=line['organisation_name'],
            postcode_outward=line['postcode_outward'],
            postcode_inward=line['postcode_inward'],
            latitude=line['latitude'],
            longitude=line['longitude'],
            udprn=line['udprn'],
            franchise=random_franchise(),
            home_phone=line['home_phone'],
            mobile_phone=line['mobile_phone'],
            # # formatted_mobile_phone=line['formatted_mobile_phone'],
            # # work_phone=line['work_phone'],
            # # home_ansaphone=line['home_ansaphone'],
            # # mob_ansaphone=line['mob_ansaphone'],
            # # phone_extension=line['phone_extension'],
            email=line['email'],
            # cc_email=line['cc_email'],
            no_email=False,
            book_with=random_book_with(),
            property_type=random_property_type(),
            # # when_to_collect=line['when_to_collect'],
            # # chased_notes=line['chased_notes'],
            frequency=random_frequency(),
            default_cleaning_method=random_method(),
            # # alternative_commission=line['alternative_commission'],
            # # weekly_cycle=line['weekly_cycle'],
            # # weekly_cycle_current=line['weekly_cycle_current'],
            # # set_time=line['set_time'],
            use_default_job=True,
            job_task_default=random_task(),
            price_default=12,
            # # access_type_default=line['access_type_default'],
            # # money_type_default=line['money_type_default'],
            # # auto_booking_default=line['auto_booking_default'],
            # # job_task_alt=line['job_task_alt'],
            # # price_alt=line['price_alt'],
            # # access_type_alt=line['access_type_alt'],
            # # money_type_alt=line['money_type_alt'],
            # # auto_booking_alt=line['auto_booking_alt'],
            # # set_time_alt=line['set_time_alt']
        )


# from common.utilities import fill_jobs


def fill_jobs():
    for cust in Customer.objects.all():
        # insert 1st job
        date = datetime.datetime.now()-timedelta(days=randint(1, 7))
        r = random()
        if r > 0.9:
            stat = JobStatus.objects.get(job_status_description='Due')
        else:
            stat = JobStatus.objects.get(job_status_description='Booked')
        first_job = Job.objects.create(
            window_cleaner=random_wc(),
            job_task=random_task(),
            cleaning_method=random_method(),
            set_price=randint(8, 80),
            # price_on_day
            # owes
            # voucher
            # loss
            access=random_access(),
            money_type=random_money(),
            # auto_booking
            alternative_commission=random_alt_commission(),
            # Bank_transfer_to
            scheduled_date=date,
            allocated_date=date,
            job_status=stat,
            # payment_status
            # job_notes
            # this_clean_only_notes
            customer=cust,
            # customer_reminder
            # booked_by
            # checked_in_by
            # checked_in_timestamp
            # manual_check_in
            # completed_date_check_in
            # job_status_check_in
            # job_not_done
            # is_first_job
            # created_date_time
            # last_edited
        )
        date = first_job.scheduled_date-timedelta(
            weeks=first_job.customer.frequency.frequency_choice)
        stat = JobStatus.objects.get(job_status_description='Completed')
        num_jobs = randint(1, 35)
        for i in range(1, num_jobs):
            r = random()
            if r > 0.9:
                payment_status = PaymentStatus.objects.get(
                    payment_status_description='MWC Owed')
            else:
                payment_status = PaymentStatus.objects.get(
                    payment_status_description='Paid')
            job = Job.objects.create(
                window_cleaner=first_job.window_cleaner,
                job_task=first_job.job_task,
                cleaning_method=first_job.cleaning_method,
                set_price=first_job.set_price,
                # price_on_day
                # owes
                # voucher
                # loss
                access=first_job.access,
                money_type=first_job.money_type,
                # auto_booking
                alternative_commission=first_job.alternative_commission,
                # Bank_transfer_to
                scheduled_date=date,
                allocated_date=date,
                job_status=stat,
                payment_status=payment_status,
                job_notes=' '.join(get_sentences(randint(0, 5))),
                this_clean_only_notes=' '.join(get_sentences(randint(0, 2))),
                customer=cust,
                # customer_reminder
                # booked_by
                checked_in_by=first_job.window_cleaner.user
                # checked_in_timestamp
                # manual_check_in
                # completed_date_check_in
                # job_status_check_in
                # job_not_done
                # is_first_job
                # created_date_time
                # last_edited
            )
            date = date-timedelta(
                weeks=first_job.customer.frequency.frequency_choice)


def export_customers():
    with open('customers.csv', 'wb') as csvfile:
        writer = csv.writer(csvfile, dialect='excel')
        row = []
        fields = Customer._meta.get_fields()
        for f in fields:
            if not f.is_relation or f.one_to_one or (
                    f.many_to_one and f.related_model):
                row.append(f.name)
        writer.writerow(row)
        for cust in Customer.objects.all():
            row = []
            for f in fields:
                if not f.is_relation or f.one_to_one or (
                        f.many_to_one and f.related_model):
                    row.append(getattr(cust, f.name))
            writer.writerow(row)
        #  from common.utilities import filldb


def job_notes():
    for j in Job.objects.all():
        j.job_notes = ' '.join(get_sentences(randint(0, 5)))
        j.save()


def current_site_url(request):
    """Returns fully qualified URL (no trailing slash) for the current site."""
    from django.contrib.sites.shortcuts import get_current_site
    current_site = get_current_site(request)
    protocol = getattr(settings, 'MY_SITE_PROTOCOL', 'http')
    port = getattr(settings, 'MY_SITE_PORT', '')
    url = '%s://%s' % (protocol, current_site.domain)
    if port:
        url += ':%s' % port
    return url


def get_the_day_of_week(week_date):
    date_parms = week_date.split('-')
    get_week_date = datetime.date(
        int(date_parms[0]),
        int(date_parms[1]),
        int(date_parms[2])
    )
    day_number = get_week_date + datetime.timedelta(days=1)
    return day_number.weekday()


def date_day_suffix(d):
    return 'th' if 11<=d<=13 else {1:'st',2:'nd',3:'rd'}.get(d%10, 'th')

def custom_strftime_with_suffix(format, t):
    return t.strftime(format).replace('{S}', str(t.day) + date_day_suffix(t.day))


def get_job_time_slot_str(job_id,return_boolean=False):

    job_time_slot_set = TimeSlot.objects.filter(job_id=job_id)
    time_slot_lists = []

    if len(job_time_slot_set) > 0:
        if return_boolean == True:
            return True
        else:
            for job_time_slot in job_time_slot_set:
                str = ''
                if job_time_slot.NOT_flag:
                    str += 'Not '
                str += job_time_slot.date.strftime("%a %d/%m")
                if not job_time_slot.end_time and not job_time_slot.start_time:
                    str += ' any'
                elif not job_time_slot.end_time and job_time_slot.start_time:
                    start_time_format = job_time_slot.start_time.strftime("%I:%M%p").replace(
                        ':00', '').lstrip("0").replace(" 0", " ")
                    str += ' aft. ' + start_time_format + ' '
                elif not job_time_slot.start_time and job_time_slot.end_time:
                    end_time_format = job_time_slot.end_time.strftime("%I:%M%p").replace(
                        ':00', '').lstrip("0").replace(" 0", " ")
                    str += ' bef ' + end_time_format + ' '
                elif job_time_slot.start_time and job_time_slot.end_time:
                    start_time_format = job_time_slot.start_time.strftime("%I:%M%p").replace(
                        ':00', '').lstrip("0").replace(" 0", " ")
                    end_time_format = job_time_slot.end_time.strftime("%I:%M%p").replace(
                        ':00', '').lstrip("0").replace(" 0", " ")
                    str += ' ' + start_time_format + \
                        '-' + end_time_format
                time_slot_lists.append(str)

        return ', '.join(time_slot_lists)


def get_customer_time_slot_str(customer_id, job_id):

    customer_query_set = Customer.objects.get(id=customer_id)
    job_query_set = Job.objects.get(id=job_id)

    if customer_query_set.use_alternate_job == False:
        customer_time_slot_set = DefaultTimeSlot.objects.filter(
            customer_id=customer_id)
    elif customer_query_set.use_alternate_job == True:
        if customer_query_set.job_cycle != job_query_set.job_cycle_current:
            customer_time_slot_set = DefaultTimeSlot.objects.filter(
            customer_id=customer_id)
        else:
            customer_time_slot_set = AlternateTimeSlot.objects.filter(
                customer_id=customer_id)

    str = ''
    time_slot_lists = []
    other_day_str = ''
    if len(customer_time_slot_set) > 0:
        for customer_time_slot in customer_time_slot_set:
            str = ''            

            if 'Contact customer' in customer_time_slot.day_of_week:
                str += 'TBA'
            else:
                customer_time_slot.day_of_week = day_abbreviation(customer_time_slot.day_of_week)

            str += customer_time_slot.day_of_week

            if customer_time_slot.NOT_flag is True:
                str += ' X '

            if customer_time_slot.is_specific_appointment == False:
                if not customer_time_slot.end_time and customer_time_slot.start_time:
                    start_time_format = customer_time_slot.start_time.strftime("%I:%M%p").replace(
                        ':00', '').lstrip("0").replace(" 0", " ")
                    str += ' A ' + start_time_format + ' '
                elif not customer_time_slot.start_time and customer_time_slot.end_time:
                    end_time_format = customer_time_slot.end_time.strftime("%I:%M%p").replace(
                        ':00', '').lstrip("0").replace(" 0", " ")
                    str += ' B ' + end_time_format + ' '
                elif customer_time_slot.start_time and customer_time_slot.end_time:
                    start_time_format = customer_time_slot.start_time.strftime("%I:%M%p").replace(
                        ':00', '').lstrip("0").replace(" 0", " ")
                    end_time_format = customer_time_slot.end_time.strftime("%I:%M%p").replace(
                        ':00', '').lstrip("0").replace(" 0", " ")
                    str += ' ' + start_time_format + \
                        '-' + end_time_format + ' '
                elif not customer_time_slot.start_time and \
                    not customer_time_slot.end_time:
                    #str += ' any'
                    pass
            else:
                if customer_time_slot.start_time:
                    start_time_format = customer_time_slot.start_time.strftime("%I:%M%p").replace(
                        ':00', '').lstrip("0").replace(" 0", " ")
                    str += ' ' + start_time_format + ' '

            if customer_time_slot.notes:
                str += ' - ' + customer_time_slot.notes

            if customer_time_slot.day_of_week == 'Oth':
                other_day_str = str.rstrip()
            else:
                time_slot_lists.append(str.rstrip())

        time_slot_lists.append(other_day_str)

        time_slot_lists_str = ', '.join(time_slot_lists)
        return time_slot_lists_str.rstrip(', ')
    else:
        return 'Any'

def get_customer_time_slot_span_str(customer_id, type_job='default'):

    if type_job == 'default':
        customer_time_slot_set = DefaultTimeSlot.objects.filter(
            customer_id=customer_id)
    else:
        customer_time_slot_set = AlternateTimeSlot.objects.filter(
            customer_id=customer_id)

    str = ''
    time_slot_lists = []
    other_day_str = ''
    index = 1
    if len(customer_time_slot_set) > 0:
        for customer_time_slot in customer_time_slot_set:
            str = ''
            if customer_time_slot.NOT_flag is True:
                str += 'X '

            if 'Contact customer' in customer_time_slot.day_of_week:
                str += 'TBA'
            else:
                customer_time_slot.day_of_week = day_abbreviation(customer_time_slot.day_of_week)

            str += customer_time_slot.day_of_week

            if customer_time_slot.is_specific_appointment == False:
                if not customer_time_slot.end_time and customer_time_slot.start_time:
                    start_time_format = customer_time_slot.start_time.strftime("%I:%M%p").replace(
                        ':00', '').lstrip("0").replace(" 0", " ")
                    str += ' A ' + start_time_format + ' '
                elif not customer_time_slot.start_time and customer_time_slot.end_time:
                    end_time_format = customer_time_slot.end_time.strftime("%I:%M%p").replace(
                        ':00', '').lstrip("0").replace(" 0", " ")
                    str += ' B ' + end_time_format + ' '
                elif customer_time_slot.start_time and customer_time_slot.end_time:
                    start_time_format = customer_time_slot.start_time.strftime("%I:%M%p").replace(
                        ':00', '').lstrip("0").replace(" 0", " ")
                    end_time_format = customer_time_slot.end_time.strftime("%I:%M%p").replace(
                        ':00', '').lstrip("0").replace(" 0", " ")
                    str += ' ' + start_time_format + \
                        '-' + end_time_format + ' '
                elif not customer_time_slot.start_time and \
                    not customer_time_slot.end_time:
                    #str += ' any'
                    pass
            else:
                if customer_time_slot.start_time:
                    start_time_format = customer_time_slot.start_time.strftime("%I:%M%p").replace(
                        ':00', '').lstrip("0").replace(" 0", " ")
                    str += ' ' + start_time_format + ' '

            if customer_time_slot.notes:
                str += ' - ' + customer_time_slot.notes

            if index == len(customer_time_slot_set):
                str = '<span>%s </span>' % str
            else:
                str = '<span>%s, </span>' % str

            if customer_time_slot.day_of_week == 'Oth':
                other_day_str = str.rstrip()
            else:
                time_slot_lists.append(str.rstrip())
            index += 1
            
        time_slot_lists.append(other_day_str)

    return mark_safe(' '.join(time_slot_lists))


def get_allocate_time_slot_str(job_id):

    job_object = Job.objects.only(
        'allocated_date_specific_time','allocated_date_start_time',
        'allocated_date_end_time','allocated_date_NOT_flag'
    ).get(id=job_id)
    
    Slot_str = ''
    if job_object.allocated_date_NOT_flag is True:
        Slot_str += 'X '

    if job_object.allocated_date_specific_time == False:
        if not job_object.allocated_date_end_time and job_object.allocated_date_start_time:
            start_time_format = job_object.allocated_date_start_time.strftime("%I:%M%p").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            Slot_str += ' A ' + start_time_format + ' '
        elif not job_object.allocated_date_start_time and job_object.allocated_date_end_time:
            end_time_format = job_object.allocated_date_end_time.strftime("%I:%M%p").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            Slot_str += ' B ' + end_time_format + ' '
        elif job_object.allocated_date_start_time and job_object.allocated_date_end_time:
            start_time_format = job_object.allocated_date_start_time.strftime("%I:%M").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            end_time_format = job_object.allocated_date_end_time.strftime("%I:%M%p").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            Slot_str += ' ' + start_time_format + \
                '-' + end_time_format + ' '
        elif not job_object.allocated_date_start_time and \
            not job_object.allocated_date_end_time:
            #Slot_str += ' any'
            pass
    else:
        if job_object.allocated_date_start_time:
            start_time_format = job_object.allocated_date_start_time.strftime("%I:%M%p").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            Slot_str += ' '+start_time_format
    
    Slot_str = re.sub(' +', ' ', Slot_str)
    return Slot_str


def get_day_two_time_slot_str(job_id):
    
    job_object = Job.objects.only(
        'day_two_specific_time','day_two_date_start_time',
        'day_two_end_time','day_two_NOT_flag'
    ).get(id=job_id)

    Slot_str = ''
    if job_object.day_two_NOT_flag is True:
        Slot_str += 'X '

    if job_object.day_two_specific_time == False:
        if not job_object.day_two_end_time and job_object.day_two_date_start_time:
            start_time_format = job_object.day_two_date_start_time.strftime("%I:%M%p").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            Slot_str += ' A ' + start_time_format + ' '
        elif not job_object.day_two_date_start_time and job_object.day_two_end_time:
            end_time_format = job_object.day_two_end_time.strftime("%I:%M%p").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            Slot_str += ' B ' + end_time_format + ' '
        elif job_object.day_two_date_start_time and job_object.day_two_end_time:
            start_time_format = job_object.day_two_date_start_time.strftime("%I:%M").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            end_time_format = job_object.day_two_end_time.strftime("%I:%M%p").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            Slot_str += ' ' + start_time_format + \
                '-' + end_time_format + ' '
        elif not job_object.day_two_date_start_time and \
            not job_object.day_two_end_time:
            #Slot_str += ' any'
            pass
    else:
        if job_object.day_two_date_start_time:
            start_time_format = job_object.day_two_date_start_time.strftime("%I:%M%p").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            Slot_str += ' '+start_time_format 
    
    Slot_str = re.sub(' +', ' ', Slot_str)
    return Slot_str



def get_allocate_day2_time_slot_str(job_id):
    
    job_object = Job.objects.select_related('customer').only(
        'allocated_date', 'day_two_date',
        'allocated_date_specific_time', 'allocated_date_start_time',
        'allocated_date_end_time', 'allocated_date_NOT_flag',
        'day_two_specific_time', 'day_two_date_start_time',
        'day_two_end_time', 'day_two_NOT_flag', 'customer__one_day_only'
    ).get(id=job_id)

    Slot_allocate_str = ''
    if job_object.allocated_date_NOT_flag is True:
        Slot_allocate_str += 'X '

    day1_start_time_format = day2_start_time_format = ''
    if job_object.allocated_date_specific_time == False:
        if not job_object.allocated_date_end_time and job_object.allocated_date_start_time:
            start_time_format = job_object.allocated_date_start_time.strftime("%I:%M%p").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            Slot_allocate_str += 'A ' + start_time_format + ' '
            day1_start_time_format = job_object.allocated_date_start_time.strftime("%I:%M").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
        elif not job_object.allocated_date_start_time and job_object.allocated_date_end_time:
            end_time_format = job_object.allocated_date_end_time.strftime("%I:%M%p").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            Slot_allocate_str += 'B ' + end_time_format + ' '
        elif job_object.allocated_date_start_time and job_object.allocated_date_end_time:
            start_time_format = job_object.allocated_date_start_time.strftime("%I:%M").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            end_time_format = job_object.allocated_date_end_time.strftime("%I:%M%p").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            Slot_allocate_str += start_time_format + \
                '-' + end_time_format + ''
        elif not job_object.allocated_date_start_time and \
            not job_object.allocated_date_end_time and job_object.allocated_date_NOT_flag is False:
            Slot_allocate_str += 'Any'
    else:
        if job_object.allocated_date_start_time:
            start_time_format = job_object.allocated_date_start_time.strftime("%I:%M%p").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            Slot_allocate_str += start_time_format + ' '


    Slot_day2_str = ''
    if job_object.day_two_NOT_flag is True:
        Slot_day2_str += 'X '

    if job_object.day_two_specific_time == False:
        if not job_object.day_two_end_time and job_object.day_two_date_start_time:
            start_time_format = job_object.day_two_date_start_time.strftime("%I:%M%p").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            Slot_day2_str += 'A ' + start_time_format + ' '
            day2_start_time_format = job_object.day_two_date_start_time.strftime("%I:%M").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
        elif not job_object.day_two_date_start_time and job_object.day_two_end_time:
            end_time_format = job_object.day_two_end_time.strftime("%I:%M%p").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            Slot_day2_str += 'B ' + end_time_format + ' '
        elif job_object.day_two_date_start_time and job_object.day_two_end_time:
            start_time_format = job_object.day_two_date_start_time.strftime("%I:%M").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            end_time_format = job_object.day_two_end_time.strftime("%I:%M%p").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            Slot_day2_str += start_time_format + \
                '-' + end_time_format + ''
        elif not job_object.day_two_date_start_time and \
            not job_object.day_two_end_time and job_object.day_two_NOT_flag is False:
            Slot_day2_str += 'Any'
    else:
        if job_object.day_two_date_start_time:
            start_time_format = job_object.day_two_date_start_time.strftime("%I:%M%p").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            Slot_day2_str += start_time_format + ' '

    Slot_str_return = allocate_date_str = day_two_date_str = ''

    if job_object.allocated_date:
        allocate_date_str = custom_strftime_with_suffix('{S}',job_object.allocated_date)
    if job_object.day_two_date:
        day_two_date_str = custom_strftime_with_suffix('{S}',job_object.day_two_date)
        # day_two_date_str = job_object.day_two_date.strftime("X%d/X%m").replace('X0','X').replace('X','')

    if Slot_allocate_str == 'Any' and Slot_day2_str == 'Any':
        ''' if allocate_date_str and day_two_date_str:
            Slot_str_return = allocate_date_str+'/'+day_two_date_str+' Any'
        else:
            Slot_str_return = allocate_date_str+' Any' '''
        Slot_str_return = ' Any'
    else:
        if allocate_date_str and day_two_date_str:
            if Slot_allocate_str == Slot_day2_str or \
                (
                    (Slot_allocate_str == 'Any' or Slot_allocate_str.strip() == 'A {}AM'.format(day1_start_time_format)) and \
                    (Slot_day2_str == 'Any' or Slot_day2_str.strip() == 'A {}AM'.format(day2_start_time_format)) and \
                    job_object.allocated_date_NOT_flag is False and job_object.day_two_NOT_flag is False):
                Slot_str_return = Slot_allocate_str
            else:    
                Slot_str_return = Slot_allocate_str+'/'+day_two_date_str+' '+Slot_day2_str
        else:
            Slot_str_return = Slot_allocate_str
        # print(Slot_str_return)

    Slot_str_return = re.sub(' +', ' ', Slot_str_return)
    if job_object.day_two_NOT_flag is True or job_object.customer.one_day_only is True:
        return mark_safe('<span class="text-danger">'+ Slot_str_return +'<span>')
    elif day_two_date_str == '' or job_object.day_two_NOT_flag is True: 
        return mark_safe('<span class="text-black">'+ Slot_str_return +'<span>')
    else:
        return Slot_str_return

def planner_get_customer_time_slot(cust_job_fields, default_time_slots, alt_time_slots):
    if cust_job_fields['use_alternate_job'] == False:
        customer_time_slot_set =copy.deepcopy(default_time_slots)
    elif cust_job_fields['use_alternate_job'] == True:
        if cust_job_fields['cust_job_cycle'] != cust_job_fields['job_cycle_current']:
            customer_time_slot_set =copy.deepcopy(default_time_slots)
        else:
            customer_time_slot_set = copy.deepcopy(alt_time_slots)

    str = ''
    time_slot_lists = []
    other_day_str = ''
    time_slot_dict = {}
    if customer_time_slot_set is not None and len(customer_time_slot_set) > 0:
        for customer_time_slot in customer_time_slot_set:
            str = ''                    
            day_of_week = customer_time_slot['day_of_week']
            if 'Contact customer' in customer_time_slot['day_of_week']:
                str += 'TBA'
            else:
                customer_time_slot['day_of_week'] = day_abbreviation(customer_time_slot['day_of_week'])

            str += customer_time_slot['day_of_week']

            if customer_time_slot['NOT_flag'] is True:
                str += ' X '

            if customer_time_slot['is_specific_appointment'] == False:
                if not customer_time_slot['end_time'] and customer_time_slot['start_time']:
                    start_time_format = customer_time_slot['start_time'].strftime("%I:%M%p").replace(
                        ':00', '').lstrip("0").replace(" 0", " ")
                    str += ' A ' + start_time_format + ' '
                elif not customer_time_slot['start_time'] and customer_time_slot['end_time']:
                    end_time_format = customer_time_slot['end_time'].strftime("%I:%M%p").replace(
                        ':00', '').lstrip("0").replace(" 0", " ")
                    str += ' B ' + end_time_format + ' '
                elif customer_time_slot['start_time'] and customer_time_slot['end_time']:
                    start_time_format = customer_time_slot['start_time'].strftime("%I:%M%p").replace(
                        ':00', '').lstrip("0").replace(" 0", " ")
                    end_time_format = customer_time_slot['end_time'].strftime("%I:%M%p").replace(
                        ':00', '').lstrip("0").replace(" 0", " ")
                    str += ' ' + start_time_format + \
                        '-' + end_time_format + ' '
                elif not customer_time_slot['start_time'] and \
                    not customer_time_slot['end_time']:
                    #str += ' any'                    
                    pass
            else:
                if customer_time_slot['start_time']:
                    start_time_format = customer_time_slot['start_time'].strftime("%I:%M%p").replace(
                        ':00', '').lstrip("0").replace(" 0", " ")
                    str += ' ' + start_time_format + ' '

            if customer_time_slot['notes']:
                str += ' - ' + customer_time_slot['notes']

            if customer_time_slot['day_of_week'] == 'Oth':
                other_day_str = str.rstrip()
            else:
                time_slot_lists.append(str.rstrip())
    
        time_slot_lists.append(other_day_str)
        time_slot_lists_str = ', '.join(time_slot_lists)
        
        if day_of_week=='Any day' and (not customer_time_slot['end_time'] and not customer_time_slot['start_time']):
            time_slot_dict['slots'] = 'Any'
            time_slot_dict['is_any_day'] = True
        elif day_of_week=='Any day' and (customer_time_slot['start_time'] or customer_time_slot['end_time']): # any + time slot
            time_slot_dict['slots'] = time_slot_lists_str.rstrip(', ')
            time_slot_dict['is_any_day'] = True
        else:
            time_slot_dict['slots'] = 'Any'
            time_slot_dict['is_any_day'] = False
    else:
        time_slot_dict['slots'] = 'Any'
        time_slot_dict['is_any_day'] = True

    return time_slot_dict

def planner_get_allocate_time_slot(allocated_fields):

    Slot_str = ''
    if allocated_fields['allocated_date_NOT_flag'] is True:
        Slot_str += 'X '

    if allocated_fields['allocated_date_specific_time'] == False:
        if not allocated_fields['allocated_date_end_time'] and allocated_fields['allocated_date_start_time']:
            start_time_format = allocated_fields['allocated_date_start_time'].strftime("%I:%M%p").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            Slot_str += ' A ' + start_time_format + ' '
        elif not allocated_fields['allocated_date_start_time'] and allocated_fields['allocated_date_end_time']:
            end_time_format = allocated_fields['allocated_date_end_time'].strftime("%I:%M%p").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            Slot_str += ' B ' + end_time_format + ' '
        elif allocated_fields['allocated_date_start_time'] and allocated_fields['allocated_date_end_time']:
            start_time_format = allocated_fields['allocated_date_start_time'].strftime("%I:%M").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            end_time_format = allocated_fields['allocated_date_end_time'].strftime("%I:%M%p").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            Slot_str += ' ' + start_time_format + \
                '-' + end_time_format + ' '
        elif not allocated_fields['allocated_date_start_time'] and \
            not allocated_fields['allocated_date_end_time']:
            #Slot_str += ' any'
            pass
    else:
        if allocated_fields['allocated_date_start_time']:
            start_time_format = allocated_fields['allocated_date_start_time'].strftime("%I:%M%p").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            Slot_str += ' '+start_time_format
    
    Slot_str = re.sub(' +', ' ', Slot_str)
    return Slot_str

def planner_get_day_two_time_slot(day2_fields):

    Slot_str = ''
    if day2_fields['day_two_NOT_flag'] is True:
        Slot_str += 'X '

    if day2_fields['day_two_specific_time'] == False:
        if not day2_fields['day_two_end_time'] and day2_fields['day_two_date_start_time']:
            start_time_format = day2_fields['day_two_date_start_time'].strftime("%I:%M%p").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            Slot_str += ' A ' + start_time_format + ' '
        elif not day2_fields['day_two_date_start_time'] and day2_fields['day_two_end_time']:
            end_time_format = day2_fields['day_two_end_time'].strftime("%I:%M%p").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            Slot_str += ' B ' + end_time_format + ' '
        elif day2_fields['day_two_date_start_time'] and day2_fields['day_two_end_time']:
            start_time_format = day2_fields['day_two_date_start_time'].strftime("%I:%M").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            end_time_format = day2_fields['day_two_end_time'].strftime("%I:%M%p").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            Slot_str += ' ' + start_time_format + \
                '-' + end_time_format + ' '
        elif not day2_fields['day_two_date_start_time'] and \
            not day2_fields['day_two_end_time']:
            #Slot_str += ' any'
            pass
    else:
        if day2_fields['day_two_date_start_time']:
            start_time_format = day2_fields['day_two_date_start_time'].strftime("%I:%M%p").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            Slot_str += ' '+start_time_format 
    
    Slot_str = re.sub(' +', ' ', Slot_str)
    return Slot_str

def day_abbreviation(day_of_week):

    day_abbreviations = {}
    day_abbreviations['Monday'] = 'M'
    day_abbreviations['Tuesday'] = 'Tu'
    day_abbreviations['Wednesday'] = 'W'
    day_abbreviations['Thursday'] = 'Th'
    day_abbreviations['Friday'] = 'F'
    day_abbreviations['Saturday'] = 'Sa'
    day_abbreviations['Sunday'] = 'Su'
    day_abbreviations['Any day'] = 'Any'
    day_abbreviations['Other days'] = 'Oth'

    return day_abbreviations[day_of_week]

def job_time_slot_availablity_check(time_slot,allocate_to_date,is_day1_day2='day1'):
    
    Slot_str = ''

    if is_day1_day2 == 'day2' and time_slot.day_two_date is not None:
        if allocate_to_date.strftime('%Y-%m-%d') != time_slot.day_two_date.strftime('%Y-%m-%d'):
            return Slot_str

        if time_slot.day_two_NOT_flag is True:
            Slot_str += 'not '

        if time_slot.day_two_specific_time is False:

            if not time_slot.day_two_date_start_time and \
                not time_slot.day_two_end_time:
                Slot_str += 'any time'

            elif not time_slot.day_two_end_time and time_slot.day_two_date_start_time:
                start_time_format = time_slot.day_two_date_start_time.strftime("%I:%M%p").replace(
                    ':00', '').lstrip("0").replace(" 0", " ")
                Slot_str += 'after ' + start_time_format
            
            elif not time_slot.day_two_date_start_time and time_slot.day_two_end_time:
                end_time_format = time_slot.day_two_end_time.strftime("%I:%M%p").replace(
                    ':00', '').lstrip("0").replace(" 0", " ")
                Slot_str += 'before ' + end_time_format

            elif time_slot.day_two_date_start_time and time_slot.day_two_end_time:
                start_time_format = time_slot.day_two_date_start_time.strftime("%I:%M%p").replace(
                    ':00', '').lstrip("0").replace(" 0", " ")
                end_time_format = time_slot.day_two_end_time.strftime("%I:%M%p").replace(
                    ':00', '').lstrip("0").replace(" 0", " ")
                Slot_str += 'between ' + start_time_format + \
                    '-' + end_time_format
        else:
            if time_slot.day_two_date_start_time and not time_slot.day_two_end_time:
                start_time_format = time_slot.day_two_date_start_time.strftime("%I:%M%p").replace(
                    ':00', '').lstrip("0").replace(" 0", " ")
                Slot_str += 'at ' + start_time_format
    else:
        if allocate_to_date.strftime('%Y-%m-%d') != time_slot.allocated_date.strftime('%Y-%m-%d'):
            return Slot_str

        if time_slot.allocated_date_NOT_flag is True:
            Slot_str += 'not '

        if time_slot.allocated_date_specific_time is False:

            if not time_slot.allocated_date_start_time and \
                not time_slot.allocated_date_end_time:
                Slot_str += 'any time'

            elif not time_slot.allocated_date_end_time and time_slot.allocated_date_start_time:
                start_time_format = time_slot.allocated_date_start_time.strftime("%I:%M%p").replace(
                    ':00', '').lstrip("0").replace(" 0", " ")
                Slot_str += 'after ' + start_time_format
            
            elif not time_slot.allocated_date_start_time and time_slot.allocated_date_end_time:
                end_time_format = time_slot.allocated_date_end_time.strftime("%I:%M%p").replace(
                    ':00', '').lstrip("0").replace(" 0", " ")
                Slot_str += 'before ' + end_time_format

            elif time_slot.allocated_date_start_time and time_slot.allocated_date_end_time:
                start_time_format = time_slot.allocated_date_start_time.strftime("%I:%M%p").replace(
                    ':00', '').lstrip("0").replace(" 0", " ")
                end_time_format = time_slot.allocated_date_end_time.strftime("%I:%M%p").replace(
                    ':00', '').lstrip("0").replace(" 0", " ")
                Slot_str += 'between ' + start_time_format + \
                    '-' + end_time_format
        else:
            if time_slot.allocated_date_start_time and not time_slot.allocated_date_end_time:
                start_time_format = time_slot.allocated_date_start_time.strftime("%I:%M%p").replace(
                    ':00', '').lstrip("0").replace(" 0", " ")
                Slot_str += 'at ' + start_time_format

    return Slot_str

def time_slot_availablity_check(time_slot):
    
    Slot_str = ''
    if time_slot.NOT_flag is True:
        Slot_str += 'not '        

    ''' if 'Any day' in time_slot.day_of_week or 'Other day' in time_slot.day_of_week:
        time_slot.day_of_week = ' '
    else:
        time_slot.day_of_week = ' '+time_slot.day_of_week

    Slot_str += time_slot.day_of_week '''

    if time_slot.is_specific_appointment is False:

        if not time_slot.start_time and \
            not time_slot.end_time:
            Slot_str += 'any time'

        elif not time_slot.end_time and time_slot.start_time:
            start_time_format = time_slot.start_time.strftime("%I:%M%p").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            Slot_str += 'after ' + start_time_format
        
        elif not time_slot.start_time and time_slot.end_time:
            end_time_format = time_slot.end_time.strftime("%I:%M%p").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            Slot_str += 'before ' + end_time_format

        elif time_slot.start_time and time_slot.end_time:
            start_time_format = time_slot.start_time.strftime("%I:%M%p").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            end_time_format = time_slot.end_time.strftime("%I:%M%p").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            Slot_str += 'between ' + start_time_format + \
                '-' + end_time_format
    else:
        if not time_slot.end_time and time_slot.start_time:
            start_time_format = time_slot.start_time.strftime("%I:%M%p").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            Slot_str += 'at ' + start_time_format

    return Slot_str


def get_hours_lists():
    """ Get Hours Lists """
    hours_lists = []
    for i in range(0, 24*2):
        hours_lists.append(
            (
                (datetime.datetime.combine(datetime.date.today(), datetime.time()
                                           ) + datetime.timedelta(minutes=30) * i).time().strftime("%H:%M"),
                (datetime.datetime.combine(datetime.date.today(), datetime.time()) +
                 datetime.timedelta(minutes=30) * i).time().strftime("%I:%M %p")
            )
        )
    return hours_lists


def get_wc_job_time_slot_str(job_type):
    """
    This function will return short form for job_type passed.
    """
    job_type_val = ' '
    if job_type == 'Clean only':
        job_type_val = ' '
    elif job_type == 'Quote only':
        job_type_val = 'Q'
    elif job_type == 'TBA':
        job_type_val = 'TBA'
    elif job_type == 'Quote & clean':
        job_type_val = 'Q&C'
    elif job_type == 'Window cleaner visit':
        job_type_val = 'WC'

    return job_type_val


def customer_job_status(customer_id):
    job = Job.objects.filter(
                            customer_id=customer_id,
                            job_status__job_is_done=False
                        ).values(
                            'id', 'job_status__job_is_done'
                        ).first()
    return job

def textify(html):
    # Remove html tags and continuous whitespaces 
    html = html.replace("<br>", "\n").replace("<br/>", "\n")
    text_only = re.sub('[ \t]+', ' ', strip_tags(html))
    text_only = unescape(text_only)
    # Strip single spaces in the beginning of each line
    return text_only.replace('\n ', '\n').strip()


def create_message_before_celery(franchise_id,franchisor_id,receiver_type,receiver_id):
    
    new_message = Message(
        outgoing=True,
        sent_time=timezone.now(),
        message_type=Message.EMAIL_MESSAGE
    )

    if franchise_id != '':
        new_message.franchise_id = franchise_id

    if franchisor_id != '':
        new_message.franchisor_id = franchisor_id

    if receiver_type == 'C':
        new_message.customer_id = receiver_id
    if receiver_type == 'CO':
        new_message.contact_id = receiver_id
    if receiver_type == 'U':
        new_message.user_id = receiver_id
    if receiver_type == 'CL':
        new_message.commercial_list_id = receiver_id

    new_message.save()
    last_insert_msg_id = new_message.id

    return last_insert_msg_id

def generate_user_initial(user_or_wc):

    """ 
        This function is used for generate User and Windowcleaner name initials
        Takes a User instance as input
    """    
    if (isinstance(user_or_wc,User)):
        initials = ''.join(
            (
                user_or_wc.first_name[:1],
                user_or_wc.middle_name[:1],
                user_or_wc.last_name[:1]
            )
        )        
    elif (isinstance(user_or_wc,WindowCleaner)):
        initials = ''.join(
            (
                user_or_wc.user.first_name[:1],
                user_or_wc.user.middle_name[:1],
                user_or_wc.user.last_name[:1]
            )
        )  
    else:   # a string has been passed        
        if len(user_or_wc) > 0:
            initials = ''        
            names = user_or_wc.split()
            for name in names:
                initials += name[0].upper()
        else:
            initials = ''
    return initials


def get_initials_from_user_id(user_id):
    """
        returns the initials of a user
        takes a user ID
    """
    try:
        user = User.objects.get(id=user_id)    
        initials = generate_user_initial(user)
        return initials
    except User.DoesNotExist:
        return None

def get_franchise_str(franchise_id):
    """
        returns the franchise name
        takes a Franchise ID
    """
    try:
        franchise = Franchise.objects.get(id=franchise_id)            
        return franchise.franchise
    except Franchise.DoesNotExist:
        return None

def get_all_franchisee_territory():
    """
        returns the all franchisee_territory 
        with comma separated and
    """
    queryset_franchise = Franchise.objects.all()
    franchisee_territory_str = ''
    franchisee_territory_list = []
    for franchise in queryset_franchise:
        franchisee_territory = str(franchise.franchisee_territory)
        franchisee_territory_list.append(franchisee_territory)
    if len(franchisee_territory_list) > 0:
        franchisee_territory_str = "{} and {}".format(", ".join(franchisee_territory_list[:-1]),  franchisee_territory_list[-1])

    return franchisee_territory_str

def get_franchise_cust_user_ids(recipient, sender):

    cust_user_franchise_dict = {}

    cust_user_franchise_dict['franchise_id'] = None
    cust_user_franchise_dict['franchisor_id'] = None
    cust_user_franchise_dict['customer_id'] = None
    cust_user_franchise_dict['contact_id'] = None
    cust_user_franchise_dict['user_id'] = None
    cust_user_franchise_dict['commercial_id'] = None

    alternate_email=False

    if 'gmail.com' in sender or 'googlemail.com' in sender:
        alternate_email = True
        sender1 = sender.replace('googlemail.com', 'gmail.com')
        sender2 = sender.replace('gmail.com', 'googlemail.com')
    
    if 'ymail.com' in sender or 'yahoo.com' in sender:
        alternate_email = True
        sender1 = sender.replace('yahoo.com', 'ymail.com')
        sender2 = sender.replace('ymail.com', 'yahoo.com')

    try:
        franchise = Franchise.objects.get(email__iexact=recipient)
    except Franchise.DoesNotExist:
        franchise = None

    if franchise:
        cust_user_franchise_dict['franchise_id'] = franchise.id

    try:
        franchisor = Franchisor.objects.get(user__email__iexact=recipient)
    except Franchisor.DoesNotExist:
        franchisor = None

    if franchisor:
        cust_user_franchise_dict['franchisor_id'] = franchisor.id

    try:
        if alternate_email:
            customer_det = Customer.objects.filter(
                Q(email=sender1) | Q(email=sender2) | Q(cc_email=sender1) | Q(cc_email=sender2)
            ).first()
        else:
            customer_det = Customer.objects.filter(
                Q(email__iexact=sender) |
                Q(cc_email__iexact=sender)
            ).first()
        if customer_det:
            if franchise is not None and franchise != customer_det.booking_road.area.franchise:
                cust_user_franchise_dict['customer_id'] = None
            else:
                cust_user_franchise_dict['customer_id'] = customer_det.id
    except Customer.DoesNotExist:
        cust_user_franchise_dict['customer_id'] = None

    
    if alternate_email:
        contact_det = Contact.objects.filter(
            Q(email=sender1) | Q(email=sender2)
        ).first()
    else:
        contact_det = Contact.objects.filter(email__iexact=sender).first()
    if contact_det:
        cust_user_franchise_dict['contact_id'] = contact_det.id
    else:
        cust_user_franchise_dict['contact_id'] = None

    if alternate_email:
        user_det = User.objects.filter(
            Q(email=sender1) | Q(email=sender2)
        ).first()
    else:
        user_det = User.objects.filter(email__iexact=sender).first()
    if user_det:
        cust_user_franchise_dict['user_id'] = user_det.id
    else:    
        cust_user_franchise_dict['user_id'] = None

    if alternate_email:
        commercial_list_det = CommercialList.objects.filter(
            Q(email=sender1) | Q(email=sender2)
        ).first()
    else:
        commercial_list_det = CommercialList.objects.filter(email__iexact=sender).first()
    if commercial_list_det:
        cust_user_franchise_dict['commercial_id'] = commercial_list_det.id
    else:
        cust_user_franchise_dict['commercial_id'] = None

    return cust_user_franchise_dict


def convert_or_coerce_timestamp_to_utc(timeobj):
    out = timeobj
    try:
        out = timeobj.astimezone(pytz.utc)  # aware object can be in any timezone
    except (
        ValueError,
        TypeError
        ) as exc:  # naive
        out = timeobj.replace(tzinfo=pytz.utc)
    return out


def count_wc_invoice_checked(user):

    with connection.cursor() as cursor:
        # note invoice_date < CURRENT_DATE is specific to this one
        cursor.execute(
            """with cte as (
                    select distinct completed_date
                    from jobs_job
                        inner join customers_customer cc on jobs_job.customer_id = cc.id
                        inner join franchises_bookingroad fb on cc.booking_road_id = fb.id
                        inner join franchises_area fa on fb.area_id = fa.id
                        inner join jobs_jobstatus jj on jobs_job.job_status_id = jj.id
                        inner join accounts_windowcleaner aw on jobs_job.window_cleaner_id = aw.id
                        inner join accounts_user au on aw.user_id = au.id
                    where   (
                            jj.generates_invoice is True
                            or
                            checked_in_from_app is True
                            or (
                                        jj.generates_invoice is False
                                        and
                                        checked_in_timestamp >= allocated_date
                                    )
                            )
                            and fa.is_test_area is FALSE
                            and au.id = {0}
                            and jj.job_status_description not in ('Message sent', 'Office ref', 'Skipped after reminder')
                )
                , cte2 as (
                    select invoice_date from jobs_checkedinvoice
                    inner join accounts_windowcleaner a on jobs_checkedinvoice.window_cleaner_id = a.id
                    inner join accounts_user u on a.user_id = u.id
                    where checked_status={1}
                    and invoice_date < CURRENT_DATE
                    and u.id = {0}
                )
                select count(*) cnt from cte left join cte2 on cte2.invoice_date = cte.completed_date
                where cte2.invoice_date IS NULL
            """.format(user.id, 1)
        )
        columns = [col[0] for col in cursor.description]
        query_dict = [dict(zip(columns, row)) for row in cursor.fetchall()]            
    return query_dict[0]['cnt']


def checkFileExistOnS3(bucket, key):

    s3_client = boto3.client('s3')
    try:
        s3_client.head_object(Bucket=bucket, Key=key)
    except ClientError as e:
        print('File not exist----',e)
        return int(e.response['Error']['Code']) != 404
    return True

def get_last_day_of_month(any_day):
    # this will never fail
    # get close to the end of the month for any day, and add 4 days 'over'
    next_month = any_day.replace(day=28) + datetime.timedelta(days=4)
    # subtract the number of remaining 'overage' days to get last day of current month, or said programattically said, the previous day of the first of next month
    return next_month - datetime.timedelta(days=next_month.day)

def set_def_alt_job_time_slot_to_allocated_job(customer_obj, job_query_set, allocated_date):    

    ''' This function is use for set allocate date time slot with from default and alt job. '''

    customer_query_set = customer_obj

    allocate_date_day = None
    if allocated_date is not None and allocated_date !='':
        allocate_date_day = allocated_date.strftime('%A')
    
    if customer_query_set.use_alternate_job == False:
        timeslot_query_set = DefaultTimeSlot.objects.filter(
        customer_id=customer_obj.id)
    elif customer_query_set.use_alternate_job == True:
        if customer_query_set.job_cycle != job_query_set.job_cycle_current:
            timeslot_query_set = DefaultTimeSlot.objects.filter(
            customer_id=customer_obj.id)
        else:
            timeslot_query_set = AlternateTimeSlot.objects.filter(
                customer_id=customer_obj.id)

    dict_job_slots = {}
    NOT_flag = is_specific_time = False
    start_time = end_time = None
    day_exist = False
    if len(timeslot_query_set) > 0 and allocate_date_day is not None:
        for timeslot_query in timeslot_query_set:
            if allocate_date_day is not None and str(timeslot_query.day_of_week) == str(allocate_date_day):
                if timeslot_query.start_time is not None:
                    start_time = timeslot_query.start_time
                if timeslot_query.end_time is not None:
                    end_time = timeslot_query.end_time
                
                NOT_flag = timeslot_query.NOT_flag
                is_specific_time = timeslot_query.is_specific_appointment
                
                if timeslot_query.is_specific_appointment is True:
                    NOT_flag = False
                day_exist = True

            elif timeslot_query.day_of_week == 'Contact customer':
                NOT_flag = True
            elif timeslot_query.day_of_week == 'Other days' and timeslot_query.NOT_flag is True:
                NOT_flag = True
            elif timeslot_query.day_of_week == 'Other days':
                start_time = timeslot_query.start_time
                end_time = timeslot_query.end_time
                NOT_flag = timeslot_query.NOT_flag
                is_specific_time = timeslot_query.is_specific_appointment
            elif timeslot_query.day_of_week == 'Any day' and not day_exist:
                if timeslot_query.start_time is not None:
                    start_time = timeslot_query.start_time
                if timeslot_query.end_time is not None:
                    end_time = timeslot_query.end_time           
                NOT_flag = timeslot_query.NOT_flag
                is_specific_time = timeslot_query.is_specific_appointment
            else:
                pass

        dict_job_slots['start_time'] = start_time
        dict_job_slots['end_time'] = end_time
        dict_job_slots['NOT_flag'] = NOT_flag
        dict_job_slots['is_specific_time'] = is_specific_time

    else:
        dict_job_slots['start_time'] = start_time
        dict_job_slots['end_time'] = end_time
        dict_job_slots['NOT_flag'] = NOT_flag
        dict_job_slots['is_specific_time'] = is_specific_time

    return dict_job_slots


def get_chaser_bank_details(job, franchise):
    """ Returns BTDs for chasers and paperless bills """

    window_cleaner = job.window_cleaner
    customer = job.customer
    commercial_list = customer.commercial_list    
    chaser_money_type = job.money_type.chaser_money_type
    
    if commercial_list is not None and commercial_list.pay_wc_directly == True and commercial_list.wc_for_bank_details:
        bank_name = commercial_list.wc_for_bank_details.user.bank_name
        bank_account_name = commercial_list.wc_for_bank_details.user.bank_account_holder_name
        bank_account_number = commercial_list.wc_for_bank_details.user.bank_account_number
        bank_account_sort_code = commercial_list.wc_for_bank_details.user.bank_account_sort_code
        bank_account_notes = commercial_list.wc_for_bank_details.user.bank_account_notes
    
    if window_cleaner.is_employed == False and chaser_money_type != MoneyType.BT_MWC:
        bank_name = window_cleaner.user.bank_name
        bank_account_name = window_cleaner.user.bank_account_holder_name
        bank_account_number = window_cleaner.user.bank_account_number
        bank_account_sort_code = window_cleaner.user.bank_account_sort_code
        bank_account_notes = window_cleaner.user.bank_account_notes
    else:
        bank_name = franchise.bank_name
        bank_account_name = franchise.account_name
        bank_account_number = franchise.account_number
        bank_account_sort_code = franchise.account_sort_code
        bank_account_notes = franchise.bank_account_notes
    
    return {
        'bank_name':bank_name,
        'bank_account_name':bank_account_name,
        'bank_account_number':bank_account_number,
        'bank_account_sort_code':bank_account_sort_code,
        'bank_account_notes':bank_account_notes,
    }

def formatted_cust_other_quotes(customer_other_quotes):
    
    cust_other_quotes = ''
    cust_other_quote_list = []
    if isinstance(customer_other_quotes, str):
        customer_other_quotes = json.loads(customer_other_quotes)

    if len(customer_other_quotes) > 0:
        
        for cust_other_quote in customer_other_quotes:
            if cust_other_quote['tasks'] != '' and cust_other_quote['price']:
                cust_other_quote_str = '<span class="cust_other_quotes">'
                price = '<span class="price">'+currency_short_with_negative(cust_other_quote['price'])+'</span>'
                tasks = '<span class="tasks">'+cust_other_quote['tasks']+'</span>'
                notes = '<span class="notes">'+cust_other_quote['notes']+'</span>'
                cust_other_quote_str += tasks+' - '+price+' '+notes
                cust_other_quote_str += '</span>'
                cust_other_quote_list.append(cust_other_quote_str)
    
    if len(cust_other_quote_list) > 0:
        cust_other_quotes = ", ".join(cust_other_quote_list)

    return mark_safe(cust_other_quotes)


def get_cust_ppd_wc_initials(credit_item_list):
    """ Return PPD comma-separated list of wc initials """

    cust_ppd_wc_initials = []
    if len(credit_item_list) > 0:
        for cust_credit in credit_item_list:
            if cust_credit.prepaid_to_wc is None:
                cust_ppd_wc_initials.append('MWC')
            else:
                cust_ppd_wc_initials.append(cust_credit.prepaid_to_wc.get_wc_first_last_initials())

        cust_ppd_wc_initials = list(set(cust_ppd_wc_initials))

    return ', '.join(cust_ppd_wc_initials) if len(cust_ppd_wc_initials) > 0 else ''


def get_this_year_bank_holidays(franchise):

    division = franchise.bank_holiday_division or 1
    this_year_start = datetime.date(datetime.date.today().year, 1, 1)
    next_year_start = datetime.date(datetime.date.today().year, 1, 1) + datetime.timedelta(weeks=52)

    holidays_this_year_start = BankHolidays.objects.filter(
        division=division,
        date__gte=this_year_start,
        date__lt=next_year_start,
    ).order_by('date').values()

    return holidays_this_year_start


def fn_get_total_hours(sum_of_duration):
    total_seconds = int(sum_of_duration)
    negative=''
    if total_seconds<0:
        total_seconds = -total_seconds
        negative = '-'
    time = datetime.timedelta(seconds=total_seconds)
    hours = time.seconds//3600
    minutes = (time.seconds//60)%60
    if minutes > 0:
        return '{0}{1}h{2}'.format(negative,hours, minutes )
    else:
        return '{0}{1}h'.format(negative, hours)


def get_client_ip(request):
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[-1]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip