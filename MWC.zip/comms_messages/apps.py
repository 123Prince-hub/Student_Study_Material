# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.apps import AppConfig


class CommsMessagesConfig(AppConfig):
    name = 'comms_messages'
    verbose_name = 'Email & SMS messages'
