from accounts.models import (
    User, WindowCleaner, Franchisee, FranchiseAdmin,
    LeafletDistributor, Canvasser, Franchisor, CustomerCare
)
from comms_messages.models import Message, UnactionedMessage

from django.db.models.signals import post_save, pre_delete, pre_save
from django.dispatch import receiver
from django.contrib.auth.models import Group


@receiver(post_save, sender=Franchisor)
def create_franchisor_user(sender, instance, created, **kwargs):
    """ This is use for assign franchior group to created franchisor user """

    if created:
        user_instance = User.objects.get(pk=instance.user_id)
        franchisor_group = Group.objects.get(name='franchisor')
        franchisor_group.user_set.add(user_instance)


@receiver(pre_delete, sender=Franchisor)
def delete_franchisor_user(sender, instance, using, **kwargs):
    """ This is use for unassign franchior group to deleted franchisor user """

    user_instance = User.objects.get(pk=instance.user_id)
    franchisor_group = Group.objects.get(name='franchisor')
    franchisor_group.user_set.remove(user_instance)

@receiver(post_save, sender=CustomerCare)
def create_customer_care_user(sender, instance, created, **kwargs):
    """ This is use for assign customer_care group to created customer_care user """

    if created:
        user_instance = User.objects.get(pk=instance.user_id)
        customer_care_group = Group.objects.get(name='customer_care')
        customer_care_group.user_set.add(user_instance)


@receiver(pre_delete, sender=CustomerCare)
def delete_customer_care_user(sender, instance, using, **kwargs):
    """ This is use for unassign customer_care group to deleted customer_care user """

    user_instance = User.objects.get(pk=instance.user_id)
    customer_care_group = Group.objects.get(name='customer_care')
    customer_care_group.user_set.remove(user_instance)

@receiver(post_save, sender=Franchisee)
def create_franchisee_user(sender, instance, created, **kwargs):
    """ This is use for assign franchisee group to created franchisee user """

    if created:
        user_instance = User.objects.get(pk=instance.user_id)
        franchisee_group = Group.objects.get(name='franchisee')
        franchisee_group.user_set.add(user_instance)

@receiver(pre_delete, sender=Franchisee)
def delete_franchisee_user(sender, instance, using, **kwargs):
    """ This is use for unassign franchisee group to deleted franchisee user """

    user_instance = User.objects.get(pk=instance.user_id)
    franchisee_group = Group.objects.get(name='franchisee')
    franchisee_group.user_set.remove(user_instance)


@receiver(post_save, sender=FranchiseAdmin)
def create_franchise_admin_user(sender, instance, created, **kwargs):
    """ This is use for assign franchise_admin group to created franchise admin user """

    if created:
        user_instance = User.objects.get(pk=instance.user_id)
        franchise_admin_group = Group.objects.get(name='franchise_admin')
        franchise_admin_group.user_set.add(user_instance)

@receiver(pre_delete, sender=FranchiseAdmin)
def delete_franchise_admin_user(sender, instance, using, **kwargs):
    """ This is use for unassign franchise_admin group to deleted franchise admin user """

    user_instance = User.objects.get(pk=instance.user_id)
    franchise_admin_group = Group.objects.get(name='franchise_admin')
    franchise_admin_group.user_set.remove(user_instance)


@receiver(post_save, sender=WindowCleaner)
def create_window_cleaner_user(sender, instance, created, **kwargs):
    """ This is use for assign window_cleaner group to created window cleaner user """

    if created:
        user_instance = User.objects.get(pk=instance.user_id)
        window_cleaner_group = Group.objects.get(name='window_cleaner')
        window_cleaner_group.user_set.add(user_instance)

@receiver(pre_delete, sender=WindowCleaner)
def delete_window_cleaner_user(sender, instance, using, **kwargs):
    """ This is use for unassign window_cleaner group to deleted window cleaner user """

    user_instance = User.objects.get(pk=instance.user_id)
    window_cleaner_group = Group.objects.get(name='window_cleaner')
    window_cleaner_group.user_set.remove(user_instance)


@receiver(post_save, sender=LeafletDistributor)
def create_leaflet_distributor_user(sender, instance, created, **kwargs):
    """ This is use for assign leaflet_distributors group to created leaflet distributors user """

    if created:
        user_instance = User.objects.get(pk=instance.user_id)
        leaflet_distributor_group = Group.objects.get(
            name='leaflet_distributors')
        leaflet_distributor_group.user_set.add(user_instance)

@receiver(pre_delete, sender=LeafletDistributor)
def delete_leaflet_distributors_user(sender, instance, using, **kwargs):
    """ This is use for unassign leaflet_distributors group to deleted leaflet distributors user """

    user_instance = User.objects.get(pk=instance.user_id)
    leaflet_distributor_group = Group.objects.get(name='leaflet_distributors')
    leaflet_distributor_group.user_set.remove(user_instance)


@receiver(post_save, sender=Canvasser)
def create_canvasser_user(sender, instance, created, **kwargs):
    """ This is use for assign canvasser group to created canvasser user """

    if created:
        user_instance = User.objects.get(pk=instance.user_id)
        canvasser_group = Group.objects.get(name='canvasser')
        canvasser_group.user_set.add(user_instance)


@receiver(pre_delete, sender=Canvasser)
def delete_canvasser_user(sender, instance, using, **kwargs):
    """ This is use for unassign canvasser group to deleted canvasser user """

    user_instance = User.objects.get(pk=instance.user_id)
    canvasser_group = Group.objects.get(name='canvasser')
    canvasser_group.user_set.remove(user_instance)


@receiver(pre_save, sender=Message)
def on_change_actioned(
        sender, instance: Message,
        **kwargs
        ):

        if instance.outgoing is False and instance.franchise:
                current_val, created = UnactionedMessage.objects.get_or_create(
                        franchise=instance.franchise
                        )
                if instance.id is None:         # new message is being created
                        current_val.messages += 1
                        current_val.save()
                else:                           # message updated
                        previous = Message.objects.get(id=instance.id)
                        if previous.actioned is False and instance.actioned:
                                current_val.messages -= 1
                                current_val.save()
                        if previous.actioned and instance.actioned is False:
                                current_val.messages += 1
                                current_val.save()


