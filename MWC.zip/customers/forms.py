from decimal import *
from dal import autocomplete, forward
import re
import datetime
from functools import *
import operator

from customers.models import (
    Customer, BookWithChoice, IsInactiveReason,
    BusinessSourceCanvasser, BusinessSourceInternet,
    BusinessSourceLocalMagazine, BusinessSourceLocalAdBoard,
    BusinessSourceDirectory, BusinessSourceLeaflet,
    BusinessSource, WCNewCustomer,
    CommercialList, ImportedCustomer, VATFlags
)
from accounts.models import User, WindowCleaner
from franchises.models import BookingRoad, FranchiseVatRate
from jobs.models import Job, JobStatus, MoneyType, AccessMethod
from jobs.views import get_vat, vat_prices

from django import forms
from django.db.models import Q, F, Value
from django.db.models.functions import Coalesce, Concat, Upper, Substr, Cast
from django.forms import ModelForm, FloatField
from django.forms.widgets import HiddenInput, TextInput, \
    Textarea, DateInput, NumberInput, CheckboxInput, CheckboxSelectMultiple
from django.utils.translation import gettext_lazy as _
from phonenumber_field.widgets import PhoneNumberInternationalFallbackWidget
import phonenumbers
from common.utilities import get_user_franchise, has_group


class WCCustomerForm(ModelForm):

    class Meta:
        model = WCNewCustomer
        fields = [
            'title',
            'first_name',
            'last_name',
            'home_phone',
            'mobile_phone',
            'work_phone',
            'email',
            'building_number',
            'building_name',
            'sub_building_name',
            'address_line_1',
            'address_line_2',
            'address_line_3',
            'post_town',
            'county',
            'postcode',
            'postcode_outward',
            'postcode_inward',
            'organisation_name',
            'latitude',
            'longitude',
            'udprn',
            'property_type',
            # 'access_type',
            # 'money_type',
            # 'is_first_job',
            # 'job_task',
            # 'first_clean_price',
            # 'regular_price',
            # 'frequency',
            # 'cleaned_today',
            # 'amount_paid',
            # # 'other_quotes_JSON',
            # 'booking_road',
        ]
        widgets = {
            'building_number': HiddenInput(),
            'building_name': HiddenInput(),
            'sub_building_name': HiddenInput(),
            'thoroughfare': HiddenInput(),
            'county': HiddenInput(),
            'postcode_outward': HiddenInput(),
            'postcode_inward': HiddenInput(),
            'organisation_name': HiddenInput(),
            'latitude': HiddenInput(),
            'longitude': HiddenInput(),
            'udprn': HiddenInput(),
            'home_phone': PhoneNumberInternationalFallbackWidget(),
            'mobile_phone': PhoneNumberInternationalFallbackWidget(),
            'work_phone': PhoneNumberInternationalFallbackWidget(),
            }
        labels = {
            'job_task': _('Job tasks'),
            }

    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user')
        request = kwargs.pop('request', None)
        franchise = get_user_franchise(user, request)
        super(WCCustomerForm, self).__init__(*args, **kwargs)
        # self.fields['booking_road'].queryset = \
        #     BookingRoad.objects.filter(
        #         area__franchise=franchise
        #         ).select_related()


class CustomerDetailForm(ModelForm):

    error_css_class = 'is-invalid'
    is_inactive_reason_dummy = forms.ModelChoiceField(
            queryset=IsInactiveReason.objects.all(),
            initial=3,
            required=False,
            label='Reason'
        )

    customer_list = forms.ModelChoiceField(
        # TODO check filter for franchise
        # works in view CustomersAutocomplete
        required=False,
        queryset=Customer.objects.all(),
        widget=autocomplete.ModelSelect2(
            url='customer-autocomplete',
            attrs={
                'data-placeholder': 'Go to customer ...',
            },
        )
    )
    time_slots_default_JSON = forms.CharField(
        required=True,
        label='Regular time slots'
    )
    time_slots_alt_JSON = forms.CharField(
        required=False,
        label='Alternate time slots'
    )
    job_task_default_JSON = forms.CharField(
        required=False,
        label='Job task'
    )
    job_task_alt_JSON = forms.CharField(
        required=False,
        label='Job task'
    )
    other_quotes_JSON = forms.CharField(
        required=False,
        label='Other quotes'
    )
    job_status_btn = forms.CharField(
        required=False
    )

    time_needed_default = forms.DurationField(
                            widget=forms.TimeInput(
                                format='%H:%M',
                                attrs={
                                    'placeholder': 'Job duration HH:MM',
                                    'id': 'timepicker_default'
                                }
                            ), required=False)
    time_needed_alt = forms.DurationField(
                        widget=forms.TimeInput(
                            format='%H:%M',
                            attrs={
                                'placeholder': 'Job duration HH:MM',
                                'id': 'timepicker_alt'
                            }
                        ),
                        required=False
                        )

    # time_needed_default = forms.TimeField(input_formats=['%H:%M'],
    #                         widget=forms.TimeInput(format='%H:%M', attrs={'id': 'timepicker_default'}), required=False)

    # time_needed_alt = forms.TimeField(input_formats=['%H:%M'],
    #                         widget=forms.TimeInput(format='%H:%M', attrs={'id': 'timepicker_alt'}), required=False)
    class Meta:
        model = Customer
        fields = [
            'title',
            'first_name',
            'last_name',
            'business_source',
            'business_source_notes',
            'business_source_canvasser',
            'business_source_internet',
            'business_source_window_cleaner',
            'business_source_recommendation_customer',
            'business_source_local_magazine',
            'business_source_local_ad_board',
            'business_source_directory',
            'business_source_leaflet',
            'business_source_local_facebook',
            'business_source_existing_customer',
            'business_source_digital_magazine',
            'business_source_sponsorship',
            # 'told_policy',
            'told_terms_conditions_notes',
            'told_terms_conditions',
            'told_terms_conditions_date',
            # 'prepaid_to',
            'bank_transfer_to_default',
            'switch_off_review_links',
            'stop_paperless_bills',
            'stop_chasers',
            'email_invoice',
            'stop_auto_bookings',
            'auto_bookings',
            'last_price',
            'last_price_increase_date',
            'important_job_notes',
            'important_job_notes_alt',
            'booking_info',
            'customer_notes',
            'building_number',
            'building_name',
            'sub_building_name',
            'thoroughfare',
            'address_line_1',
            'address_line_2',
            'address_line_3',
            'post_town',
            'county',
            'postcode',
            'organisation_name',
            'postcode_outward',
            'postcode_inward',
            'latitude',
            'longitude',
            'udprn',
            'booking_road',
            'home_phone',
            # 'additional_home_phone',
            'mobile_phone',
            'additional_mobile_phone',
            'work_phone',
            # 'additional_work_phone',
            'home_ansaphone',
            'mob_ansaphone',
            'phone_extension',
            'email',
            'additional_email',
            'cc_email',
            'no_email',
            'book_with',
            'property_type',
            'number_of_bedrooms',
            'property_type_notes',
            'when_to_collect',
            'chased_notes',
            'frequency',
            'customer_since',
            'other_quotes_string',
            'is_inactive',
            'is_inactive_reason',
            'is_inactive_reason_notes',
            'date_inactive',
            'one_day_only',
            'is_commercial',
            'commercial_list',
            'no_sales_emails',
            'pi_to_price',
            'bank_transfer_to_default',
            'cleaning_method_default',
            'job_cycle',
            'job_task_default_note',
            'price_default',
            'access_type_default',
            'access_notes_default',
            'money_type_default',
            'use_alternate_job',
            'job_task_alt_note',
            'price_alt',
            'access_type_alt',
            'access_notes_alt',
            'money_type_alt',
            'cleaning_method_alt',
            'other_quotes_string',
            'job_task_default',
            'job_task_alt',
            'one_day_only',
            'one_day_only_alt',
            'other_quotes_string',
            'time_needed_default',
            'time_needed_alt',
            'alternative_commission_default',
            'alternative_commission_alt',
            'money_type_note',
            'bank_transfer_to_alt',
            'payment_suppl_info_default',
            'payment_suppl_info_alt',
            'is_set_up_choice',
            'set_up_by',
            'email_validation_customer_confirmed_spelling',
            'email_validation_customer_confirmed_received_email',
            'email_validation_received_customer_email',
            'email_validation_warning',
            'vat_notes',
            'vat_flag',
            'base_price_default',
            'base_price_alt',
            'price_default_vat',
            'price_alt_vat',
            'vat_price_reduced_from',
            'vat_price_reduced_to',            
            'vat_frequency_changed_from',
            'vat_frequency_changed_to'
        ]

        widgets = {
            'building_number': HiddenInput(),
            'building_name': HiddenInput(),
            'sub_building_name': HiddenInput(),
            'thoroughfare': HiddenInput(),
            'county': HiddenInput(),
            'postcode_outward': HiddenInput(),
            'postcode_inward': HiddenInput(),
            'organisation_name': HiddenInput(),
            'latitude': HiddenInput(),
            'longitude': HiddenInput(),
            'udprn': HiddenInput(),
            'address_line_1': HiddenInput(),
            'address_line_2': HiddenInput(),
            'address_line_3': HiddenInput(),
            'post_town': HiddenInput(),
            'postcode': HiddenInput(),
            # 'job_task_alt_note': Textarea(attrs={'rows': 2, 'cols': 15}),
            # 'job_task_default_note': Textarea(
            #     attrs={'rows': 2, 'cols': 15}),
            'booking_info': Textarea(attrs={'rows': 1, 'cols': 15, 'maxlength': 45,'style':"min-height:35px;"}),
            'chased_notes': Textarea(attrs={'rows': 1, 'cols': 15}),
            'vat_notes': Textarea(attrs={'rows': 1, 'cols': 15}),
            'important_job_notes': Textarea(attrs={'rows': 1, 'cols': 30}),
            'property_type_notes': Textarea(attrs={'rows': 1, 'cols': 30}),
            'customer_notes': Textarea(
                attrs={
                    'rows': 2,
                    'cols': 15,
                    'placeholder': 'Customer notes',
                    }
                ),
            'is_inactive_reason_notes': Textarea(
                attrs={
                    'rows': 2,
                    'cols': 15,
                    'placeholder': 'Inactive notes',
                    }
                ),
            'is_inactive': HiddenInput(),
            # 'is_inactive_reason': HiddenInput(),
            # 'is_inactive_reason_notes': HiddenInput(),
            'mobile_phone': PhoneNumberInternationalFallbackWidget(
                attrs={'placeholder': 'Enter a phone number...'}
                ),
            'home_phone': PhoneNumberInternationalFallbackWidget(
                attrs={'placeholder': 'Enter a phone number...'}
                ),
            'work_phone': PhoneNumberInternationalFallbackWidget(
                attrs={'placeholder': 'Enter a phone number...'}
                ),
            'phone_extension': Textarea(attrs={'rows': 1, 'cols': 15}),
            # busines sources autocompletes -------------------------------
            'business_source_directory': autocomplete.ModelSelect2(
                url='directory-autocomplete',
                forward=(forward.Const(1, 'franchise'),),
                attrs={
                    'data-placeholder': 'Search for directory...',
                    },
                    ),
            'business_source_window_cleaner': autocomplete.ModelSelect2(
                url='window-cleaner-autocomplete',
                forward=(forward.Const(1, 'franchise'),),
                attrs={
                    'data-placeholder': 'Search for WC...',
                    },
                    ),
            'business_source_canvasser': autocomplete.ModelSelect2(
                url='canvasser-autocomplete',
                forward=(forward.Const(1, 'franchise'),),
                attrs={
                    'data-placeholder': 'Search for canvasser...',
                    },
                    ),
            'business_source_internet': autocomplete.ModelSelect2(
                url='internet-autocomplete',
                forward=(forward.Const(1, 'franchise'),),
                attrs={
                    'data-placeholder': 'Search for internet...',
                    },
                    ),
            'business_source_recommendation_customer': autocomplete.ModelSelect2(
                url='customer-autocomplete',
                attrs={
                    'data-placeholder': 'Search for a customer...',
                    },
                    ),
            'business_source_existing_customer': autocomplete.ModelSelect2(
                url='customer-autocomplete',
                attrs={
                    'data-placeholder': 'Search for a customer...',
                    },
                    ),
            'business_source_leaflet': autocomplete.ModelSelect2(
                url='leaflet-autocomplete',
                forward=(forward.Const(1, 'franchise'),),
                attrs={
                    'data-placeholder': 'Search for leaflet...',
                    },
                    ),
            'business_source_local_facebook': autocomplete.ModelSelect2(
                url='local-facebook-autocomplete',
                forward=(forward.Const(1, 'franchise'),),
                attrs={
                    'data-placeholder': 'Search for local Facebook...',
                    },
                    ),
            'business_source_digital_magazine': autocomplete.ModelSelect2(
                url='digital-magazine-autocomplete',
                forward=(forward.Const(1, 'franchise'),),
                attrs={
                    'data-placeholder': 'Search for a digital magazine...',
                    },
                    ),
            'business_source_sponsorship': autocomplete.ModelSelect2(
                url='sponsorship-autocomplete',
                forward=(forward.Const(1, 'franchise'),),
                attrs={
                    'data-placeholder': 'Search for a sponsorship...',
                    },
                    ),
            'booking_road': autocomplete.ModelSelect2(
                url='booking-road-autocomplete',
                forward=(forward.Const(1, 'franchise'),),
                attrs={
                    'data-placeholder': 'Search for a booking road...',
                    },
            ),
            'important_job_notes': Textarea(attrs={'rows': 2, 'cols': 30}),
            'last_price': forms.NumberInput(attrs={
                'type': 'text',
                'step': 1.00}),
            'pi_to_price': forms.NumberInput(attrs={
                'type': 'text',
                'step': 1.00}),
            'price_default': forms.NumberInput(attrs={
                'type': 'text',
                'step': 1.00,
                'placeholder': 'Enter a price...'}),
            'price_alt': forms.NumberInput(attrs={
                'type': 'text',
                'step': 1.00,
                'placeholder': 'Enter a price...'}),
            'other_quotes_string': Textarea(attrs={'rows': 1, 'cols': 15}),

            'access_notes_default': Textarea(
                    attrs={
                        'rows': 1,
                        'cols': 15,
                        'placeholder': 'Enter access notes'
                        }
                    ),
            'access_notes_alt': Textarea(
                    attrs={
                        'rows': 1,
                        'cols': 15,
                        'placeholder': 'Enter access notes'
                        }
                    ),
            'payment_suppl_info_default': Textarea(attrs={'rows': 1, 'cols': 15}),
            'payment_suppl_info_alt': Textarea(attrs={'rows': 1, 'cols': 15}),
        }

        labels = {
            'chased_notes': _('Owing chasers notes'),
            'frequency': _('Frequency (weeks)'),
            'is_inactive_reason': _('Reason'),
            'other_quotes_string': _('Other quotes (text only)'),
            'last_price': _('Previous price'),
            'important_job_notes': _('Permanent important job notes'),
            'money_type_default': _('Money (reg. job)'),
            'money_type_alt': _('Money (alternate job)'),
            'access_type_default': _('Access (reg. job)'),
            'access_type_alt': _('Access (alternate job)'),
            'job_task_default_note': _('Task regular: price breakdown and notes'),
            'job_task_alt_note': _('Task Alt: price breakdown and notes'),
            'cleaning_method_default': _('Cleaning method'),
            'cleaning_method_alt': _('Cleaning method'),
            'business_source_recommendation_customer': _('Recomm. other customer'),
            'business_source_existing_customer':_('Existing customer'),
            'bank_transfer_to_default': _('Bank transfer to (reg. job)'),
            'price_default': _('Default price'),
            'price_alt': _('Alternate price'),
            'other_quotes_string': _('Other quotes notes'),
            'time_needed_default': _('Job duration HH:MM'),
            'time_needed_alt': _('Job duration HH:MM'),
            'property_type_notes': _('Property Type Info'),
            'payment_suppl_info_default': _('Payment suppl. info (reg. job)'),
            'payment_suppl_info_alt': _('Payment suppl. info(alternate job)'),
            'business_source_notes': _('Marketing notes'),           
        }

    class Media:
        js = ('js/default_job_form.js')

    def clean(self):
        # TODO: It's possible to save a WC that is not part of the cust.
        # franchise at this point.
        # The DOM has to be manipulated though as
        # context['window_cleaners'] is filtered
        cleaned_data = super().clean()
        mobile = cleaned_data.get("mobile_phone")
        email = cleaned_data.get("email")
        home_phone = cleaned_data.get("home_phone")
        work_phone = cleaned_data.get("work_phone")
        book_with = cleaned_data.get("book_with")
        text = BookWithChoice.objects.get(book_with='Text')
        text_only = BookWithChoice.objects.get(book_with='Text Only')
        book_with_email = BookWithChoice.objects.get(book_with='Email')
        phone_customer = BookWithChoice.objects.get(book_with='Phone Customer')
        is_inactive = cleaned_data.get("is_inactive")
        is_inactive_reason = cleaned_data.get("is_inactive_reason")
        additional_mobile_phone = cleaned_data.get("additional_mobile_phone")
        told_TCs = cleaned_data.get("told_terms_conditions")
        told_TCs_date = cleaned_data.get("told_terms_conditions_date")
        address_line_1 = cleaned_data.get("address_line_1")
        postcode = cleaned_data.get("postcode")
        post_town = cleaned_data.get("post_town")
        address_line_1 = cleaned_data.get("address_line_1")
        job_status_btn = cleaned_data.get("job_status_btn")
        first_name = cleaned_data.get("first_name")
        last_name = cleaned_data.get("last_name")
        booking_road = cleaned_data.get("booking_road")
        bt_to_default = cleaned_data.get("bank_transfer_to_default")
        bt_to_alt = cleaned_data.get("bank_transfer_to_alt")
        money_default = cleaned_data.get("money_type_default")
        money_alt = cleaned_data.get("money_type_alt")
        job_task_default = cleaned_data.get("job_task_default")
        frequency = cleaned_data.get("frequency")
        bank_transfer_to_wc = MoneyType.objects.get(money_type='Bank transfer to WC')
        business_source = cleaned_data.get("business_source")
        access_type_default = cleaned_data.get("access_type_default")
        pi_to_price = cleaned_data.get("pi_to_price")
        last_price = cleaned_data.get("last_price")
        last_price_increase_date = cleaned_data.get("last_price_increase_date")


        if access_type_default is not None:
            if access_type_default.requires_secondary_input and cleaned_data.get("access_notes_default") == '':
                self.add_error(
                    'access_notes_default',' Access Notes(reg. job) is required'
                )
        if business_source is not None:
            if business_source.business_source == 'Asked' and cleaned_data.get("business_source_window_cleaner") is None:
                self.add_error(
                        "business_source_window_cleaner",
                        ""
                        "This field is required."
                    )
            if business_source.business_source == 'Canvasser' and cleaned_data.get("business_source_canvasser") is None:
                self.add_error(
                        "business_source_canvasser",
                        ""
                        "This field is required."
                    )
            if business_source.business_source == 'Internet - other' and cleaned_data.get("business_source_internet") is None:
                self.add_error(
                        "business_source_internet",
                        ""
                        "This field is required."
                    )
            if business_source.business_source == 'Recommended - other customer' and cleaned_data.get("business_source_recommendation_customer") is None:
                self.add_error(
                        "business_source_recommendation_customer",
                        ""
                        "This field is required."
                    )
            if business_source.business_source == 'Directory' and cleaned_data.get("business_source_directory") is None:
                self.add_error(
                        "business_source_directory",
                        ""
                        "This field is required."
                    )
            if business_source.business_source == 'Leaflet' and cleaned_data.get("business_source_leaflet") is None:
                self.add_error(
                        "business_source_leaflet",
                        ""
                        "This field is required."
                    )
            if business_source.business_source == 'Local Facebook' and cleaned_data.get("business_source_local_facebook") is None:
                self.add_error(
                        "business_source_local_facebook",
                        ""
                        "This field is required."
                    )
            if business_source.business_source == 'Digital magazine' and cleaned_data.get("business_source_digital_magazine") is None:
                self.add_error(
                        "business_source_digital_magazine",
                        ""
                        "This field is required."
                    )
            if business_source.business_source == 'Sponsorship' and cleaned_data.get("business_source_sponsorship") is None:
                self.add_error(
                        "business_source_sponsorship",
                        ""
                        "This field is required."
                    )
            if business_source.business_source == 'Existing MWC customer' and cleaned_data.get("business_source_existing_customer") is None:
                self.add_error(
                        "business_source_existing_customer",
                        ""
                        "This field is required."
                    )
            if business_source.business_source == 'Local magazine' and cleaned_data.get("business_source_local_magazine") is None:
                self.add_error(
                        "business_source_local_magazine",
                        ""
                        "This field is required."
                    )
            if business_source.business_source == 'Local ad board' and cleaned_data.get("business_source_local_ad_board") is None:
                self.add_error(
                        "business_source_local_ad_board",
                        ""
                        "This field is required."
                    )
            if (business_source.business_source == 'Other' or business_source.business_source == 'Referral - external') and cleaned_data.get("business_source_notes") == '':
                self.add_error(
                        "business_source_notes",
                        ""
                        "This field is required."
                    )

        if job_status_btn == 'check_in_job':
            if first_name == '' and last_name == '':
                self.add_error(
                    "first_name",
                    "Name : "
                    "This field is required."
                )
        if address_line_1 == '' or postcode == '' or post_town == '':
            self.add_error(
                "address_line_1",
                "Address : "
                "This field is required."
                )
        if booking_road == '':
            self.add_error(
                "booking_road",
                ""
                "This field is required."
                )
        if additional_mobile_phone != '':
            s_additional_mobile_phone = additional_mobile_phone.split(',')
            add_m_errors = []
            for add_hp in s_additional_mobile_phone:
                try:
                    x = phonenumbers.parse(add_hp, "GB")
                    if not phonenumbers.is_valid_number(x):
                        add_m_errors.append(add_hp)
                except Exception as e:
                    add_m_errors.append(add_hp)

            if len(add_m_errors) > 0:
                if len(add_m_errors) > 1:
                    is_str = 'are'
                else:
                    is_str = 'is'

                total_errors = ', '.join(str(v) for v in add_m_errors)
                self.add_error(
                    'additional_mobile_phone',
                    total_errors + " " + is_str+" not valid phone numbers"
                )

        if book_with == text and mobile == '':
            self.add_error(
                'mobile_phone',
                "Cannot save 'Communicate by' as 'Text': "
                "no mobile number in contact details."
                )
        if book_with == text_only and mobile == '':
            self.add_error(
                'mobile_phone',
                "Cannot save 'Communicate by' as 'Text Only': "
                "no mobile number in contact details."
                )
        if book_with == book_with_email and email == '':
            self.add_error(
                'email',
                "Cannot save 'Communicate by' as 'Email': "
                "no email in contact details."
                )
        if book_with == phone_customer and mobile == '' and home_phone == '':
            self.add_error(
                'book_with',
                "Cannot save 'Communicate by' as 'Phone Customer': "
                "no mobile or home numbers in contact details."
                )
        if told_TCs and not told_TCs_date:
            self.add_error(
                "told_terms_conditions",
                "Told T&Cs is ticked: "
                "Please add a T&Cs date"
                )
        # if not told_TCs and told_TCs_date:
        #     self.add_error(
        #         "told_terms_conditions",
        #         "There is a T&C date: "
        #         "Please tick 'Told terms & conditions'"
        #         )
        # if not mobile and not home_phone and not work_phone: # both were entered
        #     self.add_error(
        #         'home_phone',
        #         "Please enter either mobile phone, work or home phone"
        #         )
        if money_default == bank_transfer_to_wc and bt_to_default is None:
            self.add_error(
                "bank_transfer_to_default",
                "Please select a 'BT to' for the regular job"
            )
        
        if frequency is None:
            self.add_error(
                "frequency",
                "Please select frequency"
            )            
        # -----------------------------------------------------------------
        if cleaned_data.get("use_alternate_job"):
            job_task_alt = cleaned_data.get("job_task_alt")
            if money_alt == bank_transfer_to_wc and bt_to_alt is None:
                self.add_error(
                    "bank_transfer_to_alt",
                    "Please select a 'BT to' for the alternate job"
                )
            if cleaned_data.get("price_alt") is None:
                self.add_error(
                    'price_alt',
                    "Please add a price for the alternate job."
                )
            if cleaned_data.get("access_type_alt") is None:
                self.add_error(
                    'access_type_alt',
                    "Please add an 'Access' value for the alternate job."
                )
            else :
                access_type_alt = cleaned_data.get("access_type_alt")
                if access_type_alt.requires_secondary_input and cleaned_data.get("access_notes_alt") == '':
                    self.add_error(
                        'access_notes_alt',
                        'Access Notes (alt job) is required'
                    )
            if cleaned_data.get("money_type_alt") is None:
                self.add_error(
                    'money_type_alt',
                    "Please add a 'How pays' value for the alternate job."
                )
            if cleaned_data.get("cleaning_method_alt") is None:
                self.add_error(
                    'cleaning_method_alt',
                    "Please add a cleaning method for the (alternate job)."
                )
            if cleaned_data.get("job_cycle") is None:
                self.add_error(
                    'job_cycle',
                    "Please add a job cycle value for the alternate job."
                )

            if (not job_task_alt):
                self.add_error(
                    'job_task_alt',
                    "Please enter at least one job task for the alt. job"
                    )        

        if not ((pi_to_price==None and last_price==None and last_price_increase_date==None) or \
            (pi_to_price!=None and last_price!=None and last_price_increase_date!=None)):
            self.add_error(
                "last_price",
                "Last price increase data incomplete; please fill in all the fields."
            )


    def __init__(self, request, user, action, *args, **kwargs):
        wc_id = None
        instance = kwargs.get('instance', None)
        if kwargs.get('initial', None):
            wc_id = kwargs['initial']['wc_id']
        franchise = get_user_franchise(user, request)
        super(CustomerDetailForm, self).__init__(*args, **kwargs)
        self.fields['property_type'].empty_label = None
        self.fields['frequency'].empty_label = 'Clean every XX weeks'
        self.fields['book_with'].empty_label = None
        self.fields['commercial_list'].queryset = \
            CommercialList.objects.filter(
                franchise=franchise
            )
        ''' self.fields['business_source'].queryset = \
            BusinessSource.objects.filter(
                id__in=franchise.businesssource_set.all(),
                ) '''
        
        if action != 'edit':        
            self.fields['money_type_default'].required = False
            self.fields['time_needed_default'].required = False
            self.fields['time_slots_default_JSON'].required = False
            self.fields['cleaning_method_default'].required = False
            self.fields['price_default'].required = False
            self.fields['job_task_default'].required = False
            self.fields['book_with'].initial = 2 #default email
            self.fields['business_source'].initial = 74 #default Asked
            if (wc_id is not None):
                self.fields['business_source_window_cleaner'].initial = wc_id
            self.fields['property_type'].initial = 27 #default TBA
        self.fields['frequency'].initial = 1
        access_method_data = AccessMethod.objects.all().order_by('order')
        self.fields['access_type_default'].queryset = access_method_data
        self.fields['access_type_alt'].queryset = access_method_data
        money_type_data = MoneyType.objects.all().order_by('order')
        self.fields['money_type_default'].queryset = money_type_data
        self.fields['money_type_alt'].queryset = money_type_data

        self.fields['business_source_window_cleaner'].required = False
        self.fields['title'].required = False  # because chosen-select interferes with jquery validation
        self.fields['first_name'].required = False
        self.fields['last_name'].required = False
        self.fields['mobile_phone'].required = False
        self.fields['home_phone'].required = False
        self.fields['address_line_1'].required = False
        self.fields['post_town'].required = False
        self.fields['postcode'].required = False
        self.fields['postcode'].required = False
        self.fields['frequency'].required = False

        self.fields['access_type_alt'].empty_label = "Select an access type..."
        self.fields['access_type_default'].empty_label = "Select an access type..."
        self.fields['money_type_default'].empty_label = "Select a money type..."
        self.fields['money_type_alt'].empty_label = "Select a money type..."
        self.fields['cleaning_method_default'].empty_label = "Select a cleaning method..."
        self.fields['cleaning_method_alt'].empty_label = "Select a cleaning method..."
        self.fields['bank_transfer_to_default'].empty_label = "Bank transfer to..."
        self.fields['time_needed_alt'].required = False
        self.fields['job_task_default'].required = False
        self.fields['money_type_default'].required = False

        self.fields['base_price_default'].required = False
        self.fields['price_default_vat'].required = False
        self.fields['base_price_alt'].required = False
        self.fields['price_alt_vat'].required = False
        self.fields['vat_flag'].required = False

        self.fields['cleaning_method_default'].error_messages = {'required': 'Please add a cleaning method for the (reg. job).'}
        if instance is not None and instance.commercial_list is not None:
            self.fields['stop_chasers'].widget.attrs.update({'disabled': 'disabled'})

        q_list = [
            Q(franchisee__franchise_id=franchise.id),
            Q(franchiseadmin__franchise_id=franchise.id),
            # Q(windowcleaner__franchise__id=franchise.id),
            # Q(leafletdistributor__franchise_id=franchise.id),
            # Q(canvasser__franchise_id=franchise.id),
            Q(franchisor__user_id__isnull=False),
            Q(customercare__user_id__isnull=False),            
        ]

        try:
            set_up_by_id = self.instance.set_up_by.id
        except AttributeError:
            set_up_by_id = None
        self.fields['set_up_by'].queryset = \
            User.objects.select_related(
                'windowcleaner',
                'franchisee',
                'franchiseadmin',
                'leafletdistributor',
                'canvasser',
                'customercare'
            ).filter(
                reduce(operator.or_, q_list),
                Q(is_active=True) | Q(id=set_up_by_id),
                ~Q(groups__name=None),
                ~Q(groups__name='franchisor_only')                
            ).annotate(
                job_title=F('franchiseadmin__job_title'),
                groups_name=F('groups__name')
            ).prefetch_related(
                'groups'
            ).distinct('id').only(
                'id', 'first_name', 'last_name'
            ).order_by('id')
            
        if self.errors:
            for f_name in self.fields:
                if f_name in self.errors:
                    classes = self.fields[f_name].widget.attrs.get('class', '')
                    classes += ' form-error'
                    self.fields[f_name].widget.attrs['class'] = classes


class FirstJobForm(ModelForm):
    ALLOC_WHEN_CHOICES = (
        ('Any Time', 'Any Time'),
        ('Before', 'Before'),
        ('After', 'After'),
        ('Between', 'Between'),
        ('At', 'At'),
    )
    DAY2_WHEN_CHOICES = (
        ('Any Time', 'X'),
        ('Before', 'Before'),
        ('After', 'After'),
        ('Between', 'Between'),
        ('At', 'At'),
    )
    allocate_when_choices = forms.ChoiceField(choices=ALLOC_WHEN_CHOICES, required=False)
    day2_when_choices = forms.ChoiceField(choices=DAY2_WHEN_CHOICES, required=False)
    allocated_data = forms.CharField(
        required=False,
    )
    day2_time_slot = forms.CharField(
        required=False,
    )
    job_status_btn = forms.CharField(
        required=False
    )
    allocated_date_start_time = forms.TimeField(input_formats=['%I:%M%p'],
                            widget=forms.TimeInput(format='%I:%M%p'), required=False)
    allocated_date_end_time = forms.TimeField(input_formats=['%I:%M%p'],
                            widget=forms.TimeInput(format='%I:%M%p'), required=False)
    day_two_date_start_time = forms.TimeField(input_formats=['%I:%M%p'],
                            widget=forms.TimeInput(format='%I:%M%p'), required=False)
    day_two_end_time = forms.TimeField(input_formats=['%I:%M%p'],
                            widget=forms.TimeInput(format='%I:%M%p'), required=False)

    time_needed = forms.DurationField(
                    widget=forms.TimeInput(
                        format='%H:%M',
                        attrs={'placeholder': 'Job duration HH:MM', 'id': 'timepicker_needed'}
                    ), required=False)

    job_status = forms.ModelChoiceField(queryset = JobStatus.objects.filter(id__in=[1,2,3]) )
    class Meta:
        model = Job
        fields = [
            'job_type',
            'window_cleaner',
            'job_task',
            'job_task_note',
            'cleaning_method',
            'set_price',
            'price_on_day',
            'owes',
            'access',
            'money_type',
            'alternative_commission',
            'due_date',
            'allocated_date',
            'allocated_date_start_time',
            'allocated_date_end_time',
            'allocated_date_NOT_flag',
            'allocated_date_specific_time',
            'day_two_date',
            'day_two_date_start_time',
            'day_two_end_time',
            'day_two_NOT_flag',
            'day_two_specific_time',
            'completed_date',
            'job_status',
            'payment_status',
            'this_clean_only_notes',
            'customer_reminder',
            'customer_reminder_note',
            'action_on_check_in',
            'job_cycle_current',
            'checked_in_by',
            'checked_in_timestamp',
            'is_first_job',
            'check_in_notes',
            'manual_check_in',
            'bank_transfer_to',
            'is_first_job',
            'office_notes',
            'important_job_notes',
            'time_needed',
            'access_notes',
            'booked_by',
            'payment_suppl_info',
            'vat_flag',
        ]

        widgets = {
            'set_price': forms.NumberInput(attrs={'step': 1.00}),
            'price_on_day': forms.NumberInput(attrs={'step': 1.00}),
            'customer_reminder_note': HiddenInput(),
            # 'job_task_note': Textarea(attrs={'rows': 2, 'cols': 15}),
            # 'action_on_check_in': Textarea(attrs={'rows': 2, 'cols': 15}),
            'access_notes': Textarea(attrs={'rows': 2, 'cols': 15}),
            'important_job_notes': Textarea(attrs={'rows': 2, 'cols': 15}),
            'payment_suppl_info': Textarea(attrs={'rows': 2, 'cols': 15}),
            'check_in_notes': Textarea(attrs={'rows': 2, 'cols': 15}),
            'this_clean_only_notes': Textarea(attrs={'rows': 2}),
            'office_notes': Textarea(attrs={'rows': 2}),
            'time_needed': TextInput(
                attrs={'placeholder': '00:00', 'data-timepicker': ''}
            ),
            'customer_reminder': HiddenInput(),
            'allocated_date_specific_time': HiddenInput(),
            'day_two_specific_time': HiddenInput(),
            'booked_by': HiddenInput(),
        }
        labels = {
            'this_clean_only_notes': _('Notes for this clean only'),
            'action_on_check_in': _('Office to action when booking/at check in'),
            'office_notes': _('Summary notes for historical reference'),
        }

    def clean(self):
        cleaned_data = super().clean()
        due_status = JobStatus.objects.get(job_status_description='Due')
        try:
            refer_to_office = JobStatus.objects.get(job_status_description='Office ref')
        except:
            refer_to_office = ''

        allocated_status = JobStatus.objects.get(
            job_status_description='Allocated'
            )
        job_status = cleaned_data.get("job_status")
        job_type = cleaned_data.get("job_type")
        payment_status = cleaned_data.get("payment_status")
        completed_date = cleaned_data.get("completed_date")
        cleaning_method = cleaned_data.get("cleaning_method")
        wc = cleaned_data.get("window_cleaner")
        allocated_date = cleaned_data.get("allocated_date")
        customer_reminder = cleaned_data.get("customer_reminder")
        money_type = cleaned_data.get("money_type")
        bank_transfer_to = cleaned_data.get("bank_transfer_to")
        job_cycle_current = cleaned_data.get("job_cycle_current")
        price_on_day = cleaned_data.get("price_on_day")
        owes = cleaned_data.get("owes")
        set_price = cleaned_data.get('set_price')
        job_task = cleaned_data.get('job_task')
        access = cleaned_data.get('access')
        access_notes = cleaned_data.get('access_notes')
        job_status_btn = cleaned_data.get('job_status_btn')

        selected_job_status = JobStatus.objects.get(job_status_description=str(job_status))
        
        if set_price is None:
            self.cleaned_data['set_price'] = 0.0

        if job_status_btn == 'check_in_job':
            if job_task is None:
                self.add_error(
                    "job_task",
                    ""
                    "This field is required."
                )
            if access is None:
                self.add_error(
                    "access",
                    ""
                    "This field is required."
                )
            if money_type == 'Direct BT to WC' and bank_transfer_to is None:
                self.add_error(
                    "bank_transfer_to",
                    ""
                    "This field is required."
                )

        if access is not None:
            if access.requires_secondary_input and access_notes == '':
                self.add_error(
                    'access_notes',''
                )

        
        if job_status_btn == 'book_first_job':

            if str(job_status) != 'Booked':
                self.add_error(
                    "job_status",
                    ""
                    "Job status should be 'Booked' please change job status."
                )

        if job_status_btn == 'save_customer':
            if str(job_status) != 'Due':
                self.add_error(
                    "job_status",
                    ""
                    "Job status should be 'Due' please change job status."
                )
        self.cleaned_data['vat_flag'] = VATFlags.ADDED
        # price entered on form includes VAT
        if self.cleaned_data['set_price'] != 0.0 and self.cleaned_data['set_price'] is not None:
            franchise = get_user_franchise(self.request.user, self.request)
            today = datetime.datetime.today()
            vat_applied, vat_rate, vat_reg_number, show_breakdown = get_vat(franchise, today)
            if vat_applied:                 
                self.instance.base_set_price = self.cleaned_data['set_price'] / (1+vat_rate/100)
                self.instance.set_price_vat = self.cleaned_data['set_price'] - self.instance.base_set_price  
                self.cleaned_data['set_price'] = self.instance.base_set_price
                pass
            else:
                self.instance.base_set_price = self.cleaned_data['set_price']
                self.instance.set_price_vat = 0.0
        else:
            self.instance.base_set_price = 0.0
            self.instance.set_price_vat = 0.0

    def __init__(self, request, user, action, *args, **kwargs):
        self.user = kwargs.pop('user', None)
        franchise = get_user_franchise(user,request)
        self.request = request
        wc_id = None
        if kwargs.get('initial', None):
            wc_id = kwargs['initial']['wc_id']

        super(FirstJobForm, self).__init__(*args, **kwargs)
        self.fields['bank_transfer_to'].queryset = WindowCleaner.objects.filter(
            franchise=franchise,
            user__groups__name__in=['window_cleaner'],
            user__is_active=True
        )
        access_method_data = AccessMethod.objects.all().order_by('order')
        self.fields['access'].queryset = access_method_data
        money_type_data = MoneyType.objects.all().order_by('order')
        self.fields['money_type'].queryset = money_type_data
        # wc_data = WindowCleaner.objects.filter(user__is_active=1, user__groups__name='window_cleaner')
        # self.fields['bank_transfer_to'].queryset = wc_data
        if (wc_id is not None):
            self.fields['window_cleaner'].initial = wc_id
        self.fields['job_task'].required =False
        self.fields['access'].required =False
        self.fields['money_type'].required = False
        self.fields['cleaning_method'].empty_label = 'Cleaning method'
        self.fields['job_type'].empty_label = 'Job Type'
        self.fields['access'].empty_label = 'IF Out'
        self.fields['money_type'].empty_label = 'Money Type **'
        self.fields['window_cleaner'].empty_label = 'Window Cleaner'
        self.fields['job_status'].empty_label = None
        self.fields['time_needed'].required =False
        self.fields['set_price'].required =False
        # self.fields['set_price'].initial = 0
        self.fields['action_on_check_in'].required = True
        self.fields['job_type'].required = True
        self.fields['cleaning_method'].required = True
        self.fields['job_status'].required = True
        self.fields['vat_flag'].required = False
        if self.errors:
            for f_name in self.fields:
                if f_name in self.errors:
                    classes = self.fields[f_name].widget.attrs.get('class', '')
                    classes += ' form-error'
                    self.fields[f_name].widget.attrs['class'] = classes

        self.fields['action_on_check_in'].initial = 'WC new, full setup'
        self.fields['customer_reminder_note'].initial = 'asked WC'
        self.fields['customer_reminder'].initial = 4
        self.fields['job_type'].initial = 4
        self.fields['cleaning_method'].initial = 8
        self.fields['vat_flag'].initial = VATFlags.ADDED


class ImportedCustomerForm(ModelForm):
    class Meta:
        model = ImportedCustomer
        fields = '__all__'


from django import forms
import phonenumbers
from django.core.exceptions import ValidationError
from django.core.validators import validate_email

from customers.models import TITLE_CHOICES

class CustomerFullEnquiryForm(forms.Form):
    
    TITLE_CHOICES= [
        ('', 'Select a title'),
        ('Dr.', 'Dr.'),
        ('Mr.', 'Mr.'),
        ('Mrs.', 'Mrs.'),
        ('Ms.', 'Ms.'),
        ('Miss', 'Miss'),
        ('Rev.', 'Rev.'),
        ('Other', 'Other'),
    ]

    PROPERTY_TYPE_CHOICES= [
        ('', 'Select a property type'),
        ('HOUSE', 'House'),
        ('FLAT', 'Flat/maisonnette'),
        ('MAISONNETTE', 'Maisonnette'),
        ('COMMERCIAL', 'Commercial'),
        ('OTHER', 'Other'),
        
    ]

    HOUSE_TYPE_CHOICES= [
        ('', 'Select a house type'),
        ('DETACHED', 'Detached'),
        ('SEMI-DETACHED', 'Semi-detached'),
        ('TERRACED', 'Terraced'),
        ('END_OF_TERRACE', 'End of Terrace'),
        ('BUNGALOW', 'Bungalow'),
        ('OTHER', 'Other'),
    ]

    FLAT_TYPE_CHOICES= [
        ('', 'Select a flat type'),
        ('GROUND_FLOOR', 'Ground floor'),
        ('FIRST_FLOOR', 'First floor'),
        ('SECOND_FLOOR', 'Second floor'),
        ('OTHER', 'Other'),
    ]

    COMMERCIAL_TYPE_CHOICES= [
        ('', 'Select a commercial type'),
        ('OFFICES', 'Offices'),
        ('APPARTMENT_BLOCK', 'Appartment block'),
        ('SHOP', 'Shop'),
        ('OTHER', 'Other'),
    ]


    HOW_SOON_CHOICES = [
        ('ASAP', 'As soon as possible'),
        ('NO_RUSH', 'No rush'),
    ]

    HOW_OFTEN_CHOICES = [
        ('4_WEEKLY', '4 weekly (best value)'),
        ('8_WEEKLY', '8 weekly'),
        ('OTHER', 'Other'),

    ]

    BUSINESS_SOURCE_CHOICES= [        
        ('GOOGLE', 'Google'),
        ('LEAFLET', 'Leaflet'),
        ('FACEBOOK', 'Facebook'),
        ('SEEN_OUR_VAN', 'Seen our van'),
        ('RECOMMENDATION', 'Recommendation'),
        ('OTHER', 'Other'),
    ]

    # tab 1    
    building_number = forms.CharField(max_length=10,widget = forms.HiddenInput(), required = False)
    building_name = forms.CharField(max_length=100,widget = forms.HiddenInput(), required = False)
    sub_building_name = forms.CharField(max_length=100,widget = forms.HiddenInput(), required = False)
    county = forms.CharField(max_length=100,widget = forms.HiddenInput(), required = False)
    postcode_outward = forms.CharField(max_length=10,widget = forms.HiddenInput(), required = False)
    postcode_inward = forms.CharField(max_length=10,widget = forms.HiddenInput(), required = False)
    organisation_name = forms.CharField(max_length=100,widget = forms.HiddenInput(), required = False)
    longitude = forms.CharField(max_length=100,widget = forms.HiddenInput(), required = False)
    latitude = forms.CharField(max_length=100,widget = forms.HiddenInput(), required = False)
    udprn = forms.CharField(max_length=100,widget = forms.HiddenInput(), required = False)
    address_line_1 = forms.CharField(max_length=100, required = True)
    address_line_2 = forms.CharField(max_length=100, required = False)
    address_line_3 = forms.CharField(max_length=100, required = False)
    post_town = forms.CharField(max_length=100)
    postcode = forms.CharField(max_length=100)
    thoroughfare = forms.CharField(max_length=100, widget = forms.HiddenInput(), required = False)
    property_type = forms.ChoiceField(choices=PROPERTY_TYPE_CHOICES, required = False)
    property_type_other = forms.CharField(
        max_length=100,
        required = False,
        widget=forms.TextInput(attrs={'placeholder': 'Please enter the type of property...'})
        )
    # tab 2
    title = forms.CharField(widget=forms.Select(choices=TITLE_CHOICES))
    title_other = forms.CharField(
        max_length=30,
        required = False,
        widget=forms.TextInput(attrs={'placeholder': 'Please enter your preferred title...'})
        )
    first_name = forms.CharField(max_length=50, required = False)
    last_name = forms.CharField(max_length=25, required = True)
    email = forms.CharField(max_length=125, required = True)
    mobile = forms.CharField(max_length=125, required = False)
    landline = forms.CharField(max_length=125, required = False, label='Alternate contact number')
    # tab 3
    outside_windows = forms.BooleanField(required = False)
    inside_windows = forms.BooleanField(required = False)
    conservatory = forms.BooleanField(required = False)
    gutter_clearance = forms.BooleanField(required = False, label='Gutter clearance/cleaning')
    patio_driveway_cleaning = forms.BooleanField(required = False, label='Patio/driveway cleaning')
    cleaning_other = forms.BooleanField(required = False)
    cleaning_other_text = forms.CharField(
        max_length=200,
        required = False,
        widget=forms.TextInput(attrs={'placeholder': 'Please enter what work you require...'})
        )
    when_do_you_need_the_work_done_by = forms.ChoiceField(
        choices=HOW_SOON_CHOICES,
        required = False,
        widget=forms.RadioSelect
        )
    where_did_you_hear = forms.ChoiceField(
        choices=BUSINESS_SOURCE_CHOICES,
        required = False,
        widget=forms.RadioSelect
    )
    where_did_you_hear_other = forms.CharField(
        required=False,
        max_length=200,
        widget=forms.TextInput(attrs={'placeholder': 'Please enter where you heard from us...'})
        )
    house_type = forms.ChoiceField(choices=HOUSE_TYPE_CHOICES, required = False)
    house_type_other = forms.CharField(
        required=False,
        max_length=100,
        widget=forms.TextInput(attrs={'placeholder': 'Please enter your type of house...'})
        )
    flat_type = forms.ChoiceField(choices=FLAT_TYPE_CHOICES, required = False)
    flat_type_other = forms.CharField(
        required=False,
        max_length=200,
        widget=forms.TextInput(attrs={'placeholder': 'Please enter the flat type...'})
        )
    commercial_type = forms.ChoiceField(choices=COMMERCIAL_TYPE_CHOICES, required = False)
    commercial_other = forms.CharField(
        required=False,
        max_length=200,
        widget=forms.TextInput(attrs={'placeholder': 'Please enter the type of commercial property...'})
        )
    how_often_other = forms.CharField(
        required=False,
        max_length=200,
        widget=forms.TextInput(attrs={'placeholder': 'Please enter how often you need the work done...'})
        )
    when_last_cleaned = forms.CharField(max_length=100, required = False)
    how_often = forms.ChoiceField(choices=HOW_OFTEN_CHOICES, required = False)


    def clean(self):
        cleaned_data = super().clean()
        mobile = cleaned_data.get("mobile")
        landline = cleaned_data.get("landline")
        email = cleaned_data.get("email")
        
        if mobile!='':
            try:
                n = phonenumbers.parse(mobile, 'GB')
                if not phonenumbers.is_valid_number(n):
                    self.add_error(
                        'mobile',
                        'Please enter a valid phone number'
                    )
            except phonenumbers.NumberParseException:
                self.add_error(
                        'mobile',
                        'Please enter a valid UK mobile number'
                    )
        if landline != '':
            try:
                n = phonenumbers.parse(landline, 'GB')
                if not phonenumbers.is_valid_number(n):
                    self.add_error(
                        'landline',
                        'Please enter a valid phone number'
                    )
            except phonenumbers.NumberParseException:
                self.add_error(
                        'landline',
                        'Please enter a valid UK phone number'
                    )  

        try:
            validate_email(email)
        except ValidationError as e:
            self.add_error(
                'email',
                'Please enter a valid email address'
            )
class CustomerQuickAddForm(forms.Form):
    pass
    