# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from customers.models import WCNewCustomer
from braces.views import GroupRequiredMixin
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import ListView, View
from django.db.models import Q
from django.contrib.auth import login
from django.shortcuts import redirect
from accounts.models import User


class UserImpersonate(View):
    def post(self, request, *args, **kwargs):
        impersonate_user = request.POST['impersonate_select']
        switch_test_on_off = request.POST['switch_test_on_off']
        
        user = self.request.user.id
        impersonate_arr = []
        franchisor_data_display, franchisor_data_values = False, None
        if 'impersonate_arr' in request.session:
            impersonate_arr = request.session['impersonate_arr']

        user_groups = request.user.groups.all().values_list('name', flat=True)

        if 'franchisor' in user_groups or 'customer_care' in user_groups:
            if 'franchisor_data_display' in request.session:
                if request.session['franchisor_data_display'] == True:
                    franchisor_data_display = True
                    franchisor_data_values = request.session['franchisor_data_values']
        if impersonate_user is None or impersonate_user == '':
            return redirect('login') 
        users_data = User.objects.get(id=impersonate_user)
        login(request, users_data)
        if impersonate_arr is not None:
            request.session['impersonate_arr'] = impersonate_arr

        if 'impersonate_arr' not in request.session:
            request.session['impersonate_arr'] = []
        if franchisor_data_display == True:
            request.session['franchisor_data_display'] = True            
            request.session['franchisor_data_values'] = franchisor_data_values

        request.session['impersonate_arr'].append(user)
        groups = request.user.groups.all().values_list('name', flat=True)
        http_referrer = request.META.get('HTTP_REFERER', '/')

        request.session['switch_test_on_off'] = switch_test_on_off

        request.session['which_user_group_logged_in'] = ''
        if 'franchisor' in groups:
            if not http_referrer:
                return redirect("franchisor_dashboard")
            else:
                return redirect(http_referrer)
        elif'customer_care' in groups:
            if not http_referrer:
                return redirect("customer_care_dashboard")
            else:
                return redirect(http_referrer)
        elif 'franchise_admin' in groups:
            request.session['which_user_group_logged_in'] = 'franchise_admin'
            if 'window_cleaner' in groups:
                request.session['which_user_group_logged_in'] = 'window_cleaner'
                return redirect("wc_summary")
            else:
                if not http_referrer:
                    return redirect("franchisor_dashboard")
                else:
                    return redirect(http_referrer)
        elif 'franchisee' in groups:
            request.session['which_user_group_logged_in'] = 'franchisee'
            if 'window_cleaner' in groups and not 'franchisor_data_values' in request.session:
                request.session['which_user_group_logged_in'] = 'window_cleaner'
                return redirect("wc_summary")
            else:
                if (len(impersonate_arr) == 2):
                    request.session['which_user_group_logged_in'] = 'window_cleaner'
                    return redirect("wc_summary")
                else:
                    if not http_referrer:
                        return redirect("dashboard")
                    else:
                        return redirect(http_referrer)
        else:            
            if not http_referrer:
                return redirect("wc_summary")
            else:
                return redirect('wc_summary')

class UserImpersonateLogout(View):
    def get(self, request, *args, **kwargs):
        user = self.request.user.id
        impersonate_arr = []
        franchisor_data_display, franchisor_data_values = False, None
        switch_test_on_off = request.GET.get('switch_test_on_off')
        try:
            if 'impersonate_arr' in request.session:

                imp_session_len = len(request.session['impersonate_arr'])
                if imp_session_len > 0:
                    user_id = request.session['impersonate_arr'][imp_session_len - 1]
                    del request.session['impersonate_arr'][imp_session_len - 1]
                    users_data = User.objects.get(id=user_id)
                    impersonate_arr = request.session['impersonate_arr']

                    user_groups = request.user.groups.all().values_list('name', flat=True)
                    if 'franchisor_data_display' in request.session:
                        if request.session['franchisor_data_display'] == True:
                            franchisor_data_display = True
                            franchisor_data_values = request.session['franchisor_data_values']


                    login(request, users_data)
                    if impersonate_arr is not None:
                        request.session['impersonate_arr'] = impersonate_arr
                    if franchisor_data_display == True:
                        request.session['franchisor_data_display'] = True
                        request.session['franchisor_data_values'] = franchisor_data_values

                    request.session['switch_test_on_off'] = switch_test_on_off
        except User.DoesNotExist:
            pass
                
        http_referrer = request.META.get('HTTP_REFERER', '/')
        groups = request.user.groups.all().values_list('name', flat=True)


        if 'franchisor' in groups or 'customer_care' in groups:
            if not http_referrer or len(impersonate_arr) == 0:
                if 'franchisor_data_values' in request.session and request.session['franchisor_data_values'] is not None:                    
                    request.session['which_user_group_logged_in'] = 'franchisee'
                    return redirect("dashboard")
                else:
                    if 'franchisor' in groups:
                        request.session['which_user_group_logged_in'] = 'franchisor'
                        return redirect("franchisor_dashboard")
                    else:
                        request.session['which_user_group_logged_in'] = 'customer_care'
                        return redirect("customer_care_dashboard")
            else:
                return redirect(http_referrer)
        elif 'franchise_admin' in groups:
            request.session['which_user_group_logged_in'] = 'franchise_admin'
            if not http_referrer or len(impersonate_arr) == 0:
                return redirect("franchisor_dashboard")
            else:
                return redirect(http_referrer)
        elif 'franchisee' in groups:
            request.session['which_user_group_logged_in'] = 'franchisee'
            if not http_referrer or len(impersonate_arr) == 0:
                return redirect("dashboard")
            elif not http_referrer or len(impersonate_arr) == 1:
                return redirect("dashboard")
            else:
                return redirect(http_referrer)
        else:
            request.session['which_user_group_logged_in'] = 'window_cleaner'
            if not http_referrer or len(impersonate_arr) == 0:
                return redirect("wc_summary")
            else:
                return redirect(http_referrer)




class ShowFilterFranchiserData(View):
    def post(self, request, *args, **kwargs):
        franchisor_data_value = request.POST['franchiser_data_select']
        request.session['franchisor_data_values'] = franchisor_data_value
        if franchisor_data_value == '0':
            request.session['user_franchise_id'] = None
        else:
            request.session['user_franchise_id'] = franchisor_data_value
        request.session['franchisor_data_display'] = True
        groups = request.user.groups.all().values_list('name', flat=True)
        http_referrer = request.META.get('HTTP_REFERER', '/')
        logged_user = request.user
        
        if 'franchisor' in groups or 'customer_care' in groups:

            if 'customer_care' in groups:
                logged_user.customercare.timer_active = False
                logged_user.customercare.timer_category_id = None
                logged_user.customercare.franchise = None
                logged_user.customercare.save()

            if not http_referrer:
                if 'franchisor' in groups:
                    return redirect("franchisor_dashboard")
                else:
                   return redirect("customer_care_dashboard") 
            else:
                if int(request.session['franchisor_data_values']) != 0:
                    if 'franchisor_dashboard' in http_referrer or 'customer_care_dashboard' in http_referrer:
                        return redirect("dashboard")
                    else:
                        return redirect(http_referrer)
                else:
                    if 'franchisor' in groups:
                        return redirect("franchisor_dashboard")
                    else:
                        return redirect("customer_care_dashboard")
        elif 'franchise_admin' in groups:
            if not http_referrer:
                return redirect("franchisor_dashboard")
            else:
                return redirect(http_referrer)
        elif 'franchisee' in groups:
            if not http_referrer:
                return redirect("dashboard")
            else:
                return redirect(http_referrer)
        else:
            if not http_referrer:
                return redirect("wc_summary")
            else:
                return redirect(http_referrer)

""" def get_current_user():
    return _user_object """

class ImpersonateLogin(GroupRequiredMixin, LoginRequiredMixin, ListView):
    """ lists new customers WCs have entered """

    model = WCNewCustomer
    context_object_name = 'customers'
    template_name = 'wc_new_customer_list.html'
    paginate_by = 10
    # TODO: filter for franchise
    def get(self, request, *args, **kwargs):
        user = self.request.user
        self.queryset = WCNewCustomer.objects.filter(
            added_by=user
        )
        return super(WCNewCustomersList, self).get(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        """ filtered results """
        user = self.request.user
        try:
            if request.POST['action'] == 'filter':
                txt = request.POST['input_search']
                self.queryset = WCNewCustomer.objects.filter(
                    Q(address_line_1__icontains=txt) |
                    Q(first_name__icontains=txt) |
                    Q(last_name__icontains=txt) |
                    Q(title__icontains=txt),
                    added_by=user
                )
            else:
                self.queryset = WCNewCustomer.objects.filter(added_by=user)
        except KeyError:
            # empty or incomplete POST key dict: return all records
            self.queryset = WCNewCustomer.objects.filter(franchise=franchise)
        return super(WCNewCustomersList, self).get(request, *args, **kwargs)

    group_required = [u"window_cleaner"]