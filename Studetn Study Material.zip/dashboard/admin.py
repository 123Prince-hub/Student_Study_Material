from django.contrib import admin
from dashboard.models import *

# Register your models here.
#  ****************************  Admin Configrations for Notes   ********************************
@admin.register(Notes)
class NotesModelAdmin(admin.ModelAdmin):
    list_display = [field.name for field in Notes._meta.get_fields()]
    # list_display = ["id", "title", "desc", "created_at", "updated_at"]




#  ****************************  Admin Configrations for Homework   ********************************
@admin.register(Homework)
class HomeworkModelAdmin(admin.ModelAdmin):
    list_display = [field.name for field in Homework._meta.get_fields()]




#  ****************************  Admin Configrations for Todo   ********************************
@admin.register(Todo)
class TodokModelAdmin(admin.ModelAdmin):
    list_display = [field.name for field in Todo._meta.get_fields()]
