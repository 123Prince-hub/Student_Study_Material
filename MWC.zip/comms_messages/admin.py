
# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from .models import (
    ManualMessageTemplate, Message, Email, SMS, UnactionedMessage, ManualMessageTemplateCategory,
    AutoChaserMessageTemplate, PriceIncreaseTemplate, AddVATTemplate
)
from simple_history.admin import SimpleHistoryAdmin


class ManualMessageTemplateAdmin(admin.ModelAdmin):
    list_display = [
        'message_type',
        'title',
        'subject',
        'type_of_email',
        'manual_message_template_category',
        'order'
        ]
    save_as = True
    search_fields = ['title', 'subject','sms_template', 'email_template']
    list_filter = ('type_of_email', 'manual_message_template_category')
    ordering = ['type_of_email', 'order', 'title']


class SMSInline(admin.TabularInline):
    model = SMS


class EmailInline(admin.TabularInline):
    model = Email


class MessageAdmin(SimpleHistoryAdmin):
    inlines = [
        SMSInline, EmailInline
    ]
    list_display = [
        'get_message_type_display',
        'outgoing',
        'date_time',
        'from_num_email',
        'to_num_email',
    ]

    list_select_related = ['email', 'sms', 'customer', 'user']
    list_filter = ('franchise', 'outgoing', 'message_type', 'email__mailgun_message_status')
    ordering = ['-received_time', '-sent_time']
    search_fields = [
        'sms__from_number',
        'sms__to_number',
        'email__recipients',
        'email__from_text',
        'email__sender',
        ]


class ManualMessageTemplateCategoryAdmin(admin.ModelAdmin):
    list_display = [
        'category',
        'order'
        ]
    ordering = ['order', 'category']

class AutoChaserMessageTemplateAdmin(admin.ModelAdmin):
    list_display = [
        'title',
        'chaser_number',
        'send_both_email_and_sms',
    ]

class PriceIncreaseTemplateAdmin(admin.ModelAdmin):
    list_display = [
        'title', 'order'
    ]    

class AddVATTemplateAdmin(admin.ModelAdmin):
    list_display = [
        'title', 'order'
    ]

admin.site.register(
    AutoChaserMessageTemplate, AutoChaserMessageTemplateAdmin
)
admin.site.register(
    ManualMessageTemplate, ManualMessageTemplateAdmin
)
admin.site.register(
    Message, MessageAdmin
)
admin.site.register(
    UnactionedMessage
)
admin.site.register(
    ManualMessageTemplateCategory, ManualMessageTemplateCategoryAdmin
)
admin.site.register(
    PriceIncreaseTemplate, PriceIncreaseTemplateAdmin
)
admin.site.register(
    AddVATTemplate, AddVATTemplateAdmin
)