# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.contrib import admin
from .models import (
    Customer, PropertyType, FrequencyChoice, BusinessSource,
    BookWithChoice, AlternateTimeSlot,
    DefaultTimeSlot, OtherQuote, WCNewCustomer,
    OtherQuotesTask, PropertyTypeCategory,
    BusinessSourceCanvasser, BusinessSourceInternet,
    BusinessSourceLocalMagazine, BusinessSourceLocalAdBoard,
    BusinessSourceDirectory, BusinessSourceLeaflet, CommercialList, IsInactiveReason,
    NewCustomerOtherQuote, BusinessSourceLocalFacebook, CustomerReview, BusinessSourceSponsorship,
    BusinessSourceDigitalMagazine, CustomerWebsiteEnquiry

)
from simple_history.admin import SimpleHistoryAdmin


class BusinessSourceAdmin(admin.ModelAdmin):
    list_display = ['business_source', 'paid_for', 'order']


class OtherQuotesTaskAdmin(admin.ModelAdmin):
    list_display = ['job_task', 'order']


class NewCustomerOtherQuoteInline(admin.TabularInline):
    model = NewCustomerOtherQuote
    extra = 1


class WCNewCustomerAdmin(admin.ModelAdmin):
    search_fields = ['address_line_1']
    inlines = (NewCustomerOtherQuoteInline,)


class OtherQuoteInline(admin.TabularInline):
    model = OtherQuote
    extra = 1


class CustomerAdmin(SimpleHistoryAdmin):
    search_fields = [
        'first_name',
        'last_name',
        'address_line_1',
        'address_line_2',
        'postcode',
        'booking_road__booking_road'
        ]
    list_display = [
        '__str__',
        'last_name',
        'is_inactive',
        ]
    list_filter = ('is_inactive', 'booking_road__area__franchise')
    inlines = (OtherQuoteInline,)

    list_select_related = True
    autocomplete_fields = [
        'business_source_window_cleaner',
        'business_source_canvasser',
        'bank_transfer_to_default',
        'bank_transfer_to_alt',        
        'booking_road',
        'set_up_by',
        'business_source_recommendation_customer',
        'business_source_existing_customer']

    def get_queryset(self, request):
        return super(CustomerAdmin, self).get_queryset(request).select_related(
            'business_source_window_cleaner__user',
            'business_source_canvasser__user',
            'bank_transfer_to_default__user',
            'bank_transfer_to_alt__user',
            'booking_road__area__franchise',
            'booking_road',
            'set_up_by',
            ).prefetch_related('other_quotes')


class IsInactiveReasonAdmin(admin.ModelAdmin):
    list_display = ['reason', 'order']


class CommercialListAdmin(admin.ModelAdmin):
    list_display = ['list_name', 'company_name', 'franchise', 'payment_terms', 'invoice_frequency']
    list_filter = ('franchise',)
    search_fields = ['list_name', 'company_name']


class BusinessSourceInternetAdmin(admin.ModelAdmin):
    list_display = ['internet', 'paid_for', 'order']
    list_filter = ('franchise', 'paid_for')


class BusinessSourceLocalMagazineAdmin(admin.ModelAdmin):
    list_display = ['magazine', 'paid_for', 'order']
    list_filter = ('franchise', 'paid_for')


class BusinessSourceLocalAdBoardAdmin(admin.ModelAdmin):
    list_display = ['ad_board', 'paid_for', 'order']
    list_filter = ('franchise', 'paid_for')


class BusinessSourceDirectoryAdmin(admin.ModelAdmin):
    list_display = ['directory', 'paid_for', 'order']
    list_filter = ('franchise', 'paid_for')


class BusinessSourceLeafletAdmin(admin.ModelAdmin):
    list_display = ['leaflet', 'paid_for', 'order']
    list_filter = ('franchise', 'paid_for')


class BusinessSourceLocalFacebookAdmin(admin.ModelAdmin):
    list_display = ['local_facebook', 'paid_for', 'order']
    list_filter = ('franchise', 'paid_for')


class BusinessSourceDigitalMagazineAdmin(admin.ModelAdmin):
    list_display = ['magazine', 'paid_for', 'order']
    list_filter = ('franchise', 'paid_for')


class BusinessSourceSponsorshipAdmin(admin.ModelAdmin):
    list_display = ['sponsor', 'paid_for', 'order']
    list_filter = ('franchise', 'paid_for')


class PropertyTypeAdmin(admin.ModelAdmin):
    list_display = ['property_type', 'abbreviation', 'category', 'order']
    list_filter = ('category',)


class CustomerReviewAdmin(admin.ModelAdmin):
    list_display = ['email', 'customer', 'stars', 'date_created',]
    search_fields = ['customer', 'email']
    list_filter = ['stars', 'customer__booking_road__area__franchise']
    date_hierarchy = 'date_created'
    list_select_related = True
    autocomplete_fields = ['customer']


class CustomerWebsiteEnquiryAdmin(admin.ModelAdmin):
    list_display = ['date_created', 'ip_address', 'last_modified','get_franchise']
    list_filter = ['customer__booking_road__area__franchise',]
    list_select_related = True
    date_hierarchy = 'date_created'
    search_fields = ['customer',]
    autocomplete_fields = ['customer']

    def get_franchise(self, obj):
        try: 
            return obj.customer.booking_road.area.franchise
        except AttributeError:
            return None
    get_franchise.short_description = 'Franchise'
    get_franchise.admin_order_field = 'customer__booking_road__area__franchise'


admin.site.register(Customer, CustomerAdmin)
admin.site.register(WCNewCustomer, WCNewCustomerAdmin)
admin.site.register(PropertyType, PropertyTypeAdmin)
admin.site.register(PropertyTypeCategory)
admin.site.register(FrequencyChoice)
admin.site.register(BusinessSource, BusinessSourceAdmin)
admin.site.register(BookWithChoice)
admin.site.register(DefaultTimeSlot)
admin.site.register(AlternateTimeSlot)
admin.site.register(OtherQuote)
admin.site.register(BusinessSourceCanvasser)
admin.site.register(BusinessSourceInternet, BusinessSourceInternetAdmin)
admin.site.register(BusinessSourceLocalMagazine, BusinessSourceLocalMagazineAdmin)
admin.site.register(BusinessSourceLocalAdBoard, BusinessSourceLocalAdBoardAdmin)
admin.site.register(BusinessSourceDirectory, BusinessSourceDirectoryAdmin)
admin.site.register(BusinessSourceLeaflet, BusinessSourceLeafletAdmin)
admin.site.register(BusinessSourceLocalFacebook, BusinessSourceLocalFacebookAdmin)
admin.site.register(BusinessSourceDigitalMagazine, BusinessSourceDigitalMagazineAdmin)
admin.site.register(BusinessSourceSponsorship, BusinessSourceSponsorshipAdmin)
admin.site.register(OtherQuotesTask, OtherQuotesTaskAdmin)
admin.site.register(CommercialList, CommercialListAdmin)
admin.site.register(IsInactiveReason, IsInactiveReasonAdmin)
admin.site.register(CustomerReview, CustomerReviewAdmin)
admin.site.register(CustomerWebsiteEnquiry, CustomerWebsiteEnquiryAdmin)
