from django.conf.urls import url
from django.urls import path

from .views import *
from office.views import is_address_exist


urlpatterns = [
    url(r'wc_customers/$',
        WCNewCustomersList.as_view(),
        name='wc_customer_list'
        ),
    url(r'wc_customers/new/$',
        WCCustomerCreate.as_view(),
        name='wc_customer_add'
        ),
    url(r'wc_customers/summary/$',
        WCNewCustomerSummary.as_view(),
        name='wc_new_customer_summary'
        ),
    url(r'new_customers/$',
        NewCustomer.as_view(),
        name='wc_new_customers'
        ),
    url(r'detail/(?P<pk>[0-9]+)$',
        CustomerDetail.as_view(),
        name='detail'
        ),
    url(r'manual-invoice/(?P<pk>[0-9]+)$',
        CustomerManualInvoice.as_view(),
        name='cust_manual_invoice'
        ),
    url(r'manual-invoice-preview-send$',
        ManualInvoicePreviewAndSend.as_view(),
        name='manual_invoice_preview_send'
        ),
    url(r'^detail/(?P<pk>[0-9]+)/(?P<jobid>[0-9]+)$',
        CustomerDetail.as_view(), name='detail_jobid'),


    url(r'^detail/$',
        CustomerDetail.as_view(), name='detail'),
    url(r'add-customer/$',
        CustomerAdd.as_view(),
        name='add_customer'
        ),
    url(r'download_attachment/$',
        download_attachment,
        name='download_attachment'
        ),
    # url(r'wc_customers/(?P<pk>[0-9]+)/$',
    #     WCCustomerUpdate.as_view(),
    #     name='wc_customer_update'
    #     ),
    url(r'wc_customers/(?P<pk>[0-9]+)/delete/$',
        WCCustomerDelete.as_view(),
        name='wc_customer_delete'),
    path(
        'wc_customers/<int:year>/<int:month>/',
        WCNewCustomersList.as_view(),
        name='wc_customer_list_monthly'
    ),
    url(r'quick_add/$',
        CustomerQuickAdd.as_view(),
        name='customer_quick_add'),

    url(regex=r'^is-address-exist',
        view=is_address_exist,
        name='is_address_exist'
    ),
    url(regex=r'^area_booking_road',
        view=area_booking_road,
        name='area_booking_road'
    ),
    url(r'^customer_quick_add_post/$',
        CustomerQuickAddPost.as_view(), name='customer_quick_add_post'),

    url(r'^customers/update/$',
       CustomerUpdateStatus, name='customer_status_update'),
    # ------------------------------------------ -
    url(r'^customer-job-history/(?P<pk>[0-9]+)/$',
        JobHistory.as_view(),
        name='customer-job-history'),
    url(
        regex=r'^update_job_from_job_history/$',
        view=updateJobFromJobHistory,
        name='update_job_from_job_history'
    ),
    url(
        regex=r'^get_customer_credititems_list/$',
        view=get_customer_credititems_list,
        name='get_customer_credititems_list'
    ),
    url(
        regex = r'^set_default_alt_job_time_slot/$',
        view = set_default_alt_job_time_slot,
        name = 'set_default_alt_job_time_slot'
    ),
    url(r'^check_date_availability/(?P<form_type>\w+)/$', check_date_availability, name='check_date_availability'),
    url(regex=r'^add_booking_road',
        view=add_booking_road,
        name='add_booking_road'
    ),
    url(regex=r'^add_commercial_list',
        view=add_commercial_list,
        name='add_commercial_list'
    ),
    url(regex=r'^update_customer_name_address',
        view=update_customer_name_address,
        name='update_customer_name_address'
    ),
    url(regex=r'^tnc-mail-send',
        view=tnc_mail_send,
        name='tnc-mail-send'
    ),
    url(r'canv-summary/$',
        CanvLandingPage.as_view(),
         name='canv_summary'
    ),
    url(r'get_users_list_based_on_req/$',
        GetUsersListBasedOnReq.as_view(),
        name= 'get_users_list_based_on_req'
    ),
    # IMPORTS ============================
    url(r'imported_customers/$',
        ImportedCustomersView.as_view(),
        name= 'imported_customers'
    ),
    url(r'website_enquiry_customers/$',
        WebsiteEnquiryCustomersView.as_view(),
        name= 'website_enquiry_customers'
    ),
    url(r'get-set-website-enquiry-notes/$',
        GetSetWebsiteEnquiryNotes.as_view(),
        name= 'get_set_website_enquiry_notes'
    ),
    url(r'failed-website-enquiries/$',
        FailedWebsiteEnquiries.as_view(),
        name= 'failed_website_enquiries'
    ),
    url(r'save-website-enquiry-customer-address/$',
        SaveWebsiteEnquiryCustomerAddress.as_view(),
        name= 'save_website_enquiry_customer_address'
    ),    
]
