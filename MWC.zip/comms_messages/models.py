# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from datetime import timedelta, datetime
import re, ast


from accounts.models import User, Franchisor
from customers.models import Customer, CommercialList, ImportedCustomer
from jobs.models import MoneyType
from franchises.models import Franchise

from phonenumber_field.modelfields import PhoneNumberField

from taggit.managers import TaggableManager
from ckeditor.fields import RichTextField
from simple_history.models import HistoricalRecords


class Message(models.Model):
    EMAIL_MESSAGE = 1
    SMS_MESSAGE = 2
    EMAIL_SMS_MESSAGE = 3
    # https://www.b-list.org/weblog/2007/nov/02/handle-choices-right-way/
    MESSAGE_TYPE_CHOICES = (
        (EMAIL_MESSAGE, 'Email'),
        (SMS_MESSAGE, 'SMS'),
        (EMAIL_SMS_MESSAGE, 'Email and SMS')
    )
    message_type = models.IntegerField(
        choices=MESSAGE_TYPE_CHOICES, null=False,
        db_index=True
        )
    franchise = models.ForeignKey(
        Franchise,
        on_delete=models.PROTECT,
        null=True,
        blank=True
    )
    franchisor = models.ForeignKey(
        Franchisor,
        on_delete=models.PROTECT,
        null=True,
        blank=True
        )
    customer = models.ForeignKey(
        Customer,
        on_delete=models.PROTECT,
        related_name='messages',
        null=True,
        blank=True
    )
    user = models.ForeignKey(
        User,
        on_delete=models.PROTECT,
        related_name='messages',
        null=True,
        blank=True
    )
    contact = models.ForeignKey(
        'Contact',
        on_delete=models.PROTECT,
        related_name='contacts',
        null=True,
        blank=True
    )
    commercial_list = models.ForeignKey(
        CommercialList,
        on_delete=models.PROTECT,
        related_name='commercial_list',
        null=True,
        blank=True
    )
    outgoing = models.BooleanField(null=False, db_index=True)
    read = models.BooleanField(null=False, default=False)
    actioned = models.BooleanField(null=False, default=False, db_index=True)
    actioned_by = models.ForeignKey(
        User,
        on_delete=models.PROTECT,
        null=True,
        blank=True
    )
    actioned_by_date = models.DateTimeField(null=True, blank=True)
    related_customer = models.ForeignKey(
        Customer,
        on_delete=models.PROTECT,
        related_name='related_customer',
        null=True,
        blank=True
    )
    sent_time = models.DateTimeField(null=True, blank=True, db_index=True)
    received_time = models.DateTimeField(null=True, blank=True, db_index=True)
    old_id = models.IntegerField(null=True, blank=True)
    message_notes = models.CharField(blank=True, max_length=150)
    new_customer_id = models.IntegerField(null=True,blank=True)
    ignore_failure = models.BooleanField(null=False, default=False)
        
    tags = TaggableManager(blank=True)

    history = HistoricalRecords()

    @property
    def _history_user(self):
        return self.changed_by

    @property
    def is_over_24h(self):
        if self.received_time is not None and self.received_time != '':
            return (datetime.now().astimezone() - self.received_time) > timedelta(hours=24)
        else:
            return False

    @_history_user.setter
    def _history_user(self, value):
        self.changed_by = value

    def date_time(self):
        if self.sent_time:
            time = self.sent_time
        else:
            time = self.received_time
        return time

    def message_text(self):
        if hasattr(self, 'email'):
            if self.email.body_html:
                return self.email.body_html
            else:
                return self.email.body_plain
        else:
            return self.sms.message_text

    def from_txt(self):
        if self.customer:
            return self.customer
        elif self.user:
            return self.user
        elif self.contact:
            return self.contact
        else:
            if hasattr(self, 'sms'):
                try:
                    if self.sms.from_number:
                        return self.sms.from_number
                    else:
                        return self.sms.from_text
                except:
                    return None
            else:
                return self.email.sender

    def to_txt(self):
        if self.customer:
            return self.customer
        elif self.user:
            return self.user
        else:
            if hasattr(self, 'sms'):
                return self.sms.to_number
            else:
                return self.email.recipients

    def from_num_email(self):
        if hasattr(self, 'email'):
            return self.email.sender
        elif self.sms.from_number:
            return self.sms.from_number
        else:
            return self.sms.from_text
    from_num_email.short_description = 'From'

    def to_num_email(self):
        if hasattr(self, 'email'):
            recipient_emails = ''
            if self.email.recipients != '[]' and self.email.recipients != '':
                email_recipients = self.email.recipients
                if self.email.recipients.count(r"[") == 1:
                    email_recipients = "["+self.email.recipients+"]"
                elif self.email.recipients.count(r"[") == 0:
                    email_recipients = "[['"+self.email.recipients+"']]"
                email_lists = ast.literal_eval(email_recipients)
                recipient_emails = self.recipients_cc_bcc_formatted_email(email_lists)
            return recipient_emails
        else:
            return self.sms.to_number
    to_num_email.short_description = 'To'

    def cc_emails(self):
        cc_email_return = ''
        if hasattr(self, 'email'):
            if self.email.cc != '[]' and self.email.cc != '':
                cc_emails = self.email.cc
                if self.email.cc.count(r"[") == 1:
                    cc_emails = "["+self.email.cc+"]"
                elif self.email.cc.count(r"[") == 0:
                    cc_emails = "[['"+self.email.cc+"']]"                    
                email_lists = ast.literal_eval(cc_emails)
                cc_email_return = self.recipients_cc_bcc_formatted_email(email_lists)
        return cc_email_return
    cc_emails.short_description = 'CC'

    def bcc_emails(self):
        bcc_email_return = ''
        if hasattr(self, 'email'):
            if self.email.bcc != '[]' and self.email.bcc != '':
                bcc_emails = self.email.bcc
                if self.email.bcc.count(r"[") == 1:
                    bcc_emails = "["+self.email.bcc+"]"
                elif self.email.bcc.count(r"[") == 0:
                    bcc_emails = "[['"+self.email.bcc+"']]"
                email_lists = ast.literal_eval(bcc_emails)
                bcc_email_return = self.recipients_cc_bcc_formatted_email(email_lists)
        return bcc_email_return
    bcc_emails.short_description = 'BCC'

    def cc_email_lists(self):
        cc_email_return = ''
        if hasattr(self, 'email'):
            if self.email.cc != '[]' and self.email.cc != '':
                cc_emails = self.email.cc
                if self.email.cc.count(r"[") == 1:
                    cc_emails = "["+self.email.cc+"]"
                elif self.email.cc.count(r"[") == 0:
                    cc_emails = "[['"+self.email.cc+"']]"
                email_lists = ast.literal_eval(cc_emails)
                cc_email_return = self.recipients_cc_bcc_formatted_email(email_lists,True)
        return cc_email_return

    def recipients_cc_bcc_formatted_email(self,email_lists,is_only_email=False):
        email_regex = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        new_top_list = []
        for emails in email_lists:
            new_list = []
            for email in emails:
                if is_only_email:
                    formatted_emails = email if re.fullmatch(email_regex, email) else ''
                    new_list.append(formatted_emails)                    
                else:
                    if len(emails) > 1:
                        formatted_emails = ' <'+email.strip()+'>' if re.fullmatch(email_regex, email) else email.replace(',','')
                    else:
                        formatted_emails = email.replace(',','')
                    new_list.append(formatted_emails)
                    new_list = re.sub(r",", " ", str(new_list))
                    new_list = ast.literal_eval(new_list)
                new_list = list(filter(None, new_list))
            new_top_list.append(new_list)

        email_return = re.sub(r"['\[]", "", str(new_top_list))
        email_return = re.sub(r"['\]]", "", email_return)
        return email_return

    def message_user_type(self):
        if self.customer:
            return 'customer'
        elif self.user:
            return 'user'
        elif self.contact:
            return 'contact'
        else:
            return 'other'

    """ def message_type(self):
        if hasattr(self, 'email'):
            return'email'
        else:
            return 'sms' """

    def __str__(self):
        if self.received_time:
            time = self.received_time
        else:
            time = self.sent_time

        return time.strftime('%d/%m/%Y %H:%M:%S%z')
    
    # def save(self, *args, **kwargs):
    #     previous = Message.objects.filter(pk=self.pk).first()
    #     super(Message, self).save(*args, **kwargs)
    #     if self.outgoing is False and self.franchise:
    #             current_val, created = UnactionedMessage.objects.get_or_create(
    #                     franchise=self.franchise
    #                     )
    #             if self.id is None:         # new message is being created
    #                     current_val.messages += 1
    #                     current_val.save()
    #             else:                           # message updated
    #                     if previous.actioned is False and self.actioned:
    #                             current_val.messages -= 1
    #                             current_val.save()
    #                     if previous.actioned and self.actioned is False:
    #                             current_val.messages += 1
    #                             current_val.save()      


class Email(models.Model):

    PENDING = 0
    ACCEPTED = 1
    REJECTED = 2
    DELIVERED = 3
    FAILED = 4
    OPENED = 5
    CLICKED = 6
    UNSUBSCRIBED = 7
    COMPLAINED = 8
    STORED = 9

    MAILGUN_STATUS_CHOICES = (
        (PENDING, 'Pending'),
        (ACCEPTED, 'Accepted'),
        (REJECTED, 'Rejected'),
        (DELIVERED, 'Delivered'),
        (FAILED, 'Failed'),
        (OPENED, 'Opened'),
        (CLICKED, 'Clicked'),
        (UNSUBSCRIBED, 'Unsubscribed'),
        (COMPLAINED, 'Complained'),
        (STORED, 'Stored'),
    )
    StatusTooltipDic = {
        PENDING: 'Pending',
        ACCEPTED: 'Accepted',
        REJECTED: 'Rejected',
        DELIVERED: 'Delivered',
        FAILED: 'Failed',
        OPENED: 'Opened',
        CLICKED: 'Clicked',
        UNSUBSCRIBED: 'Unsubscribed',
        COMPLAINED: 'Complained',
        STORED: 'Stored',
    }
    message = models.OneToOneField(
        Message,
        on_delete=models.CASCADE,
        primary_key=True,
        null=False
    )
    recipients = models.TextField(blank=True, db_index=True)
    cc = models.TextField(blank=True, db_index=True)
    bcc = models.TextField(blank=True, db_index=True)
    o_tag = models.TextField(blank=True)
    o_deliverytime = models.TextField(blank=True)
    sender = models.TextField(blank=True, db_index=True)
    from_text = models.TextField(blank=True, db_index=True)
    subject = models.TextField(blank=True)
    body_plain = models.TextField(blank=True)
    stripped_text = models.TextField(blank=True)
    stripped_signature = models.TextField(blank=True)
    body_html = models.TextField(blank=True)
    stripped_html = models.TextField(blank=True)
    attachments = models.TextField(blank=True)
    mailgun_id = models.TextField(blank=True, db_index=True)
    in_reply_to_mailgun_id = models.TextField(blank=True)
    # mailgun_status = models.TextField(blank=True)
    mailgun_message_status = models.IntegerField(
        choices=MAILGUN_STATUS_CHOICES, null=True
    )
    is_spam = models.BooleanField(null=False, default=False)
    delivered = models.DateTimeField(blank=True,null=True)
    mail_id = models.CharField(max_length=1000, blank=True) # Message-ID from message headers
    # stripped: without quoted parts and signature block (if found).

    @property
    def _history_user(self):
        return self.changed_by

    @_history_user.setter
    def _history_user(self, value):
        self.changed_by = value

    @property
    def status_tooltips(self):
        return self.StatusTooltipDic[self.mailgun_message_status]


class SMS(models.Model):

    PENDING = 'pending'
    SCHEDULED = 'scheduled'
    SENT = 'sent'
    BUFFERED = 'buffered'
    DELIVERED = 'delivered'
    EXPIRED = 'expired'
    FAILED = 'delivery_failed'

    STATUS = (
        (PENDING, 'Pending'),
        (SCHEDULED, 'Scheduled'),
        (SENT, 'Sent'),
        (BUFFERED, 'Buffered'),
        (DELIVERED, 'Delivered'),
        (EXPIRED, 'Expired'),
        (FAILED, 'Delivery_failed'),
    )

    StatusTooltipDic = {
        PENDING: 'Pending',
        SCHEDULED: 'Scheduled',
        SENT: 'Sent',
        BUFFERED: 'Buffered',
        DELIVERED: 'Delivered',
        EXPIRED: 'Expired',
        FAILED: 'Delivery_failed'
    }

    message = models.OneToOneField(
        Message,
        on_delete=models.CASCADE,
        primary_key=True,
        null=False
        )
    # SMS ----------------------------------------------------------
    from_number = PhoneNumberField(blank=True, db_index=True, null=True)
    from_text = models.TextField(blank=True, null=True)
    to_number = PhoneNumberField(blank=True, db_index=True)
    message_text = models.TextField(blank=True)
    status = models.TextField(choices=STATUS, null=True)
    uuid = models.TextField(blank=True)
    error_code = models.TextField(blank=True)
    message_bird_response = models.TextField(blank=True, null=True)
    message_bird_callback_response = models.TextField(blank=True, null=True)
    
    @property
    def status_tooltips(self):
        return self.StatusTooltipDic[self.status]


class ManualMessageTemplateCategory(models.Model):
    category = models.CharField(
        max_length=255,
        blank=False,
        unique=True
        )
    order = models.IntegerField(blank=True, null=True)

    def __str__(self):
        return self.category

    class Meta:
        ordering = [
            "order",
            "category"
            ]
        verbose_name_plural = 'Manual message template categories'


class ManualMessageTemplate(models.Model):

    MESSAGE_TYPE_CHOICES = (
        (1, 'Email'),
        (2, 'SMS'),
        (3, 'Email and SMS')
    )
    TYPE_OF_EMAIL_CHOICES = (
        (1, 'Automated message (to customer)'),
        (2, 'Automated message (to WC)'),
        (3, 'Automated message (to Franchisee)'),
        (4, 'Bulk messages'),
        (5, 'Chaser messages'),
        (6, 'Office Owings - Reminder Email to office'),
        (7, 'Reply to SMS on Message Template'),
        (8, 'Reply to Email on Message Template'),
        (9, 'Email Template First Chaser Email'),
        (10, 'Auto chasers'),
        (11, 'Email Template Third Chaser Email'),
        (12, 'Email Template T&C'),
        (13, 'Manual messages'),
        (14, 'WC training'),
        (15, 'Other'),
        (16, 'Old Enfield emails'),
        (17, 'WC BTD'),
        # if you change this check chaser_cron.py
        #  - chasers rely on type_of_email to select correct template
    )

    message_type = message_type = models.IntegerField(
        choices=MESSAGE_TYPE_CHOICES, null=False
    )
    type_of_email = models.IntegerField(
        choices=TYPE_OF_EMAIL_CHOICES, null=False,
        default=1
    )
    # unique identifier of the email template
    title = models.CharField(max_length=255, unique=True)
    subject = models.CharField(
        max_length=255,
        blank=True,
        null=True
        )
    sms_template = models.TextField(
        blank=True,
        null=True,
        verbose_name='SMS Template Text '
        )
    # email_template = models.TextField(
    #     blank=True,
    #     null=True,
    #     verbose_name='Email Template Text '
    #     )
    email_template = RichTextField(default='')
    order = models.IntegerField(default=0)
    checked = models.BooleanField(default=False)
    franchise = models.ForeignKey(
        Franchise,
        on_delete=models.PROTECT,
        null=True,
        blank=True
    )
    manual_message_template_category = models.ForeignKey(
        ManualMessageTemplateCategory,
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )

    class Meta:
        ordering = ["order"]


class AutoChaserMessageTemplate(models.Model):

    title = models.CharField(max_length=255, unique=True)
    email_subject = models.CharField(
        max_length=255
        )
    sms_template = models.TextField(
        verbose_name='SMS Template Text '
        )
    email_template = RichTextField()    
    send_both_email_and_sms = models.BooleanField(default=False)
    chaser_number = models.IntegerField(blank=False)
    chaser_money_type = models.IntegerField(choices=MoneyType.CHASER_MONEY_TYPE_CHOICES)
    owing_chaser_notes = models.TextField(blank=True)    
    chaser_delay = models.IntegerField(default=1, help_text='Initial delay before sending chaser')

    def __str__(self):
        return self.title
    class Meta:
        ordering = ["chaser_number"]
        unique_together = (("chaser_number", "chaser_money_type"),)


class PriceIncreaseTemplate(models.Model):

    # unique identifier of the template
    title = models.CharField(max_length=255, unique=True)
    subject = models.CharField(
        max_length=255,
        blank=True,
        null=True
    )    
    email_template = RichTextField(default='')
    sms_template = models.TextField(
        blank=True,
        null=True,
        verbose_name='SMS Template Text'
    )
    order = models.IntegerField(default=0)

    class Meta:
        ordering = ["order"]


class AddVATTemplate(models.Model):

    # unique identifier of the template
    title = models.CharField(max_length=255, unique=True)
    subject = models.CharField(
        max_length=255,
        blank=True,
        null=True
    )    
    email_template = RichTextField(default='')
    sms_template = models.TextField(
        blank=True,
        null=True,
        verbose_name='SMS Template Text'
    )
    order = models.IntegerField(default=0)

    class Meta:
        ordering = ["order"]

class Contact(models.Model):
    """ this is to store general contact details
        for non-users and non-customers.
        Specific to franchise for franchisees &
        franchise_admins, non-specific for franchisors
    """
    TITLE_CHOICES = (
        ('Mr.', 'Mr.'),
        ('Ms.', 'Ms.'),
        ('Mrs.', 'Mrs.'),
        ('Miss', 'Miss'),
    )

    title = models.CharField(max_length=4, choices=TITLE_CHOICES, blank=True)
    first_name = models.CharField(max_length=30, blank=True)
    last_name = models.CharField(max_length=150, blank=True)
    contact_name = models.CharField(max_length=100)
    franchise = models.ForeignKey(
        'franchises.Franchise',
        on_delete=models.PROTECT,
        null=True  # for franchisors
    )
    home_phone = PhoneNumberField(blank=True)
    business_phone = PhoneNumberField(blank=True)
    extension = models.CharField(max_length=150, blank=True)
    mobile_phone = PhoneNumberField(blank=True)
    email = models.EmailField(blank=True)
    relationship = models.CharField(max_length=50, blank=True)
    # for example 'accountant'
    address_line_1 = models.CharField(max_length=200, blank=True)
    address_line_2 = models.CharField(
        max_length=200,
        blank=True
        )
    address_line_3 = models.CharField(
        max_length=200, blank=True
        )
    post_town = models.CharField(max_length=100, blank=True)
    county = models.CharField(max_length=100, blank=True)
    postcode = models.CharField(max_length=100, blank=True)
    opening_hours = models.TextField(blank=True)
    picture = models.ImageField(blank=True, upload_to='contacts')
    notes = models.TextField(blank=True)

    def __str__(self):
        return self.contact_name


class Chaser(models.Model):
    """ many-to-many table between messages
        and jobs for owing chasers
    """

    MANUAL_CHASER = 1
    AUTO_CHASER = 2

    CHASER_TYPE_CHOICES = (
        (MANUAL_CHASER, 'Manual'),
        (AUTO_CHASER, 'Automatic'),
        )
    job = models.ForeignKey(
        'jobs.Job',
        on_delete=models.PROTECT,
        null=True,
    )
    message = models.OneToOneField(
        Message,
        on_delete=models.CASCADE,
        null=False,
    )
    chaser_type = models.IntegerField(
        choices=CHASER_TYPE_CHOICES,
        null=False,
        db_index=True
        )


class UnactionedMessage(models.Model):
    franchise = models.OneToOneField(
        Franchise,
        on_delete=models.CASCADE,
        primary_key=True,
        null=False
        )
    messages = models.IntegerField(null=False, default=0)

    def __str__(self):
        return "{0} ({1})".format(self.franchise, self.messages)


class ImportedMessage(models.Model):

    old_db_message_id = models.IntegerField(primary_key=True)
    message_type = models.IntegerField(
        choices=Message.MESSAGE_TYPE_CHOICES, null=False,        
        )
    franchise = models.ForeignKey(
        Franchise,
        on_delete=models.PROTECT,
        null=True,        
        )
    franchisor = models.ForeignKey(
        Franchisor,
        on_delete=models.PROTECT,
        null=True
        )
    customer = models.ForeignKey(
        ImportedCustomer,
        on_delete=models.PROTECT,
        related_name='imported_messages',
        null=True      
    )
    user = models.ForeignKey(
        User,
        on_delete=models.PROTECT,
        related_name='imported_messages',
        null=True,
    )
    contact = models.ForeignKey(
        'Contact',
        on_delete=models.PROTECT,
        related_name='imported_contacts',
        null=True,
    )
    commercial_list = models.ForeignKey(
        CommercialList,
        on_delete=models.PROTECT,
        related_name='imported_commercial_list',
        null=True,
    )
    outgoing = models.BooleanField(null=False, db_index=True)
    read = models.BooleanField(null=False, default=False)
    actioned = models.BooleanField(null=False, default=False, db_index=True)
    actioned_by = models.ForeignKey(
        User,
        on_delete=models.PROTECT,
        null=True,        
    )
    actioned_by_date = models.DateTimeField(null=True, blank=True)
    related_customer = models.ForeignKey(
        Customer,
        on_delete=models.PROTECT,
        related_name='imported_related_customer',
        null=True
    )
    sent_time = models.DateTimeField(null=True, blank=True, db_index=True)
    received_time = models.DateTimeField(null=True, blank=True, db_index=True)
    old_id = models.IntegerField(null=True)
    message_notes = models.CharField(blank=True, max_length=150)

    @property
    def _history_user(self):
        return self.changed_by

    @property
    def is_over_24h(self):
        if self.received_time is not None and self.received_time != '':
            return (datetime.now().astimezone() - self.received_time) > timedelta(hours=24)
        else:
            return False

    @_history_user.setter
    def _history_user(self, value):
        self.changed_by = value

    def date_time(self):
        if self.received_time:
            time = self.received_time
        else:
            time = self.sent_time
        return time

    def message_text(self):
        if hasattr(self, 'email'):
            if self.email.body_html:
                return self.email.body_html
            else:
                return self.email.body_plain
        else:
            return self.sms.message_text

    def from_txt(self):
        if self.customer:
            return self.customer
        elif self.user:
            return self.user
        else:
            if hasattr(self, 'sms'):
                return self.sms.from_number
            else:
                return self.email.sender

    def to_txt(self):
        if self.customer:
            return self.customer
        elif self.user:
            return self.user
        else:
            if hasattr(self, 'sms'):
                return self.sms.to_number
            else:
                return self.email.recipients

    def from_num_email(self):
        if hasattr(self, 'email'):
            return self.email.sender
        else:
            return self.sms.from_number
    from_num_email.short_description = 'From'

    def to_num_email(self):
        if hasattr(self, 'email'):
            recipients = re.sub(r"['\[]", "", self.email.recipients)
            recipients = re.sub(r"['\]]", "", recipients)
            return recipients
        else:
            return self.sms.to_number
    to_num_email.short_description = 'To'

    def message_user_type(self):
        if self.customer_id:
            return 'customer'
        elif self.user_id:
            return 'user'
        elif self.contact_id:
            return 'contact'
        else:
            return 'other'

    """ def message_type(self):
        if hasattr(self, 'email'):
            return'email'
        else:
            return 'sms' """

    def __str__(self):
        if self.received_time:
            time = self.received_time
        else:
            time = self.sent_time

        return time.strftime('%d/%m/%Y %H:%M:%S%z')


class ImportedEmail(models.Model):

    message = models.OneToOneField(
        Message,
        on_delete=models.CASCADE,
        primary_key=True,
        null=False
        )
    recipients = models.TextField(blank=True, db_index=True)
    cc = models.TextField(blank=True, db_index=True)
    bcc = models.TextField(blank=True, db_index=True)
    o_tag = models.TextField(blank=True)
    o_deliverytime = models.TextField(blank=True)
    sender = models.TextField(blank=True, db_index=True)
    from_text = models.TextField(blank=True, db_index=True)
    subject = models.TextField(blank=True)
    body_plain = models.TextField(blank=True)
    stripped_text = models.TextField(blank=True)
    stripped_signature = models.TextField(blank=True)
    body_html = models.TextField(blank=True)
    stripped_html = models.TextField(blank=True)
    attachments = models.TextField(blank=True)
    
    @property
    def _history_user(self):
        return self.changed_by

    @_history_user.setter
    def _history_user(self, value):
        self.changed_by = value


class ImportedSMS(models.Model):

    message = models.OneToOneField(
        Message,
        on_delete=models.CASCADE,
        primary_key=True,
        null=False
        )
    # SMS ----------------------------------------------------------
    from_number = PhoneNumberField(blank=True, db_index=True)
    to_number = PhoneNumberField(blank=True, db_index=True)
    message_text = models.TextField(blank=True)
    status = models.TextField(choices=SMS.STATUS, null=True)
