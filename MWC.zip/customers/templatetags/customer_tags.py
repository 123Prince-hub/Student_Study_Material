# -*- coding:utf-8 -*-
from __future__ import unicode_literals
from django import template
from customers.models import Customer
from django.core.exceptions import ObjectDoesNotExist


register = template.Library()


@register.simple_tag()
def drop_owings_slip(customer):
    try:
        customer = Customer.objects.get(pk=customer)
        if customer.book_with == 'Text Only' or (
            customer.email is None and customer.mobile_phone is None
                ):
            return 1
    except ObjectDoesNotExist:
        pass

    return 0
