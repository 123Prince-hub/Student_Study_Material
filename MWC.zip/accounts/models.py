# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

from django.contrib.auth.models import AbstractUser
from django.core.exceptions import ValidationError

from phonenumber_field.modelfields import PhoneNumberField
from simple_history.models import HistoricalRecords

import datetime

from MWC_APP.widgets import ColorPickerWidget


class ColorField(models.CharField):

    def __init__(self, *args, **kwargs):
        kwargs['max_length'] = 10
        super(ColorField, self).__init__(*args, **kwargs)

    def formfield(self, **kwargs):
        kwargs['widget'] = ColorPickerWidget
        return super(ColorField, self).formfield(**kwargs)


class User(AbstractUser):

    TITLE_CHOICES = (
        ('Mr.', 'Mr.'),
        ('Ms.', 'Ms.'),
        ('Mrs.', 'Mrs.'),
        ('Miss', 'Miss'),
    )
    title = models.CharField(max_length=4, choices=TITLE_CHOICES, blank=True)
    middle_name = models.CharField(max_length=30, blank=True)
    nickname = models.CharField(max_length=30, blank=True)

    home_phone = PhoneNumberField(blank=True)
    mobile_phone = PhoneNumberField(blank=True)
    ansaphone = models.BooleanField(default=False)
    # TODO: REMOVE THESE 2 FIELDS
    account_number = models.CharField(max_length=10, blank=True)
    sort_code = models.CharField(max_length=10, blank=True)
    # ##########################
    dob = models.DateField(blank=True, null=True)
    old_login = models.CharField(max_length=45, blank=True)
    personal_email = models.EmailField(blank=True)
    next_of_kin_details = models.TextField(blank=True)
    bank_name = models.CharField(max_length=255, blank=True)
    bank_account_holder_name = models.CharField(max_length=255, blank=True)
    bank_account_sort_code = models.CharField(max_length=8, blank=True)
    bank_account_number = models.CharField(max_length=8, blank=True)
    bank_account_notes = models.CharField(max_length=255, blank=True)
    cells_color_code = ColorField(max_length=10, blank=True, default='#c5c5c5')
    national_insurance_number = models.CharField(max_length=9, blank=True)
    date_of_birth = models.DateField(null=True)
    picture = models.ImageField(blank=True, upload_to='users_images')
    address_line_1 = models.CharField(
        max_length=200, db_index=True, blank=True
        )
    address_line_2 = models.CharField(
        max_length=200, blank=True, db_index=True
        )
    address_line_3 = models.CharField(
        max_length=200, blank=True, db_index=True
        )
    post_town = models.CharField(
        max_length=100, db_index=True, blank=True
        )
    county = models.CharField(max_length=100, blank=True)
    postcode = models.CharField(max_length=100, blank=True, db_index=True)
    is_all_day_of_week = models.BooleanField(default=False)
    is_turnover_default_or_diary = models.BooleanField(default=False)
    notes = models.TextField(blank=True)
    first_name= models.CharField(null=False, blank=False, max_length=100)
    last_name = models.CharField(null=False, blank=False, max_length=100)
    hide_training_videos = models.BooleanField(default=False)
    history = HistoricalRecords()

    class Meta:
        ordering = ['last_name', 'first_name']

    def __str__(self):
        return self.get_full_name()

    @property
    def initials(self):
        return ''.join(
                        (self.first_name[:1],
                         self.middle_name[:1],
                         self.last_name[:1])
                        )

    @property
    def _history_user(self):
        return self.changed_by

    @_history_user.setter
    def _history_user(self, value):
        self.changed_by = value


class AvailabilityHours(models.Model):

    WEEKDAYS = [
        (1, ("Monday")),
        (2, ("Tuesday")),
        (3, ("Wednesday")),
        (4, ("Thursday")),
        (5, ("Friday")),
        (6, ("Saturday")),
        (7, ("Sunday")),
    ]

    TIME_CHOICES = []
    for i in range(0, 24*2):
        TIME_CHOICES.append(
            (
                (datetime.datetime.combine(datetime.date.today(), datetime.time()) + datetime.timedelta(minutes=30) * i).time().strftime("%H:%M"),
                (datetime.datetime.combine(datetime.date.today(), datetime.time()) + datetime.timedelta(minutes=30) * i).time().strftime("%I:%M %p")
            )
        )

    user = models.ForeignKey(
        User,
        null=False,
        on_delete=models.CASCADE
    )

    weekday = models.IntegerField(
        choices=WEEKDAYS,
        blank=True
    )

    from_hour = models.CharField(
        max_length=24, choices=TIME_CHOICES, blank=True
        )
    to_hour = models.CharField(
        max_length=24, choices=TIME_CHOICES, blank=True
        )

    is_unavailable = models.BooleanField(default=False, blank=True)

    class Meta:
        unique_together = (("weekday", "user"),)
        verbose_name = 'Availability Hours'
        verbose_name_plural = 'Availability Hours'


class WindowCleaner(models.Model):
    user = models.OneToOneField(
        User,
        null=False,
        on_delete=models.CASCADE
    )
    franchise = models.ManyToManyField(
        'franchises.Franchise',
        related_name='wc_franchise',
        blank=False
    )
    old_login = models.CharField(max_length=100, blank=True)
    is_employed = models.BooleanField(default=False)
    is_driver = models.BooleanField(default=False)
    has_own_transport = models.BooleanField(default=False)
    vehicle_details = models.CharField(max_length=500, blank=True)
    ladder_types = models.CharField(max_length=100, blank=True)
    experience = models.TextField(blank=True)
    interview_date = models.DateField(null=True, blank=True)
    interview_notes = models.TextField(blank=True)
    trial_date = models.DateField(null=True, blank=True)
    trial_notes = models.TextField(blank=True)
    company_procedures = models.BooleanField(default=False)
    has_signed_contract = models.BooleanField(default=False)
    vehicle_registration = models.CharField(max_length=11, blank=True)
    mwc_vehicle = models.BooleanField(default=False)
    # use Django's is_active for 'active'
    pl_insurance_company = models.CharField(max_length=100, blank=True)
    pl_insurance_broker = models.CharField(max_length=100, blank=True)
    pl_insurance_start_date = models.DateField(null=True, blank=True)
    pl_insurance_end_date = models.DateField(null=True, blank=True)
    pl_insurance_cover = models.CharField(
        max_length=100,
        blank=True
    )
    other_insurance = models.CharField(max_length=100, blank=True)
    requested_turnover = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        null=True
    )
    notes = models.TextField(blank=True)
    stop_chasers = models.BooleanField(default=False)
    show_franchise_expenses = models.BooleanField(null=False, blank=False, default=False)
    allocation_notes = models.CharField(max_length=100, blank=True)
    history = HistoricalRecords()

    def __str__(self):
        return self.user.get_full_name()

    def get_by_natural_key(self):
        return self.user.get_full_name()

    def get_wc_initials(self):
        return ''.join(
            (
            self.user.first_name[:1],
            self.user.middle_name[:1],
            self.user.last_name[:1]
            )
        )

    def get_wc_first_last_initials(self):
        return ''.join(
            ( self.user.first_name[:1], self.user.last_name[:1] )
        )

    class Meta:
        ordering = ['user__first_name']

    @property
    def _history_user(self):
        return self.changed_by

    @_history_user.setter
    def _history_user(self, value):
        self.changed_by = value


class WCCommissionRate(models.Model):
    window_cleaner = models.ForeignKey(
        'WindowCleaner',
        related_name='commission_rates',
        on_delete=models.CASCADE
        )
    valid_from = models.DateField(blank=False, null=True)
    commission_rate = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        null=True,
    )
    is_fixed_rate = models.BooleanField(default=False)
    daily_rate = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        null=True,
        blank=True,
    )
    is_vat_registered = models.BooleanField(default=False)
    vat_rate = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        null=True,
    )

    def __str__(self):
        return '%s-%s' % (self.window_cleaner, self.valid_from)        
    
    def clean(self):
        if self.is_fixed_rate and self.daily_rate is None:
            raise ValidationError("Please add a daily rate")
        
    class Meta:
        unique_together = ('window_cleaner', 'valid_from')
        verbose_name = 'WC commission rates'
        verbose_name_plural = 'WC commission rates'


class Franchisee(models.Model):
    user = models.OneToOneField(
        User,
        null=False,
        on_delete=models.CASCADE
    )
    franchise = models.OneToOneField(
        'franchises.Franchise',
        on_delete=models.PROTECT,
    )
    pl_insurance_carrier = models.CharField(max_length=50, blank=True)
    pl_insurance_start_date = models.DateField(null=True)
    pl_insurance_end_date = models.DateField(null=True)
    pl_insurance_cover_amount = models.CharField(max_length=50, blank=True)
    pl_insurance_is_auto_renewed = models.BooleanField(default=False)

    def __str__(self):
        return self.user.get_full_name()

    def get_by_natural_key(self):
        return self.user.get_full_name()

    class Meta:
        ordering = ['user__last_name']


class FranchiseAdmin(models.Model):
    user = models.OneToOneField(
        User,
        null=False,
        on_delete=models.CASCADE
    )
    franchise = models.ForeignKey(
        'franchises.Franchise',
        on_delete=models.PROTECT,
        null=True  # for franchisors
    )
    job_title = models.CharField(max_length=25, blank=True)

    def __str__(self):
        return self.user.get_full_name()

    def get_by_natural_key(self):
        return self.user.get_full_name()

    class Meta:
        ordering = ['user__last_name']


class LeafletDistributor(models.Model):
    user = models.OneToOneField(
        User,
        null=False,
        on_delete=models.CASCADE
    )
    franchise = models.ForeignKey(
        'franchises.Franchise',
        on_delete=models.PROTECT,
        null=True  # for franchisors
    )
    hourly_rate = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        null=True,
        blank=True,
    )
    pay_per_1000 = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        null=True,
        blank=True,
    )    
    counts_in_stats = models.BooleanField(default=True)

    def __str__(self):
        return self.user.get_full_name()

    def get_by_natural_key(self):
        return self.user.get_full_name()

    class Meta:
        ordering = ['user__last_name']


class Canvasser(models.Model):
    user = models.OneToOneField(
        User,
        null=False,
        on_delete=models.CASCADE
    )
    franchise = models.ForeignKey(
        'franchises.Franchise',
        on_delete=models.PROTECT,
        null=True  # for franchisors
    )
    hourly_rate = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        null=True,
        blank=True,
    )
    counts_in_stats = models.BooleanField(default=True)

    def __str__(self):
        return self.user.get_full_name()

    def get_by_natural_key(self):
        return self.user.get_full_name()

    class Meta:
        ordering = ['user__last_name']


class Franchisor(models.Model):
    user = models.OneToOneField(
        User,
        null=False,
        on_delete=models.CASCADE
    )

    def __str__(self):
        return self.user.get_full_name()

    def get_by_natural_key(self):
        return self.user.get_full_name()

    class Meta:
        ordering = ['user__last_name']

class CustomerCare(models.Model):
    
    user = models.OneToOneField(
        User,
        null=False,
        on_delete=models.CASCADE
    )

    timer_active = models.BooleanField(default=False)
    
    timer_start = models.DateTimeField(blank=True, null=True)

    timer_category = models.ForeignKey(
        'franchises.CustomerCareTimeCategory',
        on_delete=models.PROTECT,        
        blank=True,
        null=True
    )

    franchise = models.ForeignKey(
        'franchises.Franchise',
        on_delete=models.PROTECT,
        null=True, blank=True,
    )

    def __str__(self):
        return self.user.get_full_name()

    def get_by_natural_key(self):
        return self.user.get_full_name()

    class Meta:
        ordering = ['user__last_name']

ENTERY_TYPE_CHOICE = (
    ('notes', 'Notes'),
    ('sick_leave', 'Sick Leave'),
    ('holiday', 'Holiday'),
    ('working_hours', 'Working Hours'),
    ('add_wants', 'Add Wants'),
)
TYPE_OF_RECORD_CHOICE = (
    ('user', 'User'),
    ('general_item', 'General Notes'),
    ('job_to_allocate', 'Job to allocate'),
    ('outstanding', 'Outstanding'),
)
DIARY_REMINDER = (
    ('none', 'None'),
    ('1_hour', '1 Hour'),
    ('1_day', '1 Day'),
    ('1_month', '1 Month')
)


class UserDiary(models.Model):

    user = models.ForeignKey(
        User,
        null=False,
        on_delete=models.CASCADE
    )
    franchise = models.ForeignKey(
        'franchises.Franchise',
        on_delete=models.PROTECT,
        null=True  # for franchisors
    )
    entry_type = models.CharField(
        max_length=20, choices=ENTERY_TYPE_CHOICE, default='notes', blank=False
        )
    title = models.CharField(max_length=255, blank=True)
    notes = models.TextField(blank=False)
    reminder = models.CharField(max_length=20, choices=DIARY_REMINDER, default='none', blank=False)
    user_reminder = models.TextField(blank=False, null=True)
    reason = models.TextField(blank=False)
    start_date = models.DateField(null=True)
    end_date = models.DateField(null=True)
    from_hour = models.CharField(max_length=10, blank=True,null=True)
    to_hour = models.CharField(max_length=10, blank=True,null=True)
    is_all_day = models.BooleanField(default=False)
    type_of_record = models.CharField(max_length=25,choices=TYPE_OF_RECORD_CHOICE, blank=False,default='user')
    requested_turnover = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        null=True
    )