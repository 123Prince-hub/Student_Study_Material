from django import forms
from .models import *
from django.contrib.auth.forms import UserCreationForm

#  ************************************************  Forms for Notes   ***********************************************
class UserRegistrationForm(UserCreationForm):
    email = forms.EmailField(required=True)
    username = forms.CharField(required=True)
    password1 = forms.CharField(label=("Password"),strip=False,widget=forms.PasswordInput,)
    password2 = forms.CharField(label=("Password confirmation"),widget=forms.PasswordInput,strip=False,)
    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']





#  ************************************************  Forms for Notes   ************************************************
class NotesForm(forms.ModelForm):
    class Meta:
        model = Notes
        fields = ['title', 'desc']




#  *********************************************  Forms for Homework   **********************************************
class DateInput(forms.DateInput):
    input_type = 'date'

class HomeworkForm(forms.ModelForm):
    class Meta:
        model = Homework
        widgets = {'due':DateInput()}
        fields = ['subject', 'title', 'desc', 'due', 'is_finished']





#  **********************************  Forms for Youtube/Wikipedia/Dictionary   **************************************
class DashboardForm(forms.Form):
    text = forms.CharField(max_length=100, required=False, label="Enter that You want to Search")






#  **********************************************  Forms for Todo   *************************************************
class TodoForm(forms.ModelForm):
    class Meta:
        model = Todo
        fields = ['title', 'is_finished']




#  ********************************************  Forms for Conversion   ********************************************
class ConversionForm(forms.Form):
    CHOICES = [('length', 'Length'), ('mass', 'Mass')]
    measurment = forms.ChoiceField(choices=CHOICES, required=False, widget=forms.RadioSelect)

class LengthConversionForm(forms.Form):
    CHOICES = [('yard', 'Yard'), ('foot', 'Foot')]
    input = forms.CharField(required=False, label=False, widget=forms.TextInput(
        attrs={'type':'number', 'placeholder':'Enter the Number'}
    ))
    measure_1 = forms.CharField(
        label='', widget=forms.Select(choices=CHOICES)
    )
    measure_2 = forms.CharField(
        label='', widget=forms.Select(choices=CHOICES)
    )

class MassConversionForm(forms.Form):
    CHOICES = [('pound', 'Pound'), ('kilogram', 'Kilogram')]
    input = forms.CharField(required=False, label=False, widget=forms.TextInput(
        attrs={'type':'number', 'placeholder':'Enter the Number'}
    ))
    measure_1 = forms.CharField(
        label='', widget=forms.Select(choices=CHOICES)
    )
    measure_2 = forms.CharField(
        label='', widget=forms.Select(choices=CHOICES)
    )