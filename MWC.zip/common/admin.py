# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.contrib import admin
from .models import EmailTemplate, VideoLink, VideoLinkCategory, VideoPage, NetworkMessage
from jobs.models import WizardStep, WizardOption
from common.templatetags.app_tags import extract_text_from_html


class EmailTemplateAdmin(admin.ModelAdmin):

    def has_add_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False
    actions = None
    list_display = ['title', 'step', 'option','job_office_notes','_get_email_template']
    search_fields = ['title', 'subject']
    list_filter = (('step', admin.RelatedOnlyFieldListFilter),)

    def get_readonly_fields(self, request, obj=None):
        if obj:
            return ["step", "option"]
        else:
            return []

    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        if db_field.name == "step":
            kwargs["queryset"] = WizardStep.objects.order_by('title')
        if db_field.name == "option":
            kwargs["queryset"] = WizardOption.objects.filter(next_step_type='W').order_by('title')
        return super(EmailTemplateAdmin, self).formfield_for_foreignkey(db_field, request, **kwargs)
    
    def _get_email_template(self, obj):
         return extract_text_from_html(obj.email_template)


class VideoLinkAdmin(admin.ModelAdmin):
    list_display = (
        'title',
        'video_page',
        'order',
    )

    list_filter = (
        'video_page',
    )

    list_select_related = (
        'video_page',
    )
    search_fields = ['title', ]


class VideoPageAdmin(admin.ModelAdmin):
    list_display= ('page', 'slug','order')


admin.site.register(
    EmailTemplate, EmailTemplateAdmin
    )
admin.site.register(VideoLink, VideoLinkAdmin)
admin.site.register(VideoLinkCategory)
admin.site.register(VideoPage, VideoPageAdmin)
admin.site.register(NetworkMessage)
