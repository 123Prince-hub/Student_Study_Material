# -*- coding:utf-8 -*-
from __future__ import unicode_literals
import ast
from django.db.models.fields import IntegerField
import phonenumbers
import os,re
import datetime
import urllib
from bs4 import BeautifulSoup
from PIL import Image
import math
import inspect
import operator, json
from functools import *
from collections import defaultdict

from django import template
from django.conf import settings
from django.contrib.humanize.templatetags.humanize import intcomma
from django.contrib.auth.models import Group
from django.contrib.auth import login

from django.core.exceptions import PermissionDenied, ObjectDoesNotExist

from django.db import connection
from django.db.models import (
    Sum, F, CharField, Q, Value, Count, Subquery,
    OuterRef, DurationField, ExpressionWrapper, Func  
)

from django.db.models.functions import Concat, Coalesce, Ceil


from django.http import JsonResponse, HttpResponse

from django.utils.html import format_html
from django.utils.safestring import mark_safe

from accounts.models import WindowCleaner, User, AvailabilityHours, UserDiary
from comms_messages.models import Message, UnactionedMessage
from customers.models import (
    Customer, BusinessSource, CustomerLatestJob,
    ImportedCustomer, IS_SETUP_COMPLETE, IS_SETUP_AUTOMATED, IS_SETUP_IN_PROGRESS, IS_SETUP_TO_BE_DONE
)
from franchises.models import Franchise
from franchises.models import Setting
from jobs.models import Job, TimeSlot, CheckedInvoice
from to_do.models import TODO
from franchises.views.cct_monitoring import Epoch
from common.models import VideoLink, VideoLinkUserView
from common.utilities import (
    get_user_franchise, current_site_url,
    has_group, get_job_time_slot_str,checkFileExistOnS3,
    get_customer_time_slot_str, get_allocate_time_slot_str,
    get_day_two_time_slot_str, get_customer_time_slot_span_str,
    get_allocate_day2_time_slot_str, generate_user_initial, 
    get_user_franchise_id, formatted_cust_other_quotes, fn_get_total_hours
)
from customers.models import ACTIVE, INACTIVE, ENQUIRY, VATFlags, FutureVATFlags
from franchises.models import (
    Invoice, SENT, WeeklyCustomerCareBookedTime, CustomerCareTime
)
from django.db.models import Max

register = template.Library()


@register.filter
def trim(value):
    return value.replace("/^\s+|\s+$/g", '')


@register.filter
def removeunderscore(value):
    return value.replace("_"," ")


@register.filter()
def currency(amount):
    """ simple tag to return GBP currency - doesn't support localization """
    if amount and amount == amount:  # checks for NaN
        amount = round(float(amount), 2)
        if amount < 0.0:
            return "-£%s%s" % (intcomma(int(abs(amount))), ("%0.2f" % amount)[-3:])
        else:
            return "£%s%s" % (intcomma(int(amount)), ("%0.2f" % amount)[-3:])
    else:
        return "£0.00"


@register.filter()
def currency_short(amount):
    """ simple tag to return GBP currency - doesn't support localization
        doesn't return decimal if .00 """

    """ if (isinstance(amount,str) == False):
        if float(amount).is_integer():
            return "£%s" % (intcomma(int(amount)))
        else:
            return "£%s%s" % (intcomma(int(amount)), ("%0.2f" % amount)[-3:])
    else:
        return amount """

    if isinstance(amount, str) == True or amount is not None:
        try:
            amount = round(float(amount), 2)
        except ValueError:
            amount = 0
    else:
        return ""

    if amount < 0.0:
        amount_with_leading_zero = "-£%s%s" % (intcomma(int(abs(amount))), ("%0.2f" % amount)[-3:])
        return amount_with_leading_zero.rstrip('0').rstrip('.')
    else:
        amount_with_leading_zero = "£%s%s" % (intcomma(int(amount)), ("%0.2f" % amount)[-3:])
        return amount_with_leading_zero.rstrip('0').rstrip('.')


@register.filter
def percentage(value):
    if value is not None and value != '':
        return '{0:.2%}'.format(value)
    else:
        return '-%'


@register.filter
def percentage_short(value):
    if value is not None and value != '':
        if value<0:
            return '{0:.0%}'.format(value)
        else:
            return '+{0:.0%}'.format(value)
    else:
        return '-%'

@register.filter
def percentage(value):
    if value is not None and value != '':
        if value<0:
            return '{0:.0%}'.format(value/100)
        elif value>0:
            return '{0:.0%}'.format(value/100)
        else:
            return '0%'
    else:
        return '-%'


@register.filter()
def escape(address):
    return urllib.parse.quote_plus(address)


@register.filter()
def to_int(value):
    return int(value)


@register.filter()
def get_total(invoice):    
    return "£%s" % (invoice.net_amount+invoice.vat_amount)


# https://stackoverflow.com/questions/346467/format-numbers-in-django-templates


@register.inclusion_tag('user_owes.html', takes_context=True)
def show_owings(context, user):
    """ inclusion tag to return either WC owings
        or franchise owings, displayed in menus
    """

    qs = None
    request = context['request']
    franchise = None

    #check is Test Area On of Off
    isTestArea = False
    if 'switch_test_on_off' in request.session and \
        request.session['switch_test_on_off'] == 'true':
        isTestArea = True

    if 'franchisor_data_display' in request.session:
        # user has selected a franchise in dropdown
        franchise = int(request.session['franchisor_data_values'])

    if (franchise != 0 and franchise is not None and has_group(request, 'franchisor')):
        # user has selected a franchise in dropdown
        qs = Job.objects.filter(
            Q(customer__booking_road__area__franchise=franchise) &
            Q(customer__booking_road__area__is_test_area=isTestArea),
            Q(owes__gt=0)
            ).aggregate(
                Sum('owes'), Count('owes')
                )
    elif has_group(request, 'franchisee') or has_group(request, 'franchise_admin') or has_group(request, 'customer_care'):
        franchise_id = get_user_franchise_id(user, request)
        qs = Job.objects.filter(
            Q(customer__booking_road__area__franchise__id=franchise_id) &
            Q(customer__booking_road__area__is_test_area=isTestArea),
            Q(owes__gt=0)
        ).aggregate(
            Sum('owes'), Count('owes')
            )
    elif has_group(request, 'window_cleaner'):
        qs = Job.objects.filter(
            Q(window_cleaner__user=user) &
            Q(payment_status__payment_status_description='WC Owed') &
            Q(customer__booking_road__area__is_test_area=isTestArea),
            Q(owes__gt=0)
            ).aggregate(
                Sum('owes'), Count('owes')
                )

    if qs is not None:
        sum = qs['owes__sum']
        count = qs['owes__count']
    else:
        sum = 0.0
        count = 0
    if not sum:
        sum = 0.00
    if not count:
        count = 0

    return {'count': count, 'sum': sum}

from django.http import JsonResponse

def get_unactioned_messages(franchise_id, isTestArea=False):
    unactioned_messages = Message.objects.select_related(
            'customer__booking_road__area',
        ).filter(
            Q(actioned=False) &
            Q(outgoing=False) &
            Q(Q(customer__booking_road__area__is_test_area=isTestArea) | Q(customer__booking_road__area__is_test_area__isnull=True)) &
            Q(franchise__id=franchise_id)
        ).count()
    return unactioned_messages or 0    

@register.simple_tag(takes_context=True)
def inbox_count(context, user):
    """ returns number of unactioned messages """
    isTestArea = False
    if 'switch_test_on_off' in context.request.session and \
        context.request.session['switch_test_on_off'] == 'true':
        isTestArea = True
    franchise_id = get_user_franchise_id(user, context['request'])
    if franchise_id:
        return get_unactioned_messages(franchise_id, isTestArea)
    else: 
        return 0
        
def get_failed_messages(franchise_id, isTestArea=False):
    failed_messages = Message.objects.select_related(
        'customer__booking_road__area',
        'email',
        'sms',
    ).filter(
            Q(outgoing=True) &
            Q(Q(customer__booking_road__area__is_test_area=isTestArea) | Q(customer__booking_road__area__is_test_area__isnull=True)) &
            Q(franchise__id=franchise_id) &
            Q(ignore_failure=False) &
            Q(
                Q(email__mailgun_message_status__in=(0,2,4,7,8)) 
                | 
                Q(sms__status__in=('pending', 'buffered','expired','delivery_failed',)) 
                |
                Q(
                    Q(Q(sms__status__isnull=True) |Q(sms__status=Value(''))) & Q(email__mailgun_message_status__isnull=True)
                )

            )
        ).count()
    return failed_messages or 0   


@register.simple_tag(takes_context=True)
def failed_messages(context, user):
    """ returns number of failed/not ignored messages """
    isTestArea = False
    if 'switch_test_on_off' in context.request.session and \
        context.request.session['switch_test_on_off'] == 'true':
        isTestArea = True
    franchise_id = get_user_franchise_id(user, context['request'])
    if franchise_id:
        return get_failed_messages(franchise_id, isTestArea)
    else: 
        return 0

@register.simple_tag(takes_context=True)
def mci_count(context, user):
    """ returns number of mci jobs """

    isTestArea = False
    if 'switch_test_on_off' in context.request.session and \
        context.request.session['switch_test_on_off'] == 'true':
        isTestArea = True
    franchise_id = get_user_franchise_id(user, context['request'])
    mci_count = Job.objects.filter(
        manual_check_in=True,
        customer__booking_road__area__franchise__id=franchise_id,
        job_status__job_is_done=True,
        customer__booking_road__area__is_test_area=isTestArea
        ).count()
    return mci_count


@register.simple_tag(takes_context=True)
def sent_invoices_count(context, user):
    """ returns number of 'sent' invoices for franchise """

    franchise_id = get_user_franchise_id(user, context['request'])
    sent_invoices_count = Invoice.objects.filter(
        status=SENT,
        franchise__id=franchise_id
    ).count()

    return sent_invoices_count


@register.simple_tag(takes_context=True)
def canvasser_set_up_custs(context, user):
    """ returns number of customers to set up """

    franchise_id = get_user_franchise_id(user, context['request'])
    isTestArea = False
    if 'switch_test_on_off' in context.request.session and \
        context.request.session['switch_test_on_off'] == 'true':
        isTestArea = True
    canvasser_set_up_custs = Customer.objects.filter(
        business_source_canvasser__isnull=False,
        booking_road__area__franchise__id=franchise_id,
        booking_road__area__is_test_area=isTestArea
        ).exclude(
            is_set_up_choice=IS_SETUP_COMPLETE
            ).exclude(
                is_set_up_choice=IS_SETUP_AUTOMATED
                ).count()
    return canvasser_set_up_custs

@register.simple_tag(takes_context=True)
def is_set_up_choice_count(context, val):
    """ returns number of Is set up choice """

    isTestArea = False
    if 'switch_test_on_off' in context.request.session and \
        context.request.session['switch_test_on_off'] == 'true':
        isTestArea = True

    franchise_id = get_user_franchise_id(context['user'], context['request'])
    if franchise_id:
        is_set_up_choice_count = CustomerLatestJob.objects.filter(
            Q(customer_status=ACTIVE) | Q(customer_status=ENQUIRY),
            franchise=franchise_id,
            is_set_up_choice=val,
            is_test_area=isTestArea,
        ).count()
        return is_set_up_choice_count
    else:
        return None


@register.simple_tag(takes_context=True)
def todo_count(context, user):
    """ returns number of not done todos """

    request = context['request']
    isTestArea = False
    if 'switch_test_on_off' in request.session and \
        request.session['switch_test_on_off'] == 'true':
        isTestArea = True

    franchise_id = get_user_franchise_id(user, context['request'])
    todo_count = TODO.objects.filter(
        Q(customer__booking_road__area__is_test_area=isTestArea) | Q(customer__isnull=True),
        franchise__id=franchise_id,
        is_done=False,
        ).count()
    return todo_count


@register.simple_tag
def has_today_worksheet(user):
    has_today_worksheet = Job.objects.filter(
        job_status__job_status_description='Booked',
        # case sensitive with Postgres
        completed_date__isnull=True,
        window_cleaner__user=user,
        allocated_date=datetime.datetime.now().date(),
        ).exists()

    return has_today_worksheet

@register.filter
def parse_pi_changes_dict(value):
    if value is not None and value != '':
        pi_changes_dict = json.loads(value)
        return pi_changes_dict
    else:
        return ''

@register.filter(name='get_cust_other_quotes')
def get_cust_other_quotes(cust_other_quotes):
    if cust_other_quotes != '[]' and cust_other_quotes != '':
        return formatted_cust_other_quotes(cust_other_quotes)
    else:
        return ''


@register.filter(name='rebook_today_date')
def rebook_today_date(days):
    if days == 0:
        newDate = datetime.date.today()
    else:
        newDate = datetime.date.today() + datetime.timedelta(days=days)    
        if newDate.strftime("%A") == 'Sunday':
            newDate = newDate + datetime.timedelta(days=1)
    return newDate

@register.filter(name='rebook_tomorrow_date')
def rebook_tomorrow_date(days):
    newDate = datetime.date.today() + datetime.timedelta(days=days)
    return newDate

@register.filter(name='has_group')
def has_group(request, group_name):
    #group = Group.objects.get(name=group_name)
    if 'has_group_lists' in request.session and request.session['has_group_lists'] is not None:
        return group_name in request.session['has_group_lists']
    else:
        groups_list = [groups for groups in request.user.groups.all().values_list('name', flat=True)]
        request.session['has_group_lists'] = groups_list
        return group_name in groups_list    

# -- Get User Groups List comma separated ---#


@register.simple_tag()
def get_user_group(user_list_arr):
    my_groups = ', '.join(map(str, user_list_arr.groups.all()))
    my_groups = my_groups.replace("_", " ")
    return my_groups


@register.simple_tag()
def get_supl_business_source(customer):
    if customer.business_source:
        source = str(customer.business_source.business_source)
        supl_source = ''
        if source == "Existing customer":
            supl_source = customer.business_source_existing_customer
        elif source == "Local ad board":
            supl_source = customer.business_source_local_ad_board
        elif source == "Recommended - other customer":
            supl_source = customer.business_source_recommendation_customer
        elif source == "Internet":
            supl_source = customer.business_source_internet
        elif source == "Local magazine":
            supl_source = customer.business_source_local_magazine
        elif source == "Canvasser":
            supl_source == customer.business_source_canvasser
        elif source == "Window cleaner":
            supl_source = customer.business_source_window_cleaner
        elif source == "Directory":
            supl_source = customer.business_source_directory
        elif source == "Leaflet":
            supl_source = customer.business_source_leaflet
        elif source == "Local Facebook":
            supl_source = customer.business_source_leaflet
        elif source == "Digital magazine":
            supl_source = customer.busines_source_digital_magazine
        elif source == "Sponsorship":
            supl_source = customer.business_source_sponsorship

        return supl_source
    else:
        return None


@register.filter(name='replace_underscor_with_space')
def replace_underscor_with_space(value):
    return value.replace("_", " ")


@register.inclusion_tag('owes_tag.html')
def list_customer_owings(customerID):
    owings = Job.objects.filter(
        customer_id=customerID,
        owes__gt=0,
    ).values(
        'owes',
        'completed_date',
        'customer__address_line_1',
        'customer__address_line_2',
        'customer__address_line_3',
        'customer__postcode'
    ).annotate(
        wc=F('window_cleaner__user__first_name') +
        ' ' +
        F('window_cleaner__user__last_name'),
    )
    return {'owings': owings}


@register.inclusion_tag('worksheet_user_list.html', takes_context=True)
def list_user_worksheets(context, user):
    franchise_id = get_user_franchise_id(user, context['request'])
    ws_list = ''
    is_franchisee = User.objects.filter(
        id=user.id,
        groups__name='franchisee'
    ).exists()
    is_wc = User.objects.filter(
        id=user.id,
        groups__name='window_cleaner'
    ).exists()
    if is_franchisee:
        ws_list = WindowCleaner.objects.filter(
            franchise__id=franchise_id,
        ).annotate(
            slug=Concat(
                F('user__first_name'),
                Value('-'), F('user__last_name'),
                output_field=CharField()
            )
        )
    else:
        ws_list = WindowCleaner.objects.filter(
            user=user
        ).annotate(
            slug=Concat(
                F('user__first_name'),
                Value('-'),
                F('user__last_name'),
                output_field=CharField()
            )
        )
    return {'ws_list': ws_list,
            'my_id': user.id,
            'is_wc': is_wc,
            }


@register.inclusion_tag('owings_user_list.html', takes_context=True)
def list_user_owing_links(context, user):
    franchise_id = get_user_franchise_id(user, context['request'])
    ws_list = ''
    is_franchisee = User.objects.filter(
        id=user.id,
        groups__name='franchisee'
    ).exists()
    if is_franchisee:
        ws_list = WindowCleaner.objects.filter(
            franchise__id=franchise_id
        ).annotate(
            slug=Concat(
                F('user__first_name'),
                Value('-'),
                F('user__last_name'),
                output_field=CharField()
            )
        )
    else:
        ws_list = WindowCleaner.objects.filter(
            user=user
        ).annotate(
            slug=Concat(
                F('user__first_name'),
                Value('-'),
                F('user__last_name'),
                output_field=CharField()
            )
        )
    return {'ws_list': ws_list,
            'my_id': user.id
            }


def get_sec(time_str):
    h, m, s = str(time_str).split(':')
    return int(h) * 3600 + int(m) * 60 + int(s)


@register.filter(name='times')
def times(number):
    return range(number-1)


@register.filter(name='convert_time_am_pm')
def convert_time_am_pm(number):
    if number != '':
        time_return = datetime.datetime.strptime(
            str(number), "%H:%M"
        ).strftime("%I:%M%p")

        return time_return.replace(':00', '').lstrip("0").replace(" 0", " ")
    else:
        return ""


@register.filter(name='convert_time_to_hours_minute')
def convert_time_to_hours_minute(number):
    total_seconds = number
    intervals = (
        ('h', 3600),    #60 * 60
        ('m', 60),
    )
    result = []
    for name, count in intervals:
        value = total_seconds // count
        if value:
            total_seconds -= value * count
            if value == 1:
                name = name.rstrip('s')
            result.append("{}{}".format(value, name))
    return ' '.join(result[:2])
    return None


@register.filter(name='get_the_day_of_week')
def get_the_day_of_week(week_date):
    date_parms = week_date.split('-')
    get_week_date = datetime.date(
        int(date_parms[0]),
        int(date_parms[1]),
        int(date_parms[2])
    )
    day_number = get_week_date + datetime.timedelta(days=1)
    if day_number.weekday() == 0:
        return 7
    else:
        return day_number.weekday()


@register.filter(name='generate_date_from_str')
def generate_date_from_str(date_str):
    date_parms = date_str.split('-')
    generated_date = datetime.date(
        int(date_parms[0]),
        int(date_parms[1]),
        int(date_parms[2])
    )
    return generated_date


@register.filter(name='diary_entry_type')
def diary_entry_type(entry_type):
    if entry_type == 'notes':
        return 'Note'
    elif entry_type == 'holiday':
        return 'Hols'
    elif entry_type == 'sick_leave':
        return 'Sick'
    elif entry_type == 'working_hours':
        return 'Hours'
    elif entry_type == 'add_wants':
        return 'Wants'


@register.filter(name='local_number')
def local_number(phone_number):
    try:
        if phone_number:
            return phonenumbers.format_number(
                phone_number,
                phonenumbers.PhoneNumberFormat.NATIONAL
            )
        else:
            return None
    except AttributeError:
        return phone_number

@register.filter(name='plus_days')
def plus_days(date, days):
    return date + datetime.timedelta(days=days)


@register.filter(name='user_franchise')
def user_franchise(user, request):
    franchise = get_user_franchise(user, request)
    return franchise


@register.inclusion_tag('impersonate_header.html', takes_context=True)
def show_impersonate_data(context, user):
    request = context['request']

    user_groups = list(user.groups.all().values_list('name', flat=True))
    # evaluate the qs to avoid multiple trips to the db
    group_list = []
    user_group_data = []

    if 'franchisor' not in user_groups and 'customer_care' not in user_groups:
        franchise_id = get_user_franchise_id(user, context['request'])
        if 'wc_multi_franchise' in request.session and request.session['wc_multi_franchise']:
            user_franchise_id_list = [franchise.id for franchise in user.windowcleaner.franchise.all()]
            user_franchise_id = user_franchise_id_list
        else:
            user_franchise_id = [franchise_id]

    # if 'franchisor' in user_groups:
    #     group_list = ['franchisee', 'franchise_admin', 'window_cleaner']
    # elif 'franchisee' in user_groups:
    #     group_list = ['franchise_admin', 'window_cleaner']
    # elif 'franchise_admin' in user_groups:
    #     group_list = ['window_cleaner']
    # elif 'window_cleaner' in user_groups:
    #     group_list = []

    group_list = ['window_cleaner']
    user_list = []
    if len(group_list) > 0:
        # reduce(operator.or_, q_list)
        if 'franchisor' in user_groups or 'customer_care' in user_groups:
            if 'franchisor_data_display' in request.session:
                if request.session['franchisor_data_display'] is False:
                    group_list = []
                    user_list = []
                else:
                    q_list = [
                        Q(
                            franchisee__franchise_id=request.session[
                                'franchisor_data_values'
                                ]
                            ),
                        Q(
                            franchiseadmin__franchise_id=request.session[
                                'franchisor_data_values'
                                ]
                            ),
                        Q(
                            windowcleaner__franchise__id=request.session[
                                'franchisor_data_values'
                                ]
                            ),
                    ]
                    reduce(operator.or_, q_list)
                    user_list = User.objects.prefetch_related(
                        'user__groups','windowcleaner__franchise'
                    ).filter(
                        reduce(operator.or_, q_list),
                        groups__name__in=group_list, is_active=True
                    ).exclude(id=user.id).values(
                        'id', 'username', 'first_name',
                        'last_name', 'groups__name'
                    ).distinct('pk').order_by('pk', 'groups__name', 'username')
        else:
            q_list = [
                Q(franchisee__franchise_id__in=user_franchise_id),
                Q(franchiseadmin__franchise_id__in=user_franchise_id),
                Q(windowcleaner__franchise__id__in=user_franchise_id),
            ]
            reduce(operator.or_, q_list)
            user_list = User.objects.prefetch_related(
                        'user__groups',
                    ).filter(
                reduce(operator.or_, q_list),
                groups__name__in=group_list, is_active=True
                ).values(
                    'id', 'username', 'first_name', 'last_name', 'groups__name'
                ).distinct('pk').order_by('pk', 'groups__name', 'username')

        group_list.sort()
        for user_data in user_list:
            user_group_data.append(user_data['groups__name'])
            # print(user_group_data)

    # print(group_list)
    switch_test_on_off = 'false'
    if 'switch_test_on_off' in request.session and \
        request.session['switch_test_on_off'] == 'true':
        switch_test_on_off = 'true'

    return {
        'user_list': user_list, 'group_list': group_list,
        'group_count': len(group_list), 'user_group_data': user_group_data,
        'switch_test_on_off':switch_test_on_off
    }


@register.inclusion_tag('impersonate_logout.html', takes_context=True)
def show_impersonate_logout(context, user):
    impersonate_data_exist = False
    impersonate_session_len = 0
    request = context['request']
    user_groups = list(user.groups.all().values_list('name', flat=True))
    # evaluate the qs to avoid multiple trips to the db

    if 'impersonate_arr' in request.session:
        impersonate_session = request.session['impersonate_arr']
        impersonate_session_len = len(impersonate_session)
        if impersonate_session_len > 0:
            impersonate_data_exist = True

        if impersonate_session_len == 1:
            franchisee_and_wc = ['franchisee', 'window_cleaner']
            franchisor_and_wc = ['franchisor', 'window_cleaner']
            franchise_admin_and_wc = ['franchise_admin', 'window_cleaner']

            is_window_cleaner_result = 'window_cleaner' in user_groups
            franchisee_and_wc_result = all(elem in franchisee_and_wc  for elem in user_groups)
            franchisor_and_wc_result = all(elem in franchisor_and_wc  for elem in user_groups)
            customer_care_and_wc_result = all(elem in franchisee_and_wc  for elem in user_groups)
            franchise_admin_and_wc_result = all(elem in franchise_admin_and_wc  for elem in user_groups)

            if is_window_cleaner_result:
                impersonate_data_exist = True
            elif franchisee_and_wc_result:
                impersonate_data_exist = True
            elif franchisor_and_wc_result:
                impersonate_data_exist = True
            elif customer_care_and_wc_result:
                impersonate_data_exist = True
            elif franchise_admin_and_wc_result:
                impersonate_data_exist = True
            else:
                if impersonate_session[0] != user.id:
                    impersonate_data_exist = True
                else:
                    impersonate_data_exist = None
    else:
        request.session['impersonate_arr'] = []
        if 'franchisor' in user_groups:
            request.session['which_user_group_logged_in'] = 'franchisor'
        elif 'customer_care' in user_groups:
            request.session['which_user_group_logged_in'] = 'customer_care'
        elif 'franchise_admin' in user_groups:
            request.session['which_user_group_logged_in'] = 'franchise_admin'
        elif 'franchisee' in user_groups:
            request.session['which_user_group_logged_in'] = 'franchisee'
        else:
            request.session['which_user_group_logged_in'] = 'window_cleaner'
    
    user_initials = ''.join(
        (
            user.first_name[:1],
            user.middle_name[:1],
            user.last_name[:1]
        )
    )    

    switch_test_on_off = 'false'
    if 'switch_test_on_off' in request.session and \
        request.session['switch_test_on_off'] == 'true':
        switch_test_on_off = 'true'

    return {
        'logged_user':user,
        'impersonate_user_initials': user_initials,
        'impersonate_session_len': impersonate_session_len,
        'impersonate_session': request.session['impersonate_arr'],
        'impersonate_data_exist': impersonate_data_exist,
        'which_user_group_logged_in': request.session['which_user_group_logged_in'],
        'switch_test_on_off':switch_test_on_off
    }


@register.filter(name='is_header_franchise_selected')
def is_header_franchise_selected(request):
    if 'franchisor_data_display' in request.session:
        if int(request.session['franchisor_data_values']) != 0:
            return request.session['franchisor_data_values']
        else:
            return False
    else:
        return False


@register.inclusion_tag('franchiser_dropdown.html', takes_context=True)
def show_franchisor_data(context, user):
    request = context['request']
    users_id = user.id
    franchisor_data_values = 0
    user_groups = user.groups.all().values_list('name', flat=True)
    current_user_groups = user.groups.filter(
        user=user.id
    ).values_list('name', flat=True)

    isTestArea = False
    if 'switch_test_on_off' in request.session and \
        request.session['switch_test_on_off'] == 'true':
        isTestArea = True

    franchisee_data = franchisee_data_list = []
    if 'franchisor' in current_user_groups or 'customer_care' in current_user_groups:
        unactioned_messages = Message.objects.select_related(
            'customer__booking_road__area'
        ).filter(
            Q(actioned=False) &
            Q(outgoing=False) &
            Q(Q(customer__booking_road__area__is_test_area=isTestArea) | Q(customer__booking_road__area__is_test_area__isnull=True))            
            ).values('franchise_id').annotate(count=Count('id')).order_by()
        unactioned_messages_subquery = unactioned_messages.filter(
            franchise__id=OuterRef('id')
            )
        franchisee_data = Franchise.objects.filter(
            inactive=False
            ).annotate(
                unactioned_messages=Subquery(unactioned_messages_subquery.values('count'),
                output_field=IntegerField()
            )
        ).only('dropdown_display', 'id',)

        today_date = datetime.datetime.today()
        week_start_date = today_date - datetime.timedelta(days=today_date.weekday())
        week_end_date = week_start_date + datetime.timedelta(days=7)        

        weekly_cct_times = {}

        agreed_weekly_support = WeeklyCustomerCareBookedTime.objects.filter(
            valid_from__lte=today_date.strftime('%Y-%m-%d'),
            franchise__in=franchisee_data,
            category__category='Support'
        ).annotate(
            last_joined=Max('valid_from'),
        ).order_by('last_joined').all()

        for agreed_w_support in agreed_weekly_support:
            weekly_cct_times[agreed_w_support.franchise_id] = agreed_w_support

        support_time_this_week = {}
        support_time_used_this_week = CustomerCareTime.objects.select_related(
            'category','franchise'
            ).filter(
                start_time__date__gte=week_start_date.strftime('%Y-%m-%d'),
                start_time__date__lt=week_end_date.strftime('%Y-%m-%d'),
                franchise__in=franchisee_data,
                category__category='Support'
            ).values('franchise').annotate(
                support_total_hours = Sum(
                    ExpressionWrapper(
                        Ceil((Epoch(F('end_time'))-Epoch(F('start_time')))/Value(60.0))*Value(60), output_field=DurationField()
                        )
                    )
            )
        for support_time_used in support_time_used_this_week:
            support_time_this_week[support_time_used['franchise']] = support_time_used


        def get_franchise_cct_times(franchise):
            unlimited_support = False
            if franchise.id in weekly_cct_times:                
                if weekly_cct_times[franchise.id].unlimited_hours:
                    unlimited_support = True

            remaining_support_time = remaining_support_tot_sec = 0
            support_total_time_total_seconds = 0
            agreed_weekly_support_hours = ''
            if franchise.id in support_time_this_week:    
                if support_time_this_week[franchise.id]['support_total_hours'] is not None:
                    support_total_time_total_seconds = support_time_this_week[franchise.id]['support_total_hours']
            
            if support_total_time_total_seconds != 0 and franchise.id in weekly_cct_times:
                agreed_weekly_support_total_seconds = weekly_cct_times[franchise.id].hours * 60 * 60
                remaining_support_time = agreed_weekly_support_total_seconds - int(support_total_time_total_seconds)
                remaining_support_tot_sec = remaining_support_time
                remaining_support_time = fn_get_total_hours( remaining_support_time)
                agreed_weekly_support_hours = fn_get_total_hours( agreed_weekly_support_total_seconds)
            elif franchise.id in weekly_cct_times:
                agreed_weekly_support_total_seconds = weekly_cct_times[franchise.id].hours * 60 * 60
                remaining_support_tot_sec = agreed_weekly_support_total_seconds
                remaining_support_time = fn_get_total_hours( remaining_support_tot_sec)
                agreed_weekly_support_hours = fn_get_total_hours( agreed_weekly_support_total_seconds)
            else:
                remaining_support_time = remaining_support_tot_sec = 0
            
            franchise_cct_times = {
                'remaining_support_time': remaining_support_time,
                'remaining_support_tot_sec': remaining_support_tot_sec,
                'unlimited_support': unlimited_support,
                'agreed_weekly_support_hours': agreed_weekly_support_hours
            }
            
            return franchise_cct_times
        
        for franchise in franchisee_data:
            franchisee_data_dict = {}
            franchise_cct_times = get_franchise_cct_times(franchise)
            if franchise_cct_times['unlimited_support'] == True:
                cct_time_this_week = mark_safe('<span class="text-primary">Unlim<span>')
            elif franchise_cct_times['remaining_support_tot_sec'] > 0:
                cct_time_this_week = mark_safe('<span class="text-success">'+franchise_cct_times['remaining_support_time']+'/'+franchise_cct_times['agreed_weekly_support_hours']+'<span>')
            elif franchise_cct_times['remaining_support_tot_sec'] == 0:
                cct_time_this_week = ''
            else:
                cct_time_this_week = mark_safe('<span class="text-danger">'+franchise_cct_times['remaining_support_time']+'/'+franchise_cct_times['agreed_weekly_support_hours']+'<span>')

            franchisee_data_dict = {
                'id':  franchise.id,
                'dropdown_display':  franchise.dropdown_display,
                'unactioned_messages': franchise.unactioned_messages,
                'cct_time_this_week': cct_time_this_week
            }

            franchisee_data_list.append(franchisee_data_dict)
        

    if 'franchisor_data_display' in request.session:
        if request.session['franchisor_data_display'] is False:
            group_list = []
            user_list = []
        else:
            franchisor_data_values = request.session['franchisor_data_values']

    return {
        'franchisee_data': franchisee_data_list,
        'current_user_groups': current_user_groups,
        'franchisor_data_values': int(franchisor_data_values)
    }


"""
Set a variable in Django template
Creating a custom template tag for assigning variables in Django template.
"""


class SetVarNode(template.Node):

    def __init__(self, var_name, var_value):
        self.var_name = var_name
        self.var_value = var_value

    def render(self, context):
        try:
            value = template.Variable(self.var_value).resolve(context)
            # print(self.var_name,'==',value)
        except template.VariableDoesNotExist:
            value = ""
        context[self.var_name] = value
        return u""


@register.tag(name='set')
def set_var(parser, token):
    """
    {% set some_var = '123' %}
    """
    parts = token.split_contents()

    if len(parts) < 4:
        raise template.TemplateSyntaxError(
            "'set' tag must be of the form: {% set <var_name> = <var_value> %}"
            )

    return SetVarNode(parts[1], parts[3])


@register.inclusion_tag('current_user_franchisee.html', takes_context=True)
def ShowUserFranchise(context, user):
    user_franchise = get_user_franchise(user, context['request'])
    if user_franchise:
        return {'user_franchise': user_franchise.dropdown_display}
    else:
        return {'user_franchise': ''}


@register.filter()
def setting_value(setting_name):
    setting = Setting.objects.get(key=str(setting_name))
    data_return = None
    #for data in setting:
    if setting.setting_type == 'I':
        data_return = setting.image.url
    else:
        data_return = setting.value
    return data_return


@register.filter()
def current_site_url(request):
    """Returns fully qualified URL (no trailing slash) for the current site."""
    from django.contrib.sites.shortcuts import get_current_site
    current_site = get_current_site(request)
    protocol = getattr(settings, 'MY_SITE_PROTOCOL', 'http')
    port = getattr(settings, 'MY_SITE_PORT', '')
    url = '%s://%s' % (protocol, current_site.domain)
    if port:
        url += ':%s' % port
    return url


@register.filter(name='thumbnail')
def thumbnail(file, args):
    """
        In args 2 contains parameters 1 for size and second for folder_name
        uses = {{image_object|thumbnail:'200x200,folder_name'}}
     """
    # defining the size
    _params = args.split(',')
    if len(_params) == 0:
        size = "200x200"
        folder_name = "users_images"
    elif len(_params) == 1:
        size = _params[0]
        folder_name = "users_images"
    elif len(_params) == 2:
        size = _params[0]
        folder_name = _params[1]

    x, y = [int(x) for x in size.split('x')]
    # defining the filename and the miniature filename
    filehead, filetail = os.path.split(file.path)
    basename, format = os.path.splitext(filetail)
    miniature = basename + '_' + size + format

    # filename = file.path
    # print(filehead+'/users_images/'+filetail)
    if os.path.exists(filehead+'/'+folder_name+'/'+filetail):
        filename = filehead+'/'+folder_name+'/'+filetail
        filehead = filehead+'/'+folder_name+'/'
    else:
        filename = file.path

    # print(filename)
    # return False
    miniature_filename = os.path.join(filehead, miniature)
    filehead, filetail = os.path.split(file.url)
    miniature_url = filehead + '/' + miniature
    if os.path.exists(
        miniature_filename
        ) and os.path.getmtime(filename) > os.path.getmtime(
            miniature_filename
            ):
        os.unlink(miniature_filename)

    # if the image wasn't already resized, resize it
    if not os.path.exists(miniature_filename):
        image = Image.open(filename)
        new_image = image.resize([x, y], Image.ANTIALIAS)
        # image.thumbnail([x, y], Image.ANTIALIAS)
    try:
        # image.save(miniature_filename, image.format, quality=90, optimize=1)
        new_image.save(miniature_filename, image.format,
                       quality=95, optimize=1)
    except:
        return miniature_url

    return miniature_url


@register.filter(name='split')
def split(value, key):
    return value.split(key)


@register.filter(name='check_is_working_or_not')
def check_is_working_or_not(date_txt, user_id):
    week_day = get_the_day_of_week(date_txt)
    is_working = False
    try:
        availability_hours = AvailabilityHours.objects.filter(
            user_id=int(user_id)
        ).values('weekday')

        if availability_hours:
            week_days_lists = []
            for availability in availability_hours:
                week_days_lists.append(availability['weekday'])

            if week_day in week_days_lists:
                is_working = True
            else:
                is_working = False

        user_diary_data = UserDiary.objects.filter(
            user_id=int(user_id),
            start_date__gte=date_txt,
            end_date__lte=date_txt
        ).values('id','user_id','start_date','end_date')
        user_id_lists = []
        if user_diary_data:
            for user_diary in user_diary_data:
                user_id_lists.append(user_diary['user_id'])

            if user_id in user_id_lists:
                is_working = True

        return is_working

    except Exception as e:
        print('error in check_is_working_or_not: ', str(e))
        pass


@register.filter(name='check_user_diary_data')
def check_user_diary_data(full_date, diary_data):
    count = 1
    is_user_diary_data = False
    for data in diary_data:
        if full_date >= generate_date_from_str(data[1]['start_date']).strftime('%Y-%m-%d') and \
            full_date <= generate_date_from_str(data[1]['end_date']).strftime('%Y-%m-%d'):
            is_user_diary_data = True
        count += 1

    return is_user_diary_data


@register.filter(name='add_allocated_data')
def add_allocated_data(full_date, diary_data):
    allocated_on = 0
    allocated_off = 0
    for key, data in diary_data:
        if (full_date == data['check_date']):
            allocated_on += data['allocated_on_rota']
            allocated_off += data['allocated_off_rota']
    if (allocated_on == 0 and allocated_off == 0):
        return ''
    else:
        return format_html('<span>'+currency(allocated_on)+'</span> / '+'<span class="green_currency">'+currency(allocated_off)+'</span>')


@register.filter(name='add_booked_data')
def add_booked_data(full_date, diary_data):
    booked_on = 0
    booked_off = 0
    for key, data in diary_data:
        if (full_date == data['check_date']):
            booked_on += data['booked_on_rota']
            booked_off += data['booked_off_rota']
    if (booked_on == 0 and booked_off == 0):
        return ''
    else:
        return format_html('<span>'+currency(booked_on)+'</span> / '+'<span class="green_currency">'+currency(booked_off)+'</span>')


@register.filter(name='turnover_data')
def turnover_data(full_date, diary_data):
    turnover_completed = 0
    turnover_not_completed = 0
    for key, data in diary_data:
        if full_date == data['check_date']:
            if (data['job_completed'] == True):
                turnover_completed += data['job_turnover']
            else:
                turnover_not_completed += data['job_turnover']
    if (turnover_completed == 0 and turnover_not_completed == 0):
        return ''
    else:
        return format_html('<span>'+currency(turnover_completed)+'</span> <br/>'+'<span class="red_currency">'+currency(turnover_not_completed)+'</span>')


@register.filter(name='add_area_data')
def add_area_data(full_date, diary_data):
    job_area = []
    job_area_string = ''
    for key, data in diary_data:
        if (full_date == data['check_date'] and data['job_area'] not in job_area):
            job_area.append(data['job_area'])
            if (job_area_string != ''):
                job_area_string = job_area_string + ', ' + data['job_area']
            else:
                job_area_string = data['job_area']
    return job_area_string


@register.filter(name='plus_hours_in_time')
def plus_hours_in_time(given_time, hours_var):
    converted_date_time_obj = datetime.datetime.strptime(
        given_time, "%Y-%m-%d %H:%M:%S"
    )
    hours_from_now = converted_date_time_obj + datetime.timedelta(hours=hours_var)
    date_time = str(hours_from_now).split(' ')
    return date_time[1][:-3]


@register.filter(name='parse_date')
def parse_date(date_string, format):
    """
    Return a datetime corresponding to date_string, parsed according to format.

    For example, to re-display a date string in another format::

        {{ "01/01/1970"|parse_date:"%m/%d/%Y"|date:"F jS, Y" }}

    """
    try:
        return datetime.datetime.strptime(date_string, format)
    except ValueError:
        return None


@register.filter(name='get_avail_working_hour')
def get_avail_working_hour(full_date, availability_hour):
    week_day = get_the_day_of_week(full_date)
    default_working_hours = {}
    for data in availability_hour:
        if data[1]['weekday'] == week_day:
            default_working_hours = {
                'from_hour':data[1]['from_hour'],
                'to_hour':data[1]['to_hour'],
            }

    return default_working_hours


@register.tag()
def setList(parser, token):
    """
    Use : {% setList par1 par2 ... parN as listName %}
    'par' can be a simple variable or a list
    To set an empty list: {% setList '' as listName %}
    """
    data = list(token.split_contents())
    if len(data) >= 4 and data[-2] == "as":
        listName = data[-1]
        items = data[1:-2]
        return SetListNode(items, listName)
    else:
        raise template.TemplateSyntaxError(
            "Erreur ! L'utilisation de %r est la suivante : {%% setList par1 par2 ... parN as listName %%}" % data[0]
        )


class SetListNode(template.Node):

    def __init__(self, items, listName):
        self.items = []
        for item in items: self.items.append(template.Variable(item))
        self.listName = listName

    def render(self, context):
        finalList = []
        for item in self.items:
            itemR = item.resolve(context)
            if isinstance(itemR, list):
                finalList.extend(itemR)
            elif itemR == '':
                pass
            else:
                finalList.append(itemR)
        context.set_upward(self.listName, list(finalList))
        return ""  # django doc : render() always returns a string
        

def set_upward(self, key, value):
    """
    Set a variable in one of the higher contexts if it exists there,
    otherwise in the current context.
    """
    context = self.dicts[-1]
    for d in reversed(self.dicts):
        if key in d.keys():
            context = d
            break
    context[key] = value


@register.filter(name='placeholder')
def placeholder(value, token):
    value.field.widget.attrs["placeholder"] = token
    return value

@register.filter(name='total_trunover_jobs')
def total_trunover_jobs(jobs):
    due_jobs_trunover = 0
    for job in jobs:
        due_jobs_trunover += job['price_str']
    return due_jobs_trunover


@register.filter(name='total_time_needed_jobs')
def total_time_needed_jobs(jobs):
    total_time_needed = 0
    for job in jobs:
        if job['time_needed'] is not None:
            total_time_needed += int(job['time_needed'].total_seconds())
        else:
            total_time_needed = int(total_time_needed)

    converted_time = convert_time_to_hours_minute(total_time_needed)
    return converted_time

@register.filter(name='book_with_abbreviate')
def book_with_abbreviate(book_with_str):

    book_with_str = book_with_str
    if book_with_str == 'Email':
        book_with_str = 'EM'
    elif book_with_str == 'Text Only' or book_with_str == 'Text':
        book_with_str = 'Tx'
    elif book_with_str == 'Phone Customer':
        book_with_str = 'Ph'
    elif book_with_str == 'Just Book':
        book_with_str = 'JB'
    elif book_with_str == 'Needs Automating':
        book_with_str = 'TBA'

    return book_with_str


@register.filter(name='get_user_initial_name')
def get_user_initial_name(user_full_name):

    initials_val = generate_user_initial(user_full_name)
    return initials_val


@register.filter(name='get_job_time_slot')
def get_job_time_slot(job_id):

    """
    Get Job Time Slot Str
    """
    return get_job_time_slot_str(job_id)


@register.filter(name='get_allocate_time_slot')
def get_allocate_time_slot(job_id):

    """
    Get Allocate Date Time Slot Str
    """
    return get_allocate_time_slot_str(job_id)

@register.filter(name='get_day_two_time_slot')
def get_day_two_time_slot(job_id):

    """
    Get Day Two Time Slot Str
    """
    return get_day_two_time_slot_str(job_id)


@register.filter(name='get_allocate_day2_time_slot')
def get_allocate_day2_time_slot(job_id):

    """
    Get Allocated and Day Two Time Slot Str
    """
    return get_allocate_day2_time_slot_str(job_id)

@register.filter(name='get_customer_default_time_slots')
def get_customer_default_time_slots(customer_id,job_id):
    """
    Get Customer Time Slot Str
    """
    return get_customer_time_slot_str(customer_id,job_id)

@register.filter(name='get_customer_default_time_span_slots')
def get_customer_default_time_span_slots(customer_id):

    """
    Get Customer Time Slot Str
    """
    return get_customer_time_slot_span_str(customer_id,'default')

@register.filter(name='get_job_time_slot_dates')
def get_job_time_slot_dates(job_id):

    """
    Get Job Time Slot Dates Only
    """
    job_time_slot_set = TimeSlot.objects.filter(job_id=job_id)
    result = []
    for time_slot in job_time_slot_set:
        result.append(str(time_slot.date))
    return ','.join(result)


@register.filter(name='get_job_time_slot_json_response')
def get_job_time_slot_json_response(job_id):

    """
    Get Job Time Slot Dates Only
    """
    job_time_slot_set = TimeSlot.objects.filter(job_id=job_id)
    results = []
    response_message = {}
    for time_slot in job_time_slot_set:
        if time_slot.start_time is not None:
            start_time_val = time_slot.start_time.strftime("%I:%M")
        else:
            start_time_val = time_slot.start_time

        if time_slot.end_time is not None:
            end_time_val = time_slot.end_time.strftime("%I:%M")
        else:
            end_time_val = time_slot.end_time

        jobs_new_dict = {
            "slot_date" : time_slot.date.strftime('%d/%m/%Y'),
            "start_time" : start_time_val,
            "end_time" : end_time_val,
            "Not_flag" : time_slot.NOT_flag,
            "is_specific_appointment" : time_slot.is_specific_appointment,
        }
        results.append(jobs_new_dict)
    response_message['time_slot_lists'] = results
    return json.dumps(response_message)


@register.filter(name='diff_btn_two_dates')
def diff_btn_two_dates(start_date,end_date):

    """
    Get date difference between two dates
    """

    date_format = "%Y-%m-%d"
    if start_date is not None and end_date is not None:
        start_date = datetime.datetime.strptime(str(start_date), date_format)
        end_date = datetime.datetime.strptime(str(end_date), date_format)
        date_diff_day = end_date - start_date
        return format_html(start_date.strftime('%d/%m/%Y')[0:5] + '<br/> ('+ str(date_diff_day.days) +')')
    else:
        return '-'

@register.filter(name='get_days_between_two_dates')
def get_days_between_two_dates(start_date,end_date):

    """
    Get days between two dates
    """

    date_format = "%Y-%m-%d"
    if start_date is not None and end_date is not None:
        start_date = datetime.datetime.strptime(str(start_date), date_format)
        end_date = datetime.datetime.strptime(str(end_date), date_format)
        date_diff_day = start_date - end_date
        return date_diff_day.days
    else:
        return ''

@register.filter(name='format_datetime')
def format_datetime(value):
    if value is not None and value != '':
        seconds = value.total_seconds()
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        return '{0:.0f}h{1:02.0f}'.format(hours, minutes)
    else:
        return ''

@register.simple_tag()
def get_original_user(request):
    if 'impersonate_arr' in request.session and len(request.session['impersonate_arr'])>0:
        try:
            original_user = User.objects.get(id=request.session['impersonate_arr'][0])
        except ObjectDoesNotExist:
            return ''
        return original_user
    return ''


@register.filter(name='get_franchise_id')
def get_franchise_id(user, request):
    try:
        return user.franchisee.franchise.id
    except AttributeError:
        try:
            return user.franchiseadmin.franchise.id
        except AttributeError:
            try:
                return user.windowcleaner.franchise.id
            except AttributeError:
                try:
                    if 'franchisor_data_display' in request.session:
                        if int(request.session['franchisor_data_values']) != 0:
                            franchise = Franchise.objects.get(
                                pk=request.session['franchisor_data_values'])
                            return franchise.id
                        else:
                            return None
                    else:
                        return None
                except Exception as e:
                    print('error in get_franchise_id: ', str(e))
                    return None
    return None

@register.simple_tag
def define(val=None):
    return val


@register.filter()
def get_frequency_text(frequency_choice=0):
    if frequency_choice == 0:
        return 'One off'
    elif frequency_choice == -1:
        return 'Not sure'
    elif frequency_choice == 1:
        return 'Once a week'
    elif frequency_choice >= 52:
        return 'Once a year'
    elif frequency_choice < 4:
        return 'Every %s weeks' % str(frequency_choice)
    else:
        return 'Every %s weeks (%s mo)' % (str(frequency_choice), str(math.ceil(frequency_choice*0.23)))


@register.filter(is_safe=True)
def label_with_classes(value, arg):
    return value.label_tag(attrs={'class': arg})


@register.filter()
def convert_string_to_list(string_list):
    new_list = list(filter(None, ast.literal_eval(string_list)))
    return new_list

@register.filter()
def comma_string_to_list(string_list):
    new_list = string_list.split(", ")
    return new_list


# Register filter
@register.filter(name='sectodur')
def sectodur(value, arg):

    """
    #######################################################
    #                                                     #
    #   Seconds-to-Duration Template Tag                  #
    #                                                     #
    #######################################################


    Usage: {{ VALUE|sectodur:"not_second,sort" }}


    NOTE: Please read up 'Custom template tags and filters'
          if you are unsure as to how the template tag is
          implemented in your project.
    """
    _params = arg.split(',')
    if 'not_second' in _params:
        #print(value)
        #(h, m, s) = str(value).split(':')
        #time_needed = datetime.timedelta(hours=int(h), minutes=int(m), seconds=int(s))
        total_seconds = value.total_seconds()
    else:
        total_seconds = value


    # Place seconds in to integer
    secs = int(total_seconds)

    # If seconds are greater than 0
    if secs > 0:

        # Import math library
        import math

        # Place durations of given units in to variables
        daySecs = 86400
        hourSecs = 3600
        minSecs = 60

        # If short string is enabled
        if 'sort' in _params:

            # Set short names
            dayUnitName = 'day'
            hourUnitName = 'h'
            minUnitName = 'm'
            secUnitName = 's'

            # Set short duration unit splitters
            lastDurSplitter = ''
            nextDurSplitter = lastDurSplitter

        # If short string is not provided or any other value
        elif 'long' in _params:

            # Set long names
            dayUnitName = ' day'
            hourUnitName = ' hour'
            minUnitName = ' minute'
            secUnitName = ' second'

            # Set long duration unit splitters
            lastDurSplitter = ' and '
            nextDurSplitter = ', '

        # Create string to hold outout
        durationString = ''
        # Calculate number of days from seconds
        days = int(math.floor(secs / int(daySecs)))
        # Subtract days from seconds
        secs = secs - (days * int(daySecs))
        # Calculate number of hours from seconds (minus number of days)
        hours = int(math.floor(secs / int(hourSecs)))
        # Subtract hours from seconds
        secs = secs - (hours * int(hourSecs))
        # Calculate number of minutes from seconds (minus number of days and hours)
        minutes = int(math.floor(secs / int(minSecs)))
        # Subtract days from seconds
        secs = secs - (minutes * int(minSecs))
        # Calculate number of seconds (minus days, hours and minutes)
        seconds = secs

        # If number of days is greater than 0
        if days > 0:
            # Add multiple days to duration string
            durationString += '' + \
                str(days) + dayUnitName + (days > 1 and 's' or '')

        # Determine if next string is to be shown
        if hours > 0:
            # If there are no more units after this
            if minutes <= 0 and seconds <= 0:
                # Set hour splitter to last
                hourSplitter = lastDurSplitter
            # If there are unit after this
            else:
                # Set hour splitter to next
                hourSplitter = (len(durationString) >
                                0 and nextDurSplitter or '')

        # If number of hours is greater than 0
        if hours > 0:
            # Add multiple days to duration string
            durationString += hourSplitter + '' + \
                str(hours) + hourUnitName

        # Determine if next string is to be shown
        if minutes > 0:
            # If there are no more units after this
            if seconds <= 0:
                # Set minute splitter to last
                minSplitter = lastDurSplitter

            # If there are unit after this
            else:
                # Set minute splitter to next
                minSplitter = (len(durationString) > 0 and nextDurSplitter or '')

        # If number of minutes is greater than 0
        if minutes > 0:
            # Add multiple days to duration string
            durationString += minSplitter + '' + \
                str(minutes) + minUnitName
            #print(durationString)
        # Determine if next string is last
        if seconds > 0:
            # Set second splitter
            secSplitter = (len(durationString) > 0 and lastDurSplitter or '')

        # If number of seconds is greater than 0
        if seconds > 0:
            # Add multiple days to duration string
            durationString += secSplitter + ' ' + \
                str(seconds) + secUnitName + (seconds > 1 and 's' or '')
        # Return duration string
        return durationString.strip()


    # If seconds are not greater than 0
    else:
        # Provide 'No duration' message
        return 'No duration'

@register.filter(name='to_int')
def to_int(value):
    return int(value)


@register.filter(name='time_needed_HHAColhmm')
def time_needed_HHAColhmm(value):
    if value is not None:
        time_needed_default = str(value).split(':')        
        if 'None' not in time_needed_default and len(time_needed_default) > 2:
            time_needed_default = datetime.timedelta(hours=int(time_needed_default[1]), minutes=int(time_needed_default[2]), seconds=0)
        else:
            time_needed_default = datetime.timedelta(hours=0, minutes=0, seconds=0)
    else:
        time_needed_default = datetime.timedelta(hours=0, minutes=0, seconds=0)


    try:
        sec = time_needed_default.total_seconds()
        return '%02d:%02d' % (int((sec/3600) % 3600), int((sec/60) % 60))
    except AttributeError:
        return '00:00'


@register.filter(name='get_file_name')
def get_file_name(value):
    try:
        return os.path.basename(value.file.name)
    except:
        return os.path.basename(value)


@register.filter(name='remove_tag_from_html')
def remove_tag_from_html(html):
    soup = BeautifulSoup(html, "html.parser")    

    remove_tags_list = [
        "script", 
        "style",
        "base"
,        # there may be more elements you don't want
    ]

    # Find <img> tag in html and replaced with <i> Tags image icon
    images = soup.findAll('img')
    # print('images-----',images)
    try:        
        if len(images) > 0 and images is not None:
            for img in images:
                # print(img.attrs)
                try:
                    new_tag = soup.new_tag('i')
                    new_tag['data-img-url'] = img['src']
                    if 'style' in img.attrs:
                        new_tag['data-style'] = img['style']

                    if 'alt' in img.attrs:
                        new_tag['data-alt'] = img['alt']

                    new_tag['class'] = 'text-primary fas fa-image img-place-holder'
                    try:
                        soup.find('img').replaceWith(new_tag)
                    except Exception as e:
                        print('remove_tag_from_html() - No image tag found -  ', e) 
                except KeyError:
                    pass    # empty image tag
            # remove_tags_list.append('img')

        # create a new bs4 object from the html data loaded
        for script in soup(remove_tags_list):
            # remove all javascript and stylesheet code
            script.extract()        

        return soup.encode('utf-16', 'surrogatepass').decode('utf-16').replace('\r\n', '<br>')
        
    except Exception as e:
        print('error in remove_tag_from_html: ', e)
        pass


@register.filter(name='extract_text_from_html')
def extract_text_from_html(html):
    soup = BeautifulSoup(html, "html.parser")
    text = soup.find_all(text=True)

    output = ''
    blacklist = [
        # '[document]',
        'noscript',
        'header',
        'html',
        'meta',
        'head', 
        'input',
        'script',
        'style',
        'table',
        # there may be more elements you don't want
    ]

    for t in text:
        if t.parent.name not in blacklist:
            output += '{} '.format(t)    
    
    return output.encode('utf-16', 'surrogatepass').decode('utf-16')
    

@register.filter(name='join_with_commas')
def join_with_commas(obj_list):
    """Takes a list of objects and returns their string representations,
    separated by commas and with 'and' between the penultimate and final items
    For example, for a list of fruit objects:
    [<Fruit: apples>, <Fruit: oranges>, <Fruit: pears>] -> 'apples, oranges and pears'
    """
    
    if not obj_list:
        return ""
    l=len(obj_list)
    if l==1:
        return u"%s" % obj_list[0]
    else:    
        return ", ".join(str(obj) for obj in obj_list[:l-1]) \
                + " , " + str(obj_list[l-1])


@register.filter(name='get_previous_job_data')
def get_previous_job_data(customer_id,job_id):

    """
    Get Previous Job Data
    """
    try:
        latest_job = Job.objects.filter(
            customer_id=customer_id,
            job_status__job_is_done=True
        ).select_related('job_status').exclude( id=job_id ).annotate(
            job_status_str=F('job_status__job_status_description'),
        ).values( 'job_status_str','completed_date' ).order_by(
            '-completed_date'
        ).first()
        
        #print(latest_job['completed_date'])
        if latest_job and str(latest_job['completed_date']) is not None:
            completed_date = datetime.datetime.strptime(str(latest_job['completed_date']), '%Y-%m-%d').strftime('%d/%m')
            return latest_job['job_status_str']+' '+completed_date
        else:
            return ''

    except Exception as e:
        print('Error in get_previous_job_data:', str(e))
        pass


@register.inclusion_tag('video_modals.html',takes_context=True)
def page_video_modals(context,slug):
    """ inclusion tag to return 
        video links
    """
    subquery = VideoLinkUserView.objects.filter(
        video_link=OuterRef('pk'),
        user=context['request'].user
        ).annotate(
            view_counts=Sum('views')
            )
    

    videos = VideoLink.objects.filter(video_page__slug=slug).annotate(
        view_counts=Subquery(
            subquery.values('view_counts')
        )
    )    
    return {'videos': videos,'request':context['request']}

@register.inclusion_tag('vat_calculator.html',takes_context=True)
def vat_calculator(context,job):
    """ inclusion tag to return 
        vat calculator
    """
    return {'job': job,'request':context['request']}

@register.filter('get_video_link_user_id')
def get_video_link_user_id(video_link_id):

    try:
        videos = VideoLinkUserView.objects.get(video_link_id=video_link_id)
        return int(videos.user_id)
    except VideoLinkUserView.DoesNotExist:
        return int(0)


@register.filter('video_links_counts')
def video_links_counts(video_link_id,user_id):
    """ filter tag to return 
        video links counts
    """
    # print('video_link_id----',video_link_id)
    # print('user_id----',user_id)
    try:
        videos = VideoLinkUserView.objects.get(video_link_id=video_link_id,user_id=user_id)
        return videos.views
    except VideoLinkUserView.DoesNotExist:
        return 0

@register.filter(name='weeks_max_range') 
def weeks_max_range(number):
    return range(1,int(number)+1)

@register.filter(name='BT_to_replace')
def BT_to_replace(value,wc_name):
    if value is not None and wc_name is not None:
        return str(value).replace('Bank transfer to WC','BT to '+get_user_initial_name(wc_name))
    else:
        return ''


# settings value
@register.simple_tag
def settings_value(name):
    return getattr(settings, name, "")


@register.simple_tag
def user_video_views(user, video_link):
    try:
        rec = VideoLinkUserView.objects.get(
            user=user, video_link=video_link
        )
        dic = rec.__dict__
        if dic['views']==0:
            return '-'        
        return dic['views']
    except ObjectDoesNotExist:
        return ''

    
@register.simple_tag
def video_total_views(video_link):
    sum_views = VideoLinkUserView.objects.prefetch_related(
        'user__franchisee__franchise__franchise',
        'user__franchiseadmin__franchise__franchise').annotate(
                franchise=Coalesce(
                    F('user__franchisee__franchise__franchise'),
                    F('user__franchiseadmin__franchise__franchise')
                    )
            ).filter(
                franchise__isnull=False,
                video_link=video_link
                ).aggregate(Sum('views'))

    if sum_views:
        if sum_views['views__sum'] is None:
            return 0
        else:
            return sum_views['views__sum']
    else:
        return 0

@register.filter(name='jsonify')
def jsonify(data):
    if isinstance(data, dict):
        return data
    else:
        return json.loads(data)


@register.simple_tag
def secondary_bus_sources(customerID):
    customer = Customer.objects.filter(
        pk=customerID
        ).annotate(
            canvasser=F('business_source_canvasser__user__last_name'),
            directory=F('business_source_directory__directory'),
            internet=F('business_source_internet__internet'),
            leaflet=F('business_source_leaflet__leaflet'),
            ad_board=F('business_source_local_ad_board__ad_board'),            
            magazine=F('business_source_local_magazine__magazine'),
            window_cleaner=F('business_source_window_cleaner__user__username'),
            facebook=F('business_source_local_facebook__local_facebook'),
            digital_magazine=F('business_source_digital_magazine__magazine'),
            sponsorhsip=F('business_source_sponsorship__sponsor'),
            ).get(
                pk=customerID
                )
    
    list = []
    if customer.canvasser:
        list += 'canvasser: ' + customer.canvasser or None
    if customer.directory:
        list += 'Directory: ' + customer.directory
    if customer.internet:
        list += 'Internet: ' + customer.internet
    if customer.leaflet:
        list += 'Leaflet: ' + customer.leaflet
    if customer.magazine:
        list += 'Magazine: ' + customer.magazine
    if customer.window_cleaner:
        list += 'Window cleaner: ' + customer.window_cleaner
    if customer.facebook:
        list += 'Window cleaner: ' + customer.facebook
    if customer.digital_magazine:
        list += 'Digital magazine: ' + customer.digital_magazine
    if customer.sponsorship:
        list += 'Sponsorship: ' + customer.sponsorship
    if not list:
        return ''
    else:
        return ', '.join(list)


@register.filter(name='is_show_franchise_expenses')
def is_show_franchise_expenses(user_obj):
    window_cleaner_exist = WindowCleaner.objects.filter(
                                user=user_obj).exists()
    if window_cleaner_exist:
        window_cleaner_obj = WindowCleaner.objects.get(
                    user=user_obj)
        if window_cleaner_obj.show_franchise_expenses:
            is_show_franchise_expenses = True
        else:
            is_show_franchise_expenses = False
    else:
        is_show_franchise_expenses = False

    return is_show_franchise_expenses

@register.filter(name='is_wc_invoice_checked')
def is_wc_invoice_checked(invoice_date,user_obj):

    """ Returns CheckedInvoiceStatus"""

    window_cleaner_exist = WindowCleaner.objects.filter(
                                user=user_obj).exists()
    if window_cleaner_exist:
        window_cleaner_obj = WindowCleaner.objects.get(
                    user=user_obj)
        try:
            checked_invoice_obj = CheckedInvoice.objects.get(
                        invoice_date=invoice_date,
                        window_cleaner=window_cleaner_obj
            )
            return checked_invoice_obj.checked_status
        except Exception as e:
            return CheckedInvoice.CHECK
    else:
        return CheckedInvoice.CHECK


@register.simple_tag(takes_context=True)
def all_todays_jobs_checked_in(context, user):
    """
        checks that all jobs for today have been checked in so 
        we can display the invoice check button on WC invoices
    """
    
    isTestArea = False
    request = context['request']
    isTestArea = False
    if 'switch_test_on_off' in request.session and \
        request.session['switch_test_on_off'] == 'true':
        isTestArea = True
    
    window_cleaner_exist = WindowCleaner.objects.filter(
                                user=user).exists()
    if window_cleaner_exist:
        window_cleaner = WindowCleaner.objects.get(
                    user=user)
    else:
        return False

    jobs = Job.objects.select_related(
        'job_status',
        'customer__booking_road__area'
        ).filter(
            job_status__job_is_done=False,
            allocated_date=datetime.date.today(),
            window_cleaner=window_cleaner,
            customer__booking_road__area__is_test_area=isTestArea,
        ).exists()
    if jobs:
        return False
    else:
        return True


def get_checked_invoice_sql(isTestArea, user_id, select_term, franchise_id):
    if franchise_id:
        franchise_text = 'and ff.id={0}'.format(franchise_id)
    else:
        franchise_text=''
    sql = """
        with cte as (
            select completed_date,
            window_cleaner_id, 
            sum(
               CASE WHEN jj.generates_invoice then coalesce(price_on_day, set_price)
                   ELSE 0.0
                       END
           ) turnover,
            count(j.id) as job_count
            from jobs_job j
                join customers_customer cc on cc.id = j.customer_id
                join franchises_bookingroad fb on cc.booking_road_id = fb.id
                join franchises_area fa on fb.area_id = fa.id
                join franchises_franchise ff on fa.franchise_id = ff.id
                join jobs_jobstatus jj on j.job_status_id = jj.id
                join accounts_windowcleaner aw on j.window_cleaner_id = aw.id
                join accounts_user au on aw.user_id = au.id
            where
                (
                    jj.generates_invoice is True
                    or
                    checked_in_from_app is True
                    or (
                        jj.generates_invoice is False
                        and
                        checked_in_timestamp >= allocated_date
                        )
                )
                and fa.is_test_area is FALSE
                and au.id = {0}
                and jj.job_status_description not in ('Message sent', 'Office ref', 'Skipped after reminder')
                {3}
            group by completed_date, window_cleaner_id
            order by completed_date desc
        ),
        cte2 as (
            select cte.*, coalesce(checked_status,0) checked_status_int,
                CASE ci.checked_status
                    WHEN 1 THEN 'CHECKED'
                    WHEN 2 THEN 'RECHECK'
                    ELSE 'CHECK'
                    END checked_status
            from cte
                left outer join jobs_checkedinvoice ci on ci.invoice_date = cte.completed_date and
                            cte.window_cleaner_id = ci.window_cleaner_id
            order by completed_date desc
        )
        {2}
        """.format(user_id, isTestArea, select_term, franchise_text)

    return sql


@register.simple_tag(takes_context=True)
def count_wc_invoice_checked(context, user):
    """
        THIS QUERY MUST BE SAME AS wcinvoice.py.get_wc_invoices_queryset()
    """

    isTestArea = False
    request = context['request']
    if 'switch_test_on_off' in request.session and \
        request.session['switch_test_on_off'] == 'true':
        isTestArea = True
    franchise_id = get_user_franchise_id(request.user, request)
    with connection.cursor() as cursor:
        sql = get_checked_invoice_sql(
            isTestArea=isTestArea,
            user_id=user.id,
            select_term='select count(*) cnt from cte2 where checked_status_int=0;',
            franchise_id=franchise_id
        )
        cursor.execute(sql)
        columns = [col[0] for col in cursor.description]
        query_dict = [dict(zip(columns, row)) for row in cursor.fetchall()]            
    return query_dict[0]['cnt']

@register.filter(name='is_set_up_choice_text')
def is_set_up_choice_text(val):
    is_set_up_choice = {
        1 : 'Complete',
        2 : 'In progress',
        3 : 'To be done',
        4 : 'Automated'
    }
    return is_set_up_choice[val]


@register.filter(name='video_categories')
def video_categories(video):    
    badges = ''
    for cat in video.categories.all():
        badges += '<div class="badge" style="background-color: {0}; color: {1}">{2}</div>'.format(cat.colour, cat.text_colour, cat)
    return format_html(badges)

@register.filter(name='replace_linebr')
def replace_linebr(value):
    """Replaces all values of line break from the given string with a line space."""
    try:
        return format_html(value.replace(" ", '<br />'))
    except AttributeError:
        return value


@register.filter()
def franchise_from_id(franchise_id):
    """ simple tag to return franchise given the franchise id """
    if franchise_id and franchise_id >= 0:
        try:
            franchise = Franchise.objects.get(id=franchise_id)
            return franchise
        except ObjectDoesNotExist:
            return None
    else:
        return None

@register.filter(name='html_attachment_open')
def html_attachment_open(file_path):
    from pathlib import Path
    try:
        if re.search(r'\bmail_box_attachments\b', file_path):
            file_extention = Path(file_path).suffixes
            if '.html' in file_extention or '.txt' in file_extention:
                s3_bucket_url = settings.MEDIA_URL.replace('static','media')
                s3_bucket_url = s3_bucket_url+file_path
                is_file_exists = checkFileExistOnS3(settings.AWS_STORAGE_BUCKET_NAME,'media/'+file_path)
                if is_file_exists == True:
                    return s3_bucket_url
    except Exception as e:
        print('Error in html attachment open--',str(e))

@register.filter(name='get_paid_by_val')
def get_paid_by_val(paid_by):
    PAID_BY_CHOICE_DICT = {
        1: 'Cash',
        2: 'Chq',
        3: 'BT',
    }
    if paid_by is not None:
        return PAID_BY_CHOICE_DICT[paid_by] or ''
    return ''


@register.simple_tag(takes_context=True)
def cct_monitoring_time(context, user):

    """ returns remaining support time """

    franchise = get_user_franchise(user, context['request'])

    today_date = datetime.datetime.today()
    week_start_date = today_date - datetime.timedelta(days=today_date.weekday())
    week_end_date = week_start_date + datetime.timedelta(days=6)

    agreed_weekly_support = WeeklyCustomerCareBookedTime.objects.filter(
        valid_from__lte=today_date.strftime('%Y-%m-%d'),
        franchise=franchise,
        category__category='Support'
    ).order_by('-valid_from').first()

    agreed_weekly_support_time = 0
    if agreed_weekly_support is not None:
        agreed_weekly_support_time = agreed_weekly_support.hours * 60 * 60

    support_time_this_week = CustomerCareTime.objects.select_related(
        'category'
        ).filter(
            start_time__date__gte=week_start_date.strftime('%Y-%m-%d'),
            start_time__date__lte=week_end_date.strftime('%Y-%m-%d'),
            franchise=franchise,
            category__category='Support'
        ).aggregate(
            support_total_hours=Sum(
                ExpressionWrapper(
                    Ceil((Epoch(F('end_time'))-Epoch(F('start_time')))/Value(60.0))*Value(60), output_field=DurationField()
            )
            )
        )    

    support_total_time_hours = 0
    if support_time_this_week['support_total_hours'] is not None:
        support_total_time_hours = int(support_time_this_week['support_total_hours'])

    remaining_support_time = 0
    if support_total_time_hours != 0 and agreed_weekly_support_time !=0:
        agreed_weekly_support_time = agreed_weekly_support_time
        remaining_support_time = agreed_weekly_support_time - support_total_time_hours
    elif agreed_weekly_support_time != 0:
        remaining_support_time = agreed_weekly_support_time
    else:
        remaining_support_time = 0

    if user.customercare.timer_category is not None and \
        user.customercare.timer_category.category  == 'Training':
        return 0
    else:
        return remaining_support_time

@register.simple_tag(takes_context=True)
def wc_multi_franchise_lists(context, user):

    """ returns WC Multi franchise lists """
    request = context['request']
    user_franchise_id_list = [franchise.id for franchise in user.windowcleaner.franchise.all()]
    # check is Test Area On of Off
    isTestArea = False
    if 'switch_test_on_off' in request.session and \
        request.session['switch_test_on_off'] == 'true':
        isTestArea = True

    # convert list to string:
    franchises = '('+ ', '.join(map(str, user_franchise_id_list)) + ')'
    with connection.cursor() as cursor:
        sql ="""
            with cte as (
                select windowcleaner_id, franchise_id from accounts_windowcleaner_franchise
                where windowcleaner_id = {1}
            ),cte2 as (
                select distinct ff.id franchise_id, allocated_date
                from jobs_job j
                    inner join customers_customer cc on j.customer_id = cc.id
                    inner join franchises_bookingroad fb on cc.booking_road_id = fb.id
                    inner join franchises_area fa on fb.area_id = fa.id
                    inner join franchises_franchise ff on fa.franchise_id = ff.id
                    inner join jobs_jobstatus jj on j.job_status_id = jj.id
                where jj.job_status_description='Booked'
                and fa.is_test_area={0}
                and j.window_cleaner_id={1}
                and ff.id IN {2}
            ),
            cte3 as (
                select cte.franchise_id, allocated_date, franchise
                from cte
                left join cte2 on cte2.franchise_id = cte.franchise_id
                inner join franchises_franchise fr on fr.id = cte.franchise_id
            )
            select franchise,franchise_id, count( allocated_date ) , CASE WHEN min(allocated_date) < current_date then 'O/due' else min(to_char(allocated_date, 'DD/MM/YYYY'))::varchar end next_due_date from cte3
            GROUP BY franchise, franchise_id;
            """.format(isTestArea, user.windowcleaner.id, franchises)

        cursor.execute(sql)

        columns = [col[0] for col in cursor.description]
        query_dict = [dict(zip(columns, row)) for row in cursor.fetchall()]

    return query_dict

@register.filter
def vat_flag_icon(vat_flag):
    if vat_flag == VATFlags.NOT_ACTIONED:
        return '<i class="fa-solid fa-flag" title="Not actioned" data-toggle="tooltip" style="color:orange"></i>'
    elif vat_flag == VATFlags.ADDED:
        return '<i class="fa-solid fa-check" title="Added" data-toggle="tooltip" style="color:green"></i>'
    elif vat_flag == VATFlags.REDUCED:
        return '<i class="fa-solid fa-flag" title="Reduced" data-toggle="tooltip" style="color:blue"></i>'
    elif vat_flag == VATFlags.REFUSED:
        return '<i class="fa-solid fa-times" title="Refused" data-toggle="tooltip" style="color:red"></i>'
    else:
        return '';    


@register.filter
def future_vat_flag_icon(vat_flag):
    if vat_flag == FutureVATFlags.HAPPY:
        return '<i class="fa-solid fa-check" title="Happy" data-toggle="tooltip" style="color:green"></i>'
    elif vat_flag == FutureVATFlags.INDIFFERENT:
        return '<i class="fa-solid fa-flag" title="Indifferent" data-toggle="tooltip" style="color:blue"></i>'
    elif vat_flag == FutureVATFlags.NEGOTIATE:
        return '<i class="fa-solid fa-flag" title="Negotiate" data-toggle="tooltip" style="color:orange"></i>'
    elif vat_flag == FutureVATFlags.WOULD_CANCEL:
        return '<i class="fa-solid fa-times" title="Would cancel" data-toggle="tooltip" style="color:red"></i>'
    elif vat_flag == FutureVATFlags.ALREADY_ADDED:
        return '<i class="fa-solid fa-plus" title="Already added 20%" data-toggle="tooltip" style="color:green"></i>'
    elif vat_flag == FutureVATFlags.PRE_WARNING_SENT:
        return '<i class="fa-solid fa-envelope" title="Pre warning sent" data-toggle="tooltip" style="color:green"></i>'
    else:
        return '';  

@register.inclusion_tag('future_vat_modal.html',takes_context=True)
def future_vat_modal(context,customer):
    return {'customer': customer,'request':context['request']}

@register.filter()
def smooth_timedelta(timedeltaobj):
    """Convert a datetime.timedelta object into Days, Hours, Minutes, Seconds.
        https://stackoverflow.com/questions/16348003/displaying-a-timedelta-object-in-a-django-template
    """
    if timedeltaobj is None:
        return '-'
    secs = timedeltaobj.total_seconds()  
    if secs == 0:
        return '-'
    days_str=hrs_str=mins_str=secs_str=''  
    sign=''
    if secs<0:
        sign = '-'
        secs = -secs
    timetot = ""
    # if secs > 86400: # 60sec * 60min * 24hrs
    #     days = secs // 86400
    #     days_str = "{0}{1} days".format(sign, int(days))
    #     secs = secs - days*86400

    if secs >= 3600:
        hrs = secs // 3600
        if hrs == 1:
            hrs_str = "{0}{1} hr".format(sign, int(hrs))
        else:
            hrs_str = "{0}{1} hrs".format(sign,int(hrs))
        secs = secs - hrs*3600

    if secs >= 60:
        mins = secs // 60
        if mins == 1:
            mins_str = "{0}{1} mn".format(sign, int(mins))
        else:
            mins_str = "{0}{1} mns".format(sign, int(mins))
        secs = secs - mins*60

    if secs > 0:
        secs_str = "{0}{1} secs".format(sign, int(secs))
    
    return ' '.join((days_str, hrs_str, mins_str, secs_str))


@register.filter()
def smooth_timedelta_from_int(int_seconds):
    """Convert an int (seconds) into Days, Hours, Minutes, Seconds.        
    """
    timedeltaobj = datetime.timedelta(seconds=int(int_seconds))
    return smooth_timedelta(timedeltaobj)    


@register.simple_tag(takes_context=True)
def website_enquiries_count(context, franchise_id):
    """ returns number of website 
        enquiry customers not set up yet 
    """

    request = context['request']
    user = request.user
    franchise_id = get_user_franchise_id(user, request)
    isTestArea = False
    if 'switch_test_on_off' in request.session and \
        request.session['switch_test_on_off'] == 'true':
        isTestArea = True
    
    customer_count = Customer.objects.select_related(
            'booking_road__area__franchise'
        ).filter(
            website_enquiry = True,
            is_set_up_choice__in=(IS_SETUP_IN_PROGRESS, IS_SETUP_TO_BE_DONE),
            booking_road__area__franchise__id = franchise_id,
            booking_road__area__is_test_area=isTestArea,
        ).order_by('-created').count()
    return customer_count
