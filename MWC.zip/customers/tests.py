# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.test import TestCase

from customers.models import Customer
from jobs.models import Job


class CheckInJobFromCustomerDetailTestCase(TestCase):
    def setUp(self):
        Customer.objects.create(surname="Customer")

    def test_customer_is_created(self):
        customer = Customer.objects.get(name="Customer")
        
        self.assertEqual(customer.name, 'Customer')
