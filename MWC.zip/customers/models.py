# -*- coding: utf-8 -*-
from __future__ import unicode_literals
#from asyncio.windows_events import NULL
import datetime, re
from decimal import *
from random import choices

from django.db import models
from django.conf import settings
from django.contrib import admin
from django.contrib.humanize.templatetags.humanize import intcomma
from django.core.validators import MinValueValidator, MaxValueValidator
from django.utils.safestring import mark_safe

from simple_history.models import HistoricalRecords
from phonenumber_field.modelfields import PhoneNumberField

class PropertyTypeCategory(models.Model):
    category = models.CharField(max_length=255)
    order = models.IntegerField(null=True) 

    class Meta:
        ordering = ['order', ]
        verbose_name_plural = "Property type categories"
        verbose_name = "Property type categories"

    def __str__(self):
        return self.category

class PropertyType(models.Model):
    property_type = models.CharField(max_length=255)
    order = models.IntegerField(null=True)
    abbreviation = models.CharField(blank=True, max_length=10)
    category = models.ForeignKey(
        PropertyTypeCategory,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
    )

    class Meta:
        ordering = ['order', ]

    def __str__(self):
        return self.property_type


class FrequencyChoice(models.Model):
    frequency_choice = models.IntegerField()
    frequency_text = models.CharField(max_length=50, blank=False)
    abbreviation = models.CharField(max_length=55, blank=True)
    
    def __str__(self):
        return str(self.frequency_text)

    class Meta:
        ordering = ["frequency_choice"]


class BusinessSource(models.Model):
    business_source = models.CharField(max_length=255)
    franchise = models.ManyToManyField(
        'franchises.Franchise',
        )
    order = models.IntegerField(null=True)
    paid_for = models.BooleanField(default=False)

    def __str__(self):
        return self.business_source

    class Meta:
        ordering = ["order"]


class BusinessSourceCanvasser(models.Model):
    canvasser = models.CharField(max_length=50)
    franchise = models.ManyToManyField(
        'franchises.Franchise'
        )

    def __str__(self):
        return self.canvasser

    class Meta:
        verbose_name_plural = "Business sources MWC canvasser"
        verbose_name = "Business source MWC canvasser"


class BusinessSourceInternet(models.Model):
    internet = models.CharField(max_length=50)
    franchise = models.ManyToManyField(
        'franchises.Franchise'
        )
    paid_for = models.BooleanField(default=False)
    order = models.IntegerField(null=True)

    def __str__(self):
        return self.internet

    class Meta:
        verbose_name_plural = "Business sources internet"
        verbose_name = "Business source internet"
        ordering = ["order", "-id"]




class BusinessSourceLocalMagazine(models.Model):
    magazine = models.CharField(max_length=50)
    franchise = models.ManyToManyField(
        'franchises.Franchise'
        )
    paid_for = models.BooleanField(default=False)
    order = models.IntegerField(null=True)

    def __str__(self):
        return self.magazine

    class Meta:
        verbose_name_plural = "Business sources magazine"
        verbose_name = "Business source magazine"
        ordering = ["order", "-id"]




class BusinessSourceLocalAdBoard(models.Model):
    ad_board = models.CharField(max_length=50)
    franchise = models.ManyToManyField(
        'franchises.Franchise'
        )
    paid_for = models.BooleanField(default=False)
    order = models.IntegerField(null=True)

    def __str__(self):
        return self.ad_board

    class Meta:
        verbose_name_plural = "Business sources local ad board"
        verbose_name = "Business source local ad board"
        ordering = ["order", "-id"]




class BusinessSourceDirectory(models.Model):
    directory = models.CharField(max_length=50)
    franchise = models.ManyToManyField(
        'franchises.Franchise'
        )
    paid_for = models.BooleanField(default=False)
    order = models.IntegerField(null=True)

    def __str__(self):
        return self.directory

    class Meta:
        verbose_name_plural = "Business sources directory"
        verbose_name = "Business source MWC directory"
        ordering = ["order", "-id"]


class BusinessSourceLeaflet(models.Model):
    leaflet = models.CharField(max_length=50)
    franchise = models.ManyToManyField(
        'franchises.Franchise'
        )
    paid_for = models.BooleanField(default=False)
    order = models.IntegerField(null=True)

    def __str__(self):
        return self.leaflet

    class Meta:
        verbose_name_plural = "Business sources leaflet"
        verbose_name = "Business source MWC leaflet"
        ordering = ["order", "-id"]


class BusinessSourceLocalFacebook(models.Model):
    local_facebook = models.CharField(max_length=50)
    franchise = models.ManyToManyField(
        'franchises.Franchise'
        )
    paid_for = models.BooleanField(default=False)
    order = models.IntegerField(null=True)

    def __str__(self):
        return self.local_facebook

    class Meta:
        verbose_name_plural = "Business sources local Facebook"
        verbose_name = "Business source local Facebook"
        ordering = ["order", "-id"]


class BusinessSourceDigitalMagazine(models.Model):
    magazine = models.CharField(max_length=50)
    franchise = models.ManyToManyField(
        'franchises.Franchise'
        )
    paid_for = models.BooleanField(default=False)
    order = models.IntegerField(null=True)

    def __str__(self):
        return self.magazine

    class Meta:
        verbose_name_plural = "Business sources digital magazine"
        verbose_name = "Business source digital magazine"
        ordering = ["order", "-id"]


class BusinessSourceSponsorship(models.Model):
    sponsor = models.CharField(max_length=50)
    franchise = models.ManyToManyField(
        'franchises.Franchise'
        )
    paid_for = models.BooleanField(default=False)
    order = models.IntegerField(null=True)

    def __str__(self):
        return self.sponsor

    class Meta:
        verbose_name_plural = "Business sources sponsorship"
        verbose_name = "Business source sponsorship"
        ordering = ["order", "-id"]


class BookWithChoice(models.Model):
    book_with = models.CharField(max_length=50)
    abbreviation = models.CharField(max_length=4, blank=True)
    order = models.IntegerField(null=True)

    def __str__(self):
        return self.book_with

    class Meta:
        ordering = ["order"]


class CreditItem(models.Model):

    BANK_TRANSFER = 1
    CARD_PAYMENT = 2
    CHEQUE_RECEIVED = 3
    COLLECTED = 4
    STANDING_ORDER = 5

    CREDIT_PAYMENT_METHODS = (
        (BANK_TRANSFER, 'Bank transfer'),
        (CARD_PAYMENT, 'Card payment'),
        (CHEQUE_RECEIVED, 'Cheque received'),
        (COLLECTED, 'Collected'),
        (STANDING_ORDER, 'Standing order')
    )

    CREDIT_PAYMENT_METHODS_ABBREVIATIONS = (
        (BANK_TRANSFER, 'BT'),
        (CARD_PAYMENT, 'CP'),
        (CHEQUE_RECEIVED, 'CR'),
        (COLLECTED, 'Col'),
        (STANDING_ORDER, 'SO')
    )

    prepaid_to_mwc = models.BooleanField(default=True)
    prepaid_to_wc = models.ForeignKey(
        'accounts.WindowCleaner',
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        limit_choices_to={
            'user__groups__name': 'window_cleaner'
        }
    )
    customer = models.ForeignKey(
        'Customer',
        null=True,
        blank=True,
        on_delete=models.CASCADE,
    )
    date = models.DateField()
    amount = models.DecimalField(
        max_digits=8, decimal_places=2
    )
    added_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
    )
    payment_method = models.IntegerField(
        choices=CREDIT_PAYMENT_METHODS,
        default=BANK_TRANSFER
    )
    payment_method_abbreviation = models.IntegerField(
        choices=CREDIT_PAYMENT_METHODS_ABBREVIATIONS,
        default=BANK_TRANSFER
    )

    @property
    def pmt_method_abbreviation(self):
        return self.CREDIT_PAYMENT_METHODS_ABBREVIATIONS[int(self.payment_method_abbreviation)-1][1]


TITLE_CHOICES = (
    ('Mr.', 'Mr.'),
    ('Mr. & Mrs.', 'Mr. & Mrs.'),
    ('Mrs.', 'Mrs.'),
    ('Miss', 'Miss'),
    ('Ms.', 'Ms.'),
    ('Mrs. & Mr.', 'Mrs. & Mr.'),
    ('Rev.', 'Rev.'),
    ('Dr.', 'Dr.'),
    ('Mr. & Miss', 'Mr. & Miss'),
    ('Mr. & Mr.', 'Mr. & Mr.'),
    ('Mrs. & Mrs.', 'Mrs. & Mrs.'),
    ('Sir', 'Sir'),
    ('Dr. & Mr.', 'Dr. & Mr.'),
)


DAYS_OF_WEEK = (
    ('Any day', 'Any day'),
    ('Other days', 'Other days'),
    ('Monday', 'Monday'),
    ('Tuesday', 'Tuesday'),
    ('Wednesday', 'Wednesday'),
    ('Thursday', 'Thursday'),
    ('Friday', 'Friday'),
    ('Saturday', 'Saturday'),
    ('Sunday', 'Sunday'),
    ('Contact customer', 'Contact customer')
)

AUTO_BOOKINGS_CHOICES = (
    (0, 'Normal reminders'),
    (1, 'Stop auto reminders'),
    (2, 'Ask each clean'),
    (3, 'Ask after building work'),
    (4, 'Scarcity')
)


class DefaultTimeSlot(models.Model):
    customer = models.ForeignKey(
        'Customer',
        on_delete=models.CASCADE,
        related_name='time_slot_default'
    )
    day_of_week = models.CharField(
        blank=True,
        choices=DAYS_OF_WEEK,
        max_length=20,
        )
    start_time = models.TimeField(blank=True, null=True)
    end_time = models.TimeField(blank=True, null=True)
    notes = models.TextField(blank=True)
    NOT_flag = models.BooleanField(default=False)
    is_specific_appointment = models.BooleanField(default=False)

    def __str__(self):
        str = ''

        if 'Contact customer' in self.day_of_week:
            str_day_of_week = 'TBA'
        else:
            str_day_of_week = day_abbreviation(self.day_of_week)

        str += str_day_of_week

        if self.NOT_flag is True:
            str += ' X'

        if self.is_specific_appointment is False:
            if not self.end_time and self.start_time:
                start_time_format = self.start_time.strftime("%I:%M%p").replace(
                    ':00', '').lstrip("0").replace(" 0", " ")
                str += ' A ' + start_time_format + ' '
            elif not self.start_time and self.end_time:
                end_time_format = self.end_time.strftime("%I:%M%p").replace(
                    ':00', '').lstrip("0").replace(" 0", " ")
                str += ' B ' + end_time_format + ' '
            elif self.start_time and self.end_time:
                start_time_format = self.start_time.strftime("%I:%M%p").replace(
                    ':00', '').lstrip("0").replace(" 0", " ")
                end_time_format = self.end_time.strftime("%I:%M%p").replace(
                    ':00', '').lstrip("0").replace(" 0", " ")
                str += ' ' + start_time_format + \
                    '-' + end_time_format + ' '
            elif not self.start_time and \
                not self.end_time and \
                    not self.day_of_week == 'Contact customer':

                if self.NOT_flag is False:
                    str += ' any'
        else:
            if not self.end_time and self.start_time:
                start_time_format = self.start_time.strftime("%I:%M%p").replace(
                    ':00', '').lstrip("0").replace(" 0", " ")
                str += ' ' + start_time_format + ' '

        str = re.sub(' +', ' ', str)

        if self.notes:
            str += ' - ' + self.notes

        return str


class AlternateTimeSlot(models.Model):
    customer = models.ForeignKey(
        'Customer',
        on_delete=models.CASCADE,
        related_name='time_slot_alternate'
    )
    day_of_week = models.CharField(
        blank=True,
        choices=DAYS_OF_WEEK,
        max_length=20,
        )
    start_time = models.TimeField(blank=True, null=True)
    end_time = models.TimeField(blank=True, null=True)
    notes = models.TextField(blank=True)
    NOT_flag = models.BooleanField(default=False)
    is_specific_appointment = models.BooleanField(default=False)

    def __str__(self):
        str = ''

        if 'Contact customer' in self.day_of_week:
            str_day_of_week = 'TBA'
        else:
            str_day_of_week = day_abbreviation(self.day_of_week)

        str += str_day_of_week

        if self.NOT_flag is True:
            str += ' X'

        if self.is_specific_appointment is False:
            if not self.end_time and self.start_time:
                start_time_format = self.start_time.strftime("%I:%M%p").replace(
                    ':00', '').lstrip("0").replace(" 0", " ")
                str += ' A ' + start_time_format + ' '
            elif not self.start_time and self.end_time:
                end_time_format = self.end_time.strftime("%I:%M%p").replace(
                    ':00', '').lstrip("0").replace(" 0", " ")
                str += ' B ' + end_time_format + ' '
            elif self.start_time and self.end_time:
                start_time_format = self.start_time.strftime("%I:%M%p").replace(
                    ':00', '').lstrip("0").replace(" 0", " ")
                end_time_format = self.end_time.strftime("%I:%M%p").replace(
                    ':00', '').lstrip("0").replace(" 0", " ")
                str += ' ' + start_time_format + \
                    '-' + end_time_format + ' '
            elif not self.start_time and not self.end_time:
                if self.NOT_flag is False:
                    str += ' any'
        else:
            if not self.end_time and self.start_time:
                start_time_format = self.start_time.strftime("%I:%M%p").replace(
                    ':00', '').lstrip("0").replace(" 0", " ")
                str += ' ' + start_time_format + ' '

        str = re.sub(' +', ' ', str)

        if self.notes:
            str += ' - ' + self.notes

        return str


class TimeSlot(models.Model):
    customer = models.ForeignKey(
        'Customer',
        on_delete=models.CASCADE,
    )
    date = models.DateField(blank=False)
    start_time = models.TimeField(blank=True, null=True)
    end_time = models.TimeField(blank=True, null=True)
    notes = models.TextField(blank=True)
    NOT_flag = models.BooleanField(null=False, default=True)
    is_specific_appointment = models.BooleanField(default=False)

    def __str__(self):
        str = ''
        if self.NOT_flag:
            str += 'Not '
        str += self.date.strftime("%d/%m/%y")
        if not self.end_time and not self.start_time:
            str += ' any time'
        elif not self.end_time and self.start_time:
            str += ' after ' + self.start_time.strftime("%I:%M%p") + ' '
        elif not self.start_time and self.end_time:
            str += ' before ' + self.end_time + ' '
        elif self.start_time and self.end_time:
            str += ' ' + self.start_time.strftime("%I:%M%p") + \
                '-' + self.end_time.strftime("%I:%M%p") + ' '
        if self.notes:
            str += ' - ' + self.notes
        return str


class OtherQuotesTask(models.Model):
    job_task = models.CharField(max_length=255, unique=True)
    short_text = models.CharField(max_length=10, blank=False)
    order = models.IntegerField(null=True)

    def __str__(self):
        return self.job_task

    class Meta:
        ordering = ["order"]


class OtherQuote(models.Model):
    job_task = models.ForeignKey(OtherQuotesTask, on_delete=models.CASCADE)
    customer = models.ForeignKey('Customer', on_delete=models.CASCADE)
    # TODO: CHECK CONSEQUENCE OF on_delete
    price = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        null=False,
        validators=[MinValueValidator(Decimal('0.00'))]
    )
    notes = models.TextField(blank=True)
    told_customer = models.BooleanField(default=False)
    other_quote_date=models.DateField(blank=True, null=True)

    def __str__(self):
        task = self.job_task.job_task + ' - £' + str(self.price)
        if self.notes:
            task += ' (' + self.notes + ')'
        return task


class WCdetailsToCustomer(models.Model):
    window_cleaner = models.ForeignKey(
        'accounts.WindowCleaner', on_delete=models.CASCADE
        )
    customer = models.ForeignKey('Customer', on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)


class IsInactiveReason(models.Model):
    reason = models.CharField(max_length=100, unique=True)
    customer_left = models.BooleanField(default=True)
    order = models.IntegerField(null=True)

    def __str__(self):
        return self.reason

    class Meta:
        ordering = ["order"]


class NewCustomerOtherQuote(models.Model):
    job_task = models.ForeignKey(OtherQuotesTask, on_delete=models.CASCADE)
    customer = models.ForeignKey('WCNewCustomer', on_delete=models.CASCADE)
    # TODO: CHECK CONSEQUENCE OF on_delete
    price = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        null=False,
        validators=[MinValueValidator(Decimal('0.00'))]
    )
    notes = models.TextField(blank=True)

    def __str__(self):
        task = self.job_task.job_task + ' - £' + str(self.price)
        if self.notes:
            task += ' (' + self.notes + ')'
        return task


class CommercialList(models.Model):
    """docstring for ClassName"""

    PAYMENT_TERMS_CHOICES = (
        (0, 'Same day'),
        (3, 'Within 3 days'),
        (7, 'Within 7 days'),
        (14, 'Within 14 days'),
        (30, 'Within 30 days'),
        (60, 'Within 60 days'),
        (90, 'Within 90 days'),
    )
    INVOICE_FREQUENCY_CHOICES = (
        (1, 'Immediate'),
        (2, 'Monthly')
    )

    DAY_OF_MONTH_CHOICES = [(m,m) for m in range(1,31)]
    DAY_OF_MONTH_CHOICES.append((31, '31/Last day of month'))

    list_name = models.CharField(max_length=50, blank=False)
    company_name = models.CharField(max_length=50, blank=False)
    email = models.EmailField(blank=False, db_index=True)
    contact_title = models.CharField(max_length=25, choices=TITLE_CHOICES, blank=True, null=True)
    contact_first_name = models.CharField(max_length=50, blank=True)
    contact_last_name = models.CharField(max_length=50, blank=False)
    invoice_frequency = models.IntegerField(
        choices=INVOICE_FREQUENCY_CHOICES,
    )
    switch_off_invoices = models.BooleanField(default=False)
    franchise = models.ForeignKey(
        'franchises.Franchise',
        on_delete=models.PROTECT,
        blank=False,
    )
    address_line_1 = models.CharField(max_length=200, blank=True, db_index=True, help_text='OK to amend')
    address_line_2 = models.CharField(max_length=200, blank=True, db_index=True)
    address_line_3 = models.CharField(max_length=200, blank=True, db_index=True)
    post_town = models.CharField(max_length=100, blank=True, db_index=True)
    county = models.CharField(max_length=100, blank=True)
    postcode = models.CharField(max_length=100, blank=True, db_index=True)
    head_office_number = PhoneNumberField(blank=True, db_index=True)
    cc_email = models.EmailField(blank=True, db_index=True)
    payment_terms = models.IntegerField(
        choices=PAYMENT_TERMS_CHOICES,
        default=0,
        blank=True
    )
    invoice_day_of_month = models.IntegerField(
        choices=DAY_OF_MONTH_CHOICES,
        null=True,
        blank=True
    )
    pay_wc_directly = models.BooleanField(null=True, blank=True)
    wc_for_bank_details = models.ForeignKey(
        'accounts.WindowCleaner',
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name='wc_for_bank_details',
        limit_choices_to={
            'user__groups__name': 'window_cleaner'
        }
    )
    customer_reference = models.CharField(
        max_length=20,        
        blank=True
        )

    def __str__(self):
        return self.list_name

    @property
    def get_payment_terms(self):
        payment_terms = dict(self.PAYMENT_TERMS_CHOICES)
        return payment_terms[self.payment_terms]

    class Meta:
        ordering = ['list_name']   
        unique_together = ('list_name', 'franchise')    


class CommercialInvoices(models.Model):
    """docstring for ClassName"""
    invoice_ref = models.CharField(
        max_length=20,
        unique=True,
        blank=False)
    sent_to_email = models.EmailField(blank=False)
    invoice_date = models.DateField(blank=False)
    total = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        null=False,
    )
    pdf_version = models.FileField(upload_to="commercial_invoices")
    commercial_list = models.ForeignKey(
        CommercialList,
        on_delete=models.PROTECT,
        null=True,
        blank=True
    )
class NewCustomerId(models.Model):
    """
    NewCustomerId Model is used for handle T&C and BTD Emails
    """
    pass

IS_SETUP_COMPLETE = 1
IS_SETUP_IN_PROGRESS = 2
IS_SETUP_TO_BE_DONE = 3
IS_SETUP_AUTOMATED = 4

IS_SETUP_CHOICES = (
    (IS_SETUP_COMPLETE, 'Complete'),
    (IS_SETUP_IN_PROGRESS, 'In progress'),
    (IS_SETUP_TO_BE_DONE, 'To be done'),
    (IS_SETUP_AUTOMATED, 'Automated'),
)

ENQUIRY = 1
ACTIVE = 2
INACTIVE = 3
CUSTOMER_STATUS_CHOICES = (
    (ENQUIRY, 'Enquiry'),
    (ACTIVE, 'Active'),
    (INACTIVE, 'Inactive')
)

class VATFlags(models.IntegerChoices):
        NOT_ACTIONED = 0
        ADDED = 1
        REDUCED = 2
        REFUSED = 3        

class FutureVATFlags(models.IntegerChoices):
        HAPPY = 0
        INDIFFERENT = 1
        NEGOTIATE = 2
        WOULD_CANCEL = 3 
        ALREADY_ADDED = 4
        PRE_WARNING_SENT = 5       
class Customer(models.Model):       

    # CUSTOMER DETAILS -------------------------------------------------
    title = models.CharField(max_length=25, choices=TITLE_CHOICES)
    first_name = models.CharField(max_length=50, db_index=True)
    last_name = models.CharField(max_length=100, blank=False, db_index=True)

    business_source = models.ForeignKey(
        BusinessSource,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='+',)
    business_source_notes = models.CharField(
        max_length=500, blank=True
        )
    # 'Asked':
    business_source_window_cleaner = models.ForeignKey(
        'accounts.WindowCleaner',
        on_delete=models.PROTECT,
        null=True,
        blank=True,  # required for modelform to be required=false
        related_name='bus_source_wc+',
        limit_choices_to={
            'user__groups__name': 'window_cleaner'
        }
    )
    business_source_canvasser = models.ForeignKey(
        'accounts.Canvasser',
        on_delete=models.PROTECT,
        null=True,
        blank=True,  # required for modelform to be required=false
        related_name='canvasser+',
        limit_choices_to={
            'user__groups__name': 'canvasser'
        }
    )
    business_source_internet = models.ForeignKey(
        BusinessSourceInternet,
        null=True,
        blank=True,
        on_delete=models.PROTECT
    )
    business_source_recommendation_customer = models.ForeignKey(
        'self',
        null=True,
        blank=True,
        on_delete=models.PROTECT
    )
    business_source_local_magazine = models.ForeignKey(
        BusinessSourceLocalMagazine,
        null=True,
        blank=True,
        on_delete=models.PROTECT
    )
    business_source_local_ad_board = models.ForeignKey(
        BusinessSourceLocalAdBoard,
        null=True,
        blank=True,
        on_delete=models.PROTECT
    )
    business_source_directory = models.ForeignKey(
        BusinessSourceDirectory,
        null=True,
        blank=True,
        on_delete=models.PROTECT
    )
    business_source_existing_customer = models.ForeignKey(
        'self',
        null=True,
        blank=True,
        on_delete=models.PROTECT,
        related_name='existing_customer'
    )
    business_source_leaflet = models.ForeignKey(
        BusinessSourceLeaflet,
        null=True,
        blank=True,
        on_delete=models.PROTECT,
    )
    business_source_local_facebook = models.ForeignKey(
        BusinessSourceLocalFacebook,
        null=True,
        blank=True,
        on_delete=models.PROTECT,
    )
    business_source_digital_magazine = models.ForeignKey(
        BusinessSourceDigitalMagazine,
        null=True,
        blank=True,
        on_delete=models.PROTECT,
    )
    business_source_sponsorship = models.ForeignKey(
        BusinessSourceSponsorship,
        null=True,
        blank=True,
        on_delete=models.PROTECT,
    )
    customer_since = models.DateField(blank=False, null=False)
    told_terms_conditions = models.BooleanField(default=False)
    told_terms_conditions_date = models.DateField(null=True, blank=True)
    told_terms_conditions_notes = models.TextField(blank=True)
    told_terms_conditions_previous_address = models.ForeignKey(
        'self',
        null=True,
        blank=True,
        on_delete=models.PROTECT,
        related_name='told_tnc_prev_address'
    )
    stop_paperless_bills = models.BooleanField(default=False, db_index=True)
    stop_chasers = models.BooleanField(default=False, db_index=True)
    email_invoice = models.BooleanField(default=False, db_index=True)
    stop_auto_bookings = models.BooleanField(default=False, db_index=True)
    auto_bookings = models.IntegerField(
        db_index=True,
        choices=AUTO_BOOKINGS_CHOICES,
        default=0
    )
    is_inactive = models.BooleanField(default=False, db_index=True)
    is_inactive_reason = models.ForeignKey(
        'IsInactiveReason',
        null=True,
        blank=True,
        on_delete=models.PROTECT,
    )
    is_inactive_reason_notes = models.TextField(blank=True)
    date_inactive = models.DateField(blank=True, null=True)
    last_price = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        null=True,
        blank=True,
        validators=[MinValueValidator(Decimal('0.00'))]
    )
    last_price_increase_date = models.DateField(blank=True, null=True)
    last_price_increase_notes = models.TextField(blank=True)
    important_job_notes = models.TextField(blank=True)
    important_job_notes_alt = models.TextField(blank=True)
    booking_info = models.TextField(blank=True)
    no_sales_emails = models.BooleanField(default=False)
    one_day_only = models.BooleanField(default=False)
    one_day_only_alt = models.BooleanField(default=False)
    time_slots_notes = models.CharField(blank=True, max_length=200)
    payment_info = models.TextField(blank=True)
    other_quotes = models.ManyToManyField(
        OtherQuotesTask,
        through='OtherQuote',
        )
    # wc Bank transfer detail to customer management
    wc_detail_to_customer = models.ManyToManyField(
        'accounts.WindowCleaner',
        blank=True,
        through='WCdetailsToCustomer',
    )
    other_quotes_string = models.TextField(blank=True)
    other_quotes_notes = models.TextField(blank=True)
    customer_notes = models.TextField(blank=True)
    credit = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        null=False,
        default=0.0,
    )
    # ADDRESS --------------------------------------------------------------
    # TODO: Building Number should be numeric
    # (sub_building_name contains 'flat','A' etc.)
    building_number = models.CharField(
        max_length=16, blank=True, db_index=True
        )
    building_name = models.CharField(
        max_length=50, blank=True, db_index=True
        )
    sub_building_name = models.CharField(
        max_length=30, blank=True
        )
    thoroughfare = models.CharField(
        max_length=60, blank=True, db_index=True
        )
    address_line_1 = models.CharField(max_length=200, db_index=True, help_text='OK to amend')
    address_line_2 = models.CharField(
        max_length=200, blank=True, db_index=True
        )
    address_line_3 = models.CharField(
        max_length=200, blank=True, db_index=True
        )
    post_town = models.CharField(max_length=100, db_index=True)
    county = models.CharField(max_length=100, blank=True)
    postcode = models.CharField(max_length=100, blank=False, db_index=True)
    organisation_name = models.CharField(max_length=100, blank=True)
    postcode_outward = models.CharField(
        max_length=100, blank=True, db_index=True
        )
    postcode_inward = models.CharField(
        max_length=100, blank=True, db_index=True
        )
    latitude = models.FloatField(
        blank=True,
        null=True)
    longitude = models.FloatField(
        blank=True,
        null=True)
    udprn = models.CharField(max_length=8, blank=True)

    booking_road = models.ForeignKey(
        'franchises.BookingRoad',
        on_delete=models.PROTECT,
        null=False,
    )
    # COMMS -------------------------------------------------------------------
    home_phone = PhoneNumberField(blank=True, db_index=True)
    additional_home_phone = models.TextField(blank=True, db_index=True)
    mobile_phone = PhoneNumberField(blank=True, db_index=True)
    additional_mobile_phone = models.TextField(blank=True, db_index=True)
    work_phone = PhoneNumberField(blank=True, db_index=True)
    additional_work_phone = models.TextField(blank=True, db_index=True)
    home_ansaphone = models.BooleanField(default=False)
    mob_ansaphone = models.BooleanField(default=False)
    phone_extension = models.TextField(blank=True)
    email = models.EmailField(blank=True, db_index=True)
    additional_email = models.TextField(blank=True, db_index=True)
    cc_email = models.EmailField(blank=True, db_index=True)
    no_email = models.BooleanField(default=False)
    book_with = models.ForeignKey(
        'BookWithChoice',
        null=False,
        on_delete=models.PROTECT,
    )
    property_type = models.ForeignKey(
        'PropertyType',
        blank=True,
        null=True,
        on_delete=models.PROTECT,
    )
    property_type_notes = models.TextField(blank=True)
    number_of_bedrooms = models.IntegerField(blank=True, null=True)
    when_to_collect = models.DateField(null=True, blank=True)
    chased_notes = models.TextField(blank=True)
    contact_notes = models.TextField(blank=True)
    #  JOBS -----------------------------------------------------------
    frequency = models.ForeignKey(
        FrequencyChoice,
        on_delete=models.PROTECT,
        default=1
    )
    cleaning_method_default = models.ForeignKey(
        'jobs.CleaningMethod',
        on_delete=models.PROTECT,
        null=True
    )
    job_cycle = models.IntegerField(blank=True, null=True)
    # blank=true necessary for required=false on forms
    # DEFAULT JOB --------------------------------------------------------
    job_task_default = models.ManyToManyField(
        'jobs.JobTask',
        related_name='default_job_tasks',
        blank=True,
        )
    job_task_default_note = models.CharField(
        max_length=150,
        blank=True,
    )
    price_default = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        null=True,
        validators=[MinValueValidator(Decimal('0.00'))]
    )
    access_type_default = models.ForeignKey(
        'jobs.AccessMethod',
        null=True,
        blank=True,
        related_name='+',
        on_delete=models.PROTECT
    )
    access_notes_default = models.TextField(
        blank=True
        )
    money_type_default = models.ForeignKey(
        'jobs.MoneyType',
        related_name='+',
        on_delete=models.PROTECT,
        null=True
    )
    bank_transfer_to_default = models.ForeignKey(
        'accounts.WindowCleaner',
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name='bt_to_default+',
        limit_choices_to={
            'user__groups__name': 'window_cleaner'
        }
    )
    # has it's own format fn below
    time_needed_default = models.DurationField(
        null=True,
        default='00:00'
    )
    # ALTERNATIVE JOB --------------------------------------------------------
    use_alternate_job = models.BooleanField(default=False)
    job_task_alt = models.ManyToManyField(
        'jobs.JobTask',
        blank=True,
        related_name='alt_job_tasks'
        )
    job_task_alt_note = models.CharField(
        max_length=70,
        blank=True,
        )
    price_alt = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        null=True,
        blank=True,
        validators=[MinValueValidator(Decimal('0.00'))]
    )
    access_type_alt = models.ForeignKey(
        'jobs.AccessMethod',
        null=True,
        blank=True,
        related_name='access_type_alt+',
        on_delete=models.PROTECT
    )
    access_notes_alt = models.TextField(
        blank=True
        )
    money_type_alt = models.ForeignKey(
        'jobs.MoneyType',
        null=True,
        blank=True,
        related_name='+',
        on_delete=models.PROTECT
    )
    cleaning_method_alt = models.ForeignKey(
        'jobs.CleaningMethod',
        blank=True,
        null=True,
        related_name='cleaning_method_alt+',
        on_delete=models.PROTECT
    )
    old_property_id = models.IntegerField(null=True, blank=True)

    money_type_note = models.TextField(blank=True)
    frequency_surcharge = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        null=True,
        blank=True,
        validators=[MinValueValidator(Decimal('0.00'))]
    )
    # has it's own format fn below
    bank_transfer_to_alt = models.ForeignKey(
        'accounts.WindowCleaner',
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name='bt_to_alt+',
        limit_choices_to={
            'user__groups__name': 'window_cleaner'
        }
    )
    time_needed_alt = models.DurationField(
        null=True,
        default='00:00'
    )
    alternative_commission_default = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        null=True,
        blank=True,
        verbose_name='Alternative commission - regular job',
        validators=[
            MinValueValidator(Decimal('0.00')),
            MaxValueValidator(Decimal('100.00')),
        ]
    )
    alternative_commission_alt = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        null=True,
        blank=True,
        verbose_name='Alternative commission - alt job',
        validators=[
            MinValueValidator(Decimal('0.00')),
            MaxValueValidator(Decimal('100.00')),
        ]
    )
    is_commercial = models.BooleanField(default=False)
    commercial_list = models.ForeignKey(
        CommercialList,
        on_delete=models.PROTECT,
        null=True,
        blank=True
    )
    pi_to_price = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        null=True,
        blank=True,
        validators=[MinValueValidator(Decimal('0.00'))]
    )
    payment_info_default = models.TextField(blank=True)
    payment_info_alt = models.TextField(blank=True)

    payment_suppl_info_default = models.CharField(
        max_length=150, blank=True
        )
    payment_suppl_info_alt = models.CharField(
        max_length=150, blank=True
        )
    # used for dump of old db data:
    json_dump = models.TextField(blank=True)
    is_set_up_choice = models.IntegerField(
        choices=IS_SETUP_CHOICES,
        default=IS_SETUP_TO_BE_DONE,
        db_index=True
        )
    set_up_notes = models.CharField(
        max_length=150,
        blank=True
        )
    set_up_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        null=True,
        blank=True
        )
    
    customer_status = models.IntegerField(
        choices=CUSTOMER_STATUS_CHOICES,
        default=ENQUIRY,
        db_index=True
    )
    switch_off_review_links = models.BooleanField(default=False)
    email_validation_flag_set_by = models.ForeignKey(
        'accounts.user',
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name='email_validation_flag_set_by'
    )
    email_validation_flag_date = models.DateTimeField(auto_now=True, null=True)
    email_validation_customer_confirmed_spelling = models.BooleanField(default=False)
    email_validation_customer_confirmed_received_email = models.BooleanField(default=False)
    email_validation_received_customer_email = models.BooleanField(default=False)
    email_validation_warning = models.BooleanField(default=True)
    pi_changes_dict = models.TextField(blank=True)
    last_price_increase_edit_date = models.DateTimeField(blank=True, null=True)
    vat_flag = models.IntegerField(
        choices=VATFlags.choices,
        blank=False,
        default=VATFlags.NOT_ACTIONED
    )
    vat_price_reduced_from = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        null=True,
        blank=True,
        validators=[MinValueValidator(Decimal('0.00'))],
        verbose_name = "Price INCL. VAT Reduced from"
    )
    vat_price_reduced_to = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        null=True,
        blank=True,
        validators=[MinValueValidator(Decimal('0.00'))],
        verbose_name = "Price INCL. VAT Reduced to"
    )
    vat_frequency_changed_from = models.ForeignKey(
        FrequencyChoice,
        on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name='vat_frequency_changed_from',
        verbose_name = "Freq changed from"
    )
    vat_frequency_changed_to = models.ForeignKey(
        FrequencyChoice,
        on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name='vat_frequency_changed_to',
        verbose_name = "Freq changed to"
    )
    future_vat_flag = models.IntegerField(
        choices=FutureVATFlags.choices,        
        blank=True,  
        null=True,      
    )
    future_vat_notes = models.TextField(blank=True)
    base_price_default = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        null=True,
        validators=[MinValueValidator(Decimal('0.00'))]
    )
    base_price_alt = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        null=True,
        validators=[MinValueValidator(Decimal('0.00'))]
    )
    price_default_vat = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        null=True,
        validators=[MinValueValidator(Decimal('0.00'))]
    )
    price_alt_vat = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        null=True,
        validators=[MinValueValidator(Decimal('0.00'))]
    )
    vat_notes = models.TextField(blank=True)
    creation_franchise = models.ForeignKey(
        'franchises.Franchise',
        on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name='creation_franchise',
        verbose_name = "Created in franchise"
    )
    website_enquiry = models.BooleanField(default=False)
    created = models.DateTimeField(auto_now_add=True, null=True)
    website_enquiry_notes = models.TextField(blank=True)
    
    history = HistoricalRecords()

    @property
    def _history_user(self):
        return self.changed_by

    @_history_user.setter
    def _history_user(self, value):
        self.changed_by = value

    @property
    def full_name(self):
        seq = (self.title,
               self.first_name,
               self.last_name
               )
        return ' '.join(filter(None, seq))

    def __str__(self):
        str_ = (
            self.address_line_1,
            self.address_line_2,
            self.address_line_3,
            # self.post_town,
        )
        str_ = (', '.join(filter(None, str_)), self.postcode)
        return ' '.join(str_)

    def time_needed_default_HHhmm(self):
        try:
            sec = self.time_needed_default.total_seconds()
            return '%02dh%02d' % (int((sec/3600) % 3600), int((sec/60) % 60))
        except AttributeError:
            return '00h00'

    def time_needed_alt_HHhmm(self):
        try:
            sec = self.time_needed_alt.total_seconds()
            return '%02dh%02d' % (int((sec/3600) % 3600), int((sec/60) % 60))
        except AttributeError:
            return '00h00'

    def time_needed_default_HHAColhmm(self):
        try:
            sec = self.time_needed_default.total_seconds()
            return '%02d:%02d' % (int((sec/3600) % 3600), int((sec/60) % 60))
        except AttributeError:
            return '00:00'

    def time_needed_alt_HHAColhmm(self):
        try:
            sec = self.time_needed_alt.total_seconds()
            return '%02d:%02d' % (int((sec/3600) % 3600), int((sec/60) % 60))
        except AttributeError:
            return '00:00'

    def money_type_default_text(self):
        money_type_default_text = ''
        if self.money_type_default:
            money_type_default_text = str(self.money_type_default)
            if self.money_type_default.requires_bank_transfer_to:
                if self.bank_transfer_to_default:
                    money_type_default_text = money_type_default_text.replace(
                        'Bank transfer to WC',
                        'BT to '+str(self.bank_transfer_to_default.get_wc_initials())
                        )
            elif money_type_default_text == 'Bank transfer to MWC':
                money_type_default_text = 'BT to MWC'
            elif (self.bank_transfer_to_default and 
                self.money_type_default.money_type!='Hidden' 
                and self.money_type_default.money_type!='With'
                and self.money_type_default.money_type!='With your neighbour at number'
                ):
                money_type_default_text = money_type_default_text +' BT to '+str(self.bank_transfer_to_default.get_wc_initials())
            
            if self.payment_suppl_info_default:
                money_type_default_text += ' '+self.payment_suppl_info_default
            return money_type_default_text
        else:
            return money_type_default_text

    def money_type_alt_text(self):
        money_type_alt_text = ''
        if self.money_type_alt:
            money_type_alt_text = str(self.money_type_alt)
            if self.money_type_alt.requires_bank_transfer_to:
                if self.bank_transfer_to_alt:
                    money_type_alt_text = money_type_alt_text.replace(
                        'Bank transfer to WC',
                        'BT to '+str(self.bank_transfer_to_alt.get_wc_initials())
                        )
            elif money_type_alt_text == 'Bank transfer to MWC':
                money_type_alt_text = 'BT to MWC'
            elif (self.bank_transfer_to_alt and                      
                    self.money_type_alt.money_type!='Hidden' 
                    and self.money_type_alt.money_type!='With'
                    and self.money_type_alt.money_type!='With your neighbour at number'                    
                ):
                if self.bank_transfer_to_alt:
                    money_type_alt_text = money_type_alt_text +' BT to '+str(self.bank_transfer_to_alt.get_wc_initials()) 
                else:
                    money_type_alt_text = money_type_alt_text +' BT to ' + 'NOT SET'
            if self.payment_suppl_info_alt:
                money_type_alt_text += ' '+self.payment_suppl_info_alt
            return money_type_alt_text
        else:
            return money_type_alt_text
    
    def alternative_commission(self):        
        if self.alternative_commission_default is None:
            alternative_commission = mark_safe('<span class="text-primary">%-</span>')
        else:
            amount_with_leading_zero = "%s%s" % (intcomma(int(self.alternative_commission_default)), ("%0.2f" % self.alternative_commission_default)[-3:])
            amount_with_leading_zero = amount_with_leading_zero.rstrip('0').rstrip('.')
            alternative_commission = mark_safe('<span class="text-primary mr-1">%</span> <span class="text-body">'+str(amount_with_leading_zero)+'</span>')
        return alternative_commission

    def price_default_incl_vat(self):
        return (self.base_price_default or 0) + (self.price_default_vat or 0)
    
    def price_alt_incl_vat(self):
        return (self.base_price_alt or 0) + (self.price_alt_vat or 0)

    @property
    def address(self):
        str_ = (
            self.address_line_1,
            self.address_line_2,
            self.address_line_3,
            # self.post_town,
        )
        str_ = (', '.join(filter(None, str_)), self.postcode)
        return ' '.join(str_)

    class Meta:
        indexes = [
           models.Index(fields=['is_inactive']),
           models.Index(fields=['book_with']),
           models.Index(fields=['postcode']),
           models.Index(fields=['address_line_1']),
           models.Index(fields=['address_line_2']),
           models.Index(fields=['email']),
           models.Index(fields=['first_name']),
           models.Index(fields=['last_name']),
           models.Index(fields=['mobile_phone']),
           ]
        ordering = [
            'post_town',
            'thoroughfare',
            'building_number',
            'building_name',
            ]


class WCNewCustomer(models.Model):
    title = models.CharField(max_length=25, choices=TITLE_CHOICES, blank=True)
    first_name = models.CharField(max_length=50, blank=True)
    last_name = models.CharField(max_length=50, blank=True)
    business_source = models.ForeignKey(
        BusinessSource,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='+',)
    business_source_notes = models.CharField(
        max_length=500, blank=True
        )
    # 'Asked':
    business_source_window_cleaner = models.ForeignKey(
        'accounts.WindowCleaner',
        on_delete=models.PROTECT,
        null=True,
        blank=True,  # required for modelform to be required=false
        related_name='bus_source_wc+',
        limit_choices_to={
            'user__groups__name': 'window_cleaner'
        }
    )
    business_source_canvasser = models.ForeignKey(
        BusinessSourceCanvasser,
        null=True,
        blank=True,
        on_delete=models.PROTECT
    )
    business_source_internet = models.ForeignKey(
        BusinessSourceInternet,
        null=True,
        blank=True,
        on_delete=models.PROTECT
    )
    business_source_recommendation_customer = models.ForeignKey(
        'self',
        null=True,
        blank=True,
        on_delete=models.PROTECT
    )
    business_source_local_magazine = models.ForeignKey(
        BusinessSourceLocalMagazine,
        null=True,
        blank=True,
        on_delete=models.PROTECT
    )
    business_source_local_ad_board = models.ForeignKey(
        BusinessSourceLocalAdBoard,
        null=True,
        blank=True,
        on_delete=models.PROTECT
    )
    business_source_directory = models.ForeignKey(
        BusinessSourceDirectory,
        null=True,
        blank=True,
        on_delete=models.PROTECT
    )
    business_source_existing_customer = models.ForeignKey(
        'self',
        null=True,
        blank=True,
        on_delete=models.PROTECT,
        related_name='existing_customer'
    )
    customer_since = models.DateField(blank=True, null=True)
    told_terms_conditions = models.BooleanField(default=False)
    told_terms_conditions_date = models.DateField(null=True, blank=True)
    told_terms_conditions_notes = models.TextField(blank=True)
    stop_auto_bookings = models.BooleanField(default=False, db_index=True)
    auto_bookings = models.IntegerField(
        db_index=True,
        choices=AUTO_BOOKINGS_CHOICES,
        default=0
    )
    important_job_notes = models.TextField(blank=True)
    booking_info = models.TextField(blank=True)

    other_quotes = models.ManyToManyField(
        OtherQuotesTask,
        through='NewCustomerOtherQuote',
        )
    other_quotes_string = models.TextField(blank=True)
    other_quotes_notes = models.TextField(blank=True)
    customer_notes = models.TextField(blank=True)

    added_by = models.ForeignKey(settings.AUTH_USER_MODEL,
                                 on_delete=models.PROTECT,
                                 null=False,
                                 blank=False
                                 )
    # ADDRESS --------------------------------------------------------------
    building_number = models.CharField(
        max_length=16, blank=True, db_index=True
        )
    building_name = models.CharField(
        max_length=50, blank=True, db_index=True
        )
    sub_building_name = models.CharField(
        max_length=30, blank=True
        )
    thoroughfare = models.CharField(
        max_length=60, blank=True, db_index=True
        )
    address_line_1 = models.CharField(
        max_length=200,
        db_index=True,
        default=None,
        null=True
        )
    address_line_2 = models.CharField(
        max_length=200, blank=True, db_index=True
        )
    address_line_3 = models.CharField(
        max_length=200, blank=True, db_index=True
        )
    post_town = models.CharField(max_length=100, db_index=True, blank=True)
    county = models.CharField(max_length=100, blank=True)
    postcode = models.CharField(max_length=100, blank=True, db_index=True)
    organisation_name = models.CharField(max_length=100, blank=True)
    postcode_outward = models.CharField(
        max_length=100, blank=True, db_index=True
        )
    postcode_inward = models.CharField(
        max_length=100, blank=True, db_index=True
        )
    latitude = models.FloatField(
        blank=True,
        null=True)
    longitude = models.FloatField(
        blank=True,
        null=True)
    udprn = models.CharField(max_length=8, blank=True)

    booking_road = models.ForeignKey(
        'franchises.BookingRoad',
        on_delete=models.PROTECT,
        null=True,
        blank=True,
    )
    # COMMS -------------------------------------------------------------------
    home_phone = PhoneNumberField(
        max_length=20,
        blank=True,
        default=None,
        null=True
        )
    mobile_phone = PhoneNumberField(
        max_length=20,
        blank=True,
        default=None,
        null=True
        )
    work_phone = PhoneNumberField(blank=True, default=None, null=True)
    home_ansaphone = models.BooleanField(default=False)
    mob_ansaphone = models.BooleanField(default=False)
    phone_extension = models.TextField(blank=True)
    email = models.EmailField(
        blank=True,
        db_index=True,
        default=None,
        null=True
        )
    cc_email = models.EmailField(blank=True, db_index=True)
    no_email = models.BooleanField(default=False)
    book_with = models.ForeignKey(
        'BookWithChoice',
        blank=True,
        null=True,
        default=None,
        on_delete=models.PROTECT,
    )
    property_type = models.ForeignKey(
        'PropertyType',
        blank=True,
        null=True,
        on_delete=models.PROTECT,
    )
    #  JOBS -----------------------------------------------------------
    frequency = models.ForeignKey(
        FrequencyChoice,
        on_delete=models.PROTECT,
        blank=True,
        null=True
    )
    # new fields added for default job
    stop_paperless_bills = models.BooleanField(default=False, db_index=True)
    stop_chasers = models.BooleanField(default=False, db_index=True)
    is_inactive = models.BooleanField(default=False)
    is_inactive_reason = models.ForeignKey(
        'IsInactiveReason',
        null=True,
        blank=True,
        on_delete=models.PROTECT,
    )
    is_inactive_reason_notes = models.TextField(blank=True)
    date_inactive = models.DateField(blank=True, null=True)
    last_price = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        null=True,
        blank=True,
        validators=[MinValueValidator(Decimal('0.00'))]
    )
    last_price_increase_date = models.DateField(blank=True, null=True)
    last_price_increase_notes = models.TextField(blank=True)

    one_day_only = models.BooleanField(default=False)
    time_slots_notes = models.CharField(blank=True, max_length=200)
    payment_info = models.TextField(blank=True)

    # wc Bank transfer detail to customer management

    property_type_notes = models.TextField(blank=True)
    when_to_collect = models.DateField(null=True, blank=True)
    chased_notes = models.TextField(blank=True)
    contact_notes = models.TextField(blank=True)
    #  JOBS -----------------------------------------------------------

    cleaning_method_default = models.ForeignKey(
        'jobs.CleaningMethod',
        on_delete=models.PROTECT,
        null=True
    )
    job_cycle = models.IntegerField(blank=True, null=True)
    # blank=true necessary for required=false on forms
    # DEFAULT JOB --------------------------------------------------------
    job_task_default = models.ManyToManyField(
        'jobs.JobTask', related_name='wc_default_job_tasks'
        )
    job_task_default_note = models.CharField(
        max_length=70,
        blank=True
        )
    price_default = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        null=True,
        blank=True,
        validators=[MinValueValidator(Decimal('0.00'))]
    )
    access_type_default = models.ForeignKey(
        'jobs.AccessMethod',
        null=True,
        blank=True,
        related_name='+',
        on_delete=models.PROTECT
    )
    # access_notes = models.TextField(blank=True)

    # replaced by _default & _alt versions
    money_type_default = models.ForeignKey(
        'jobs.MoneyType',
        related_name='+',
        on_delete=models.PROTECT,
        null=True
    )
    bank_transfer_to_default = models.ForeignKey(
        'accounts.WindowCleaner',
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name='bt_to_default+',
        limit_choices_to={
            'user__groups__name': 'window_cleaner'
        }
    )
    # has it's own format fn below
    time_needed_default = models.DurationField(
        null=True,
        default='00:00'
    )
    use_alternate_job = models.BooleanField(default=False)
    # used for dump of old db data:
    json_dump = models.TextField(blank=True)
    history = HistoricalRecords()

    @property
    def full_name(self):
        seq = (self.title,
               self.first_name,
               self.last_name
               )
        return ' '.join(filter(None, seq))

    def __str__(self):
        str_ = (
            self.address_line_1,
            self.address_line_2,
            self.address_line_3,
            # self.post_town,
        )
        str_ = (', '.join(filter(None, str_)), self.postcode)
        return ' '.join(str_)

    @property
    def address(self):
        str_ = (
            self.address_line_1,
            self.address_line_2,
            self.address_line_3,
            self.post_town,
        )
        str_ = (', '.join(filter(None, str_)), self.postcode)
        return ' '.join(str_)

    class Meta:
        verbose_name_plural = "WC new customers"
        verbose_name = "WC new customer"


class CustomerNotesHistory(models.Model):
    customer = models.ForeignKey(
        Customer, on_delete=models.CASCADE)
    note = models.TextField(blank=True)
    added_by = models.ForeignKey(settings.AUTH_USER_MODEL,
                                 on_delete=models.PROTECT,
                                 null=False,
                                 blank=False,
                                 )
    created_at = models.DateTimeField(auto_now_add=True)


class WCDefaultTimeSlot(models.Model):
    customer = models.ForeignKey(
        'WCNewCustomer',
        on_delete=models.CASCADE,
        related_name='wc_time_slot_default'
    )
    day_of_week = models.CharField(
        blank=True,
        choices=DAYS_OF_WEEK,
        max_length=20,
        )
    start_time = models.TimeField(blank=True, null=True)
    end_time = models.TimeField(blank=True, null=True)
    notes = models.TextField(blank=True)
    NOT_flag = models.BooleanField(default=False)
    is_specific_appointment = models.BooleanField(default=False)

    def __str__(self):
        str = ''

        if self.NOT_flag is True:
            str += 'Not '

        if 'Any ' in self.day_of_week or 'Other ' in self.day_of_week:
            self.day_of_week = self.day_of_week.split()[0]
        else:
            self.day_of_week = self.day_of_week[:3]

        str += self.day_of_week

        if not self.end_time and self.start_time:
            start_time_format = self.start_time.strftime("%I:%M%p").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            str += ' aft. ' + start_time_format + ' '
        elif not self.start_time and self.end_time:
            end_time_format = self.end_time.strftime("%I:%M%p").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            str += ' bef. ' + end_time_format + ' '
        elif self.start_time and self.end_time:
            start_time_format = self.start_time.strftime("%I:%M%p").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            end_time_format = self.end_time.strftime("%I:%M%p").replace(
                ':00', '').lstrip("0").replace(" 0", " ")
            str += ' ' + start_time_format + \
                '-' + end_time_format + ' '
        elif not self.start_time and \
            not self.end_time and \
                not self.day_of_week == 'Contact customer':
            str += ' any'
        if self.notes:
            str += ' - ' + self.notes
        return str


class CustomerLatestJob(models.Model):
    """
        This is a non-managed model
        See for example here for what needs to be done:
        https://github.com/PhilippeGuyard/MWC/commit/c283e84
    """

    ENQUIRY = 1
    ACTIVE = 2
    INACTIVE = 3
    CUSTOMER_STATUS_CHOICES = (
        (ENQUIRY, 'Enquiry'),
        (ACTIVE, 'Active'),
        (INACTIVE, 'Inactive')
    )

    area = models.CharField(max_length=50)
    booking_road = models.CharField(max_length=150)
    name = models.CharField(max_length=150)
    home_phone = models.CharField(max_length=150)
    mobile_phone = models.CharField(max_length=150)
    customer_since = models.DateField()
    business_source = models.CharField(max_length=250)
    address = models.TextField()
    postcode = models.CharField(max_length=100)
    email = models.EmailField()
    job_status = models.CharField(max_length=50)
    due_date = models.DateField()
    allocated_date = models.DateField()
    property_type = models.CharField(max_length=255)
    frequency = models.CharField(max_length=20)
    price = models.DecimalField(
        max_digits=8,
        decimal_places=2,
    )
    vat_flag = models.IntegerField()
    money_type = models.CharField(max_length=50)
    bt_to = models.CharField(max_length=150)
    credit = models.DecimalField(
        max_digits=8,
        decimal_places=2,
    )
    stop_chasers = models.BooleanField()
    stop_paperless_bills = models.BooleanField()
    action_on_check_in = models.CharField(max_length=250)
    is_inactive = models.BooleanField()
    id = models.IntegerField(primary_key=True)
    tasks = models.TextField()
    franchise = models.IntegerField()
    building_number = models.CharField(max_length=16)
    building_name = models.CharField(max_length=50)
    thoroughfare = models.CharField(max_length=60)
    default_cleaner = models.CharField(max_length=181)
    # last_name 150 first_name 30 + ' '
    is_set_up_choice = models.IntegerField(
        choices=IS_SETUP_CHOICES,
        default=IS_SETUP_TO_BE_DONE
        )
    set_up_notes = models.CharField(
        max_length=150,
        )
    canvasser_id = models.IntegerField()
    important_job_notes = models.TextField()
    is_test_area = models.BooleanField(default=False)
    # Secondary Business Sources: return IDs
    bus_src_asked_user_id = models.IntegerField()
    bus_src_recom_cust_id = models.IntegerField()
    bus_src_exist_cust_id = models.IntegerField()
    bus_src_can_user_id = models.IntegerField()
    bus_src_internet_id = models.IntegerField()
    bus_src_loc_mag_id = models.IntegerField()
    bus_src_loc_brd_id = models.IntegerField()
    bus_src_lflet_id = models.IntegerField()
    bus_src_dir_id = models.IntegerField()
    bus_src_loc_fb = models.IntegerField()
    customer_status = models.IntegerField(
        choices=CUSTOMER_STATUS_CHOICES,
        default=ENQUIRY
    )
    booking_info = models.TextField()
    job_count = models.IntegerField()
    turnover = models.DecimalField( 
        max_digits=8,
        decimal_places=2,
    )
    book_with_abbreviation = models.CharField(max_length=4)
    access = models.CharField(max_length=50)
    primary_business_source = models.CharField(max_length=255)
    job_task_note = models.CharField(
        max_length=150,
        blank=True
        )
    access_notes = models.TextField(
        blank=True
        )
    payment_suppl_info = models.CharField(max_length=50, blank=True)
    told_terms_conditions = models.BooleanField(default=False)
    set_up_by = models.CharField(max_length=3)
    skipped_count = models.IntegerField()
    lost_turnover = models.DecimalField(
        max_digits=8,
        decimal_places=2,
    )
    has_alt_job = models.BooleanField()
    last_price_increase_date = models.DateField()
    price_incl_vat = models.DecimalField(
        max_digits=8,
        decimal_places=2,
    )
    date_inactive = models.DateField()
    bus_src_digital_magazine_id = models.IntegerField()
    bus_src_sponsorship_id = models.IntegerField()


    class Meta:
        managed = False
        db_table = 'customers_customerlatestjob'


def day_abbreviation(day_of_week):

    day_abbreviations = {}
    day_abbreviations['Monday'] = 'M'
    day_abbreviations['Tuesday'] = 'Tu'
    day_abbreviations['Wednesday'] = 'W'
    day_abbreviations['Thursday'] = 'Th'
    day_abbreviations['Friday'] = 'F'
    day_abbreviations['Saturday'] = 'Sa'
    day_abbreviations['Sunday'] = 'Su'
    day_abbreviations['Any day'] = 'Any'
    day_abbreviations['Other days'] = 'Oth'

    return day_abbreviations[day_of_week]


class ImportedOtherQuote(models.Model):
    job_task = models.ForeignKey(OtherQuotesTask, on_delete=models.CASCADE)
    customer = models.ForeignKey('ImportedCustomer', on_delete=models.CASCADE)    
    price = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        null=False,
        validators=[MinValueValidator(Decimal('0.00'))]
    )
    notes = models.TextField(blank=True)

    def __str__(self):
        task = self.job_task.job_task + ' - £' + str(self.price)
        if self.notes:
            task += ' (' + self.notes + ')'
        return task


class ImportedCustomer(models.Model):

    old_db_property_id = models.IntegerField(primary_key=True)

    # CUSTOMER DETAILS -------------------------------------------------
    title = models.CharField(max_length=25, choices=TITLE_CHOICES)
    first_name = models.CharField(max_length=50, db_index=True, blank=True)
    last_name = models.CharField(max_length=100, blank=True, db_index=True)
    business_source = models.ForeignKey(
        BusinessSource,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='+',)
    business_source_notes = models.CharField(
        max_length=500, blank=True
        )
    # 'Asked':
    business_source_window_cleaner = models.ForeignKey(
        'accounts.WindowCleaner',
        on_delete=models.CASCADE,
        null=True,
        blank=True,  # required for modelform to be required=false
        related_name='bus_source_wc+',
        limit_choices_to={
            'user__groups__name': 'window_cleaner'
        }
    )
    business_source_canvasser = models.ForeignKey(
        'accounts.Canvasser',
        on_delete=models.CASCADE,
        null=True,
        blank=True,  # required for modelform to be required=false
        related_name='canvasser+',
        limit_choices_to={
            'user__groups__name': 'canvasser'
        }
    )
    business_source_internet = models.ForeignKey(
        BusinessSourceInternet,
        null=True,
        blank=True,
        on_delete=models.CASCADE
    )
    business_source_recommendation_customer = models.ForeignKey(
        'self',
        null=True,
        blank=True,
        on_delete=models.CASCADE
    )
    business_source_local_magazine = models.ForeignKey(
        BusinessSourceLocalMagazine,
        null=True,
        blank=True,
        on_delete=models.CASCADE
    )
    business_source_local_ad_board = models.ForeignKey(
        BusinessSourceLocalAdBoard,
        null=True,
        blank=True,
        on_delete=models.CASCADE
    )
    business_source_directory = models.ForeignKey(
        BusinessSourceDirectory,
        null=True,
        blank=True,
        on_delete=models.CASCADE
    )
    business_source_existing_customer = models.ForeignKey(
        'self',
        null=True,
        blank=True,
        on_delete=models.CASCADE,
        related_name='existing_customer'
    )
    business_source_leaflet = models.ForeignKey(
        BusinessSourceLeaflet,
        null=True,
        blank=True,
        on_delete=models.CASCADE,
    )
    business_source_local_facebook = models.ForeignKey(
        BusinessSourceLocalFacebook,
        null=True,
        blank=True,
        on_delete=models.PROTECT,
    )
    customer_since = models.DateField(blank=True, null=True)
    told_terms_conditions = models.BooleanField(default=False)
    told_terms_conditions_date = models.DateField(null=True, blank=True)
    told_terms_conditions_notes = models.TextField(blank=True)
    stop_paperless_bills = models.BooleanField(default=False, db_index=True)
    stop_chasers = models.BooleanField(default=False, db_index=True)
    email_invoice = models.BooleanField(default=False, db_index=True)
    stop_auto_bookings = models.BooleanField(default=False, db_index=True)
    auto_bookings = models.IntegerField(
        db_index=True,
        choices=AUTO_BOOKINGS_CHOICES,
        default=0
    )
    is_inactive = models.BooleanField(default=False, db_index=True)
    is_inactive_reason = models.ForeignKey(
        'IsInactiveReason',
        null=True,
        blank=True,
        on_delete=models.CASCADE,
    )
    is_inactive_reason_notes = models.TextField(blank=True)
    date_inactive = models.DateField(blank=True, null=True)
    last_price = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        null=True,
        blank=True,
        validators=[MinValueValidator(Decimal('0.00'))]
    )
    last_price_increase_date = models.DateField(blank=True, null=True)
    last_price_increase_notes = models.TextField(blank=True)
    important_job_notes = models.TextField(blank=True)
    important_job_notes_alt = models.TextField(blank=True)
    booking_info = models.TextField(blank=True)
    no_sales_emails = models.BooleanField(default=False)
    one_day_only = models.BooleanField(default=False)
    one_day_only_alt = models.BooleanField(default=False)
    time_slots_notes = models.CharField(blank=True, max_length=200)
    payment_info = models.TextField(blank=True)
    other_quotes = models.ManyToManyField(
        OtherQuotesTask,
        through='ImportedOtherQuote',
        )
    other_quotes_string = models.TextField(blank=True)
    other_quotes_notes = models.TextField(blank=True)
    customer_notes = models.TextField(blank=True)
    credit = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        null=False,
        default=0.0,
    )
    # ADDRESS --------------------------------------------------------------
    # TODO: Building Number should be numeric
    # (sub_building_name contains 'flat','A' etc.)
    building_number = models.CharField(
        max_length=16, blank=True, db_index=True
        )
    building_name = models.CharField(
        max_length=50, blank=True, db_index=True
        )
    sub_building_name = models.CharField(
        max_length=30, blank=True
        )
    thoroughfare = models.CharField(
        max_length=60, blank=True, db_index=True
        )
    address_line_1 = models.CharField(max_length=200, db_index=True)
    address_line_2 = models.CharField(
        max_length=200, blank=True, db_index=True
        )
    address_line_3 = models.CharField(
        max_length=200, blank=True, db_index=True
        )
    post_town = models.CharField(max_length=100, db_index=True)
    county = models.CharField(max_length=100, blank=True)
    postcode = models.CharField(max_length=100, blank=True, db_index=True)
    organisation_name = models.CharField(max_length=100, blank=True)
    postcode_outward = models.CharField(
        max_length=100, blank=True, db_index=True
        )
    postcode_inward = models.CharField(
        max_length=100, blank=True, db_index=True
        )
    latitude = models.FloatField(
        blank=True,
        null=True)
    longitude = models.FloatField(
        blank=True,
        null=True)
    udprn = models.CharField(max_length=8, blank=True)

    booking_road = models.ForeignKey(
        'franchises.BookingRoad',
        on_delete=models.CASCADE,
        null=False,
    )
    # COMMS -------------------------------------------------------------------
    home_phone = PhoneNumberField(blank=True, db_index=True)
    additional_home_phone = models.TextField(blank=True, db_index=True)
    mobile_phone = PhoneNumberField(blank=True, db_index=True)
    additional_mobile_phone = models.TextField(blank=True, db_index=True)
    work_phone = PhoneNumberField(blank=True, db_index=True)
    additional_work_phone = models.TextField(blank=True, db_index=True)
    home_ansaphone = models.BooleanField(default=False)
    mob_ansaphone = models.BooleanField(default=False)
    phone_extension = models.TextField(blank=True)
    email = models.EmailField(blank=True, db_index=True)
    additional_email = models.TextField(blank=True, db_index=True)
    cc_email = models.EmailField(blank=True, db_index=True)
    no_email = models.BooleanField(default=False)
    book_with = models.ForeignKey(
        'BookWithChoice',
        null=True,
        on_delete=models.CASCADE,
    )
    property_type = models.ForeignKey(
        'PropertyType',
        blank=True,
        null=True,
        on_delete=models.CASCADE,
    )
    property_type_notes = models.TextField(blank=True)
    when_to_collect = models.DateField(null=True, blank=True)
    chased_notes = models.TextField(blank=True)
    contact_notes = models.TextField(blank=True)
    #  JOBS -----------------------------------------------------------
    frequency = models.ForeignKey(
        FrequencyChoice,
        on_delete=models.CASCADE,
        default=1
    )
    cleaning_method_default = models.ForeignKey(
        'jobs.CleaningMethod',
        on_delete=models.CASCADE,
        null=True
    )
    job_cycle = models.IntegerField(blank=True, null=True)
    # blank=true necessary for required=false on forms
    # DEFAULT JOB --------------------------------------------------------
    job_task_default = models.ManyToManyField(
        'jobs.JobTask',
        related_name='imported_default_job_tasks',
        blank=True,
        )
    job_task_default_note = models.CharField(
        max_length=70,
        blank=True,
        )
    price_default = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        null=True,
        validators=[MinValueValidator(Decimal('0.00'))]
    )
    access_type_default = models.ForeignKey(
        'jobs.AccessMethod',
        null=True,
        blank=True,
        related_name='+',
        on_delete=models.CASCADE
    )
    access_notes_default = models.TextField(
        blank=True
        )
    money_type_default = models.ForeignKey(
        'jobs.MoneyType',
        related_name='+',
        on_delete=models.CASCADE,
        null=True
    )
    bank_transfer_to_default = models.ForeignKey(
        'accounts.WindowCleaner',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='bt_to_default+',
        limit_choices_to={
            'user__groups__name': 'window_cleaner'
        }
    )
    # has it's own format fn below
    time_needed_default = models.DurationField(
        null=True,
        default='00:00'
    )
    # ALTERNATIVE JOB --------------------------------------------------------
    use_alternate_job = models.BooleanField(default=False)
    job_task_alt = models.ManyToManyField(
        'jobs.JobTask',
        blank=True,
        related_name='imported_alt_job_tasks'
        )
    job_task_alt_note = models.CharField(
        max_length=70,
        blank=True,
        )
    price_alt = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        null=True,
        blank=True,
        validators=[MinValueValidator(Decimal('0.00'))]
    )
    access_type_alt = models.ForeignKey(
        'jobs.AccessMethod',
        null=True,
        blank=True,
        related_name='access_type_alt+',
        on_delete=models.CASCADE
    )
    access_notes_alt = models.TextField(
        blank=True
        )
    money_type_alt = models.ForeignKey(
        'jobs.MoneyType',
        null=True,
        blank=True,
        related_name='+',
        on_delete=models.CASCADE
    )
    cleaning_method_alt = models.ForeignKey(
        'jobs.CleaningMethod',
        blank=True,
        null=True,
        related_name='cleaning_method_alt+',
        on_delete=models.CASCADE
    )
    money_type_note_default = models.TextField(blank=True)
    money_type_note_alt = models.TextField(blank=True)
    frequency_surcharge = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        null=True,
        blank=True,
        validators=[MinValueValidator(Decimal('0.00'))]
    )
    # has it's own format fn below
    bank_transfer_to_alt = models.ForeignKey(
        'accounts.WindowCleaner',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='bt_to_alt+',
        limit_choices_to={
            'user__groups__name': 'window_cleaner'
        }
    )
    time_needed_alt = models.DurationField(
        null=True,
        default='00:00'
    )
    alternative_commission_default = models.DecimalField(
        max_digits=5,
        decimal_places=3,
        null=True,
        blank=True,
        verbose_name='Alternative commission - regular job',
        validators=[
            MinValueValidator(Decimal('0.00')),
            MaxValueValidator(Decimal('100.00')),
        ]
    )
    alternative_commission_alt = models.DecimalField(
        max_digits=5,
        decimal_places=3,
        null=True,
        blank=True,
        verbose_name='Alternative commission - alt job',
        validators=[
            MinValueValidator(Decimal('0.00')),
            MaxValueValidator(Decimal('100.00')),
        ]
    )
    is_commercial = models.BooleanField(default=False)
    commercial_list = models.ForeignKey(
        CommercialList,
        on_delete=models.CASCADE,
        null=True,
        blank=True
    )
    pi_to_price = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        null=True,
        blank=True,
        validators=[MinValueValidator(Decimal('0.00'))]
    )
    payment_info_default = models.TextField(blank=True)
    payment_info_alt = models.TextField(blank=True)

    payment_suppl_info_default = models.CharField(
        max_length=50, blank=True
        )
    payment_suppl_info_alt = models.CharField(
        max_length=50, blank=True
        )
    # used for dump of old db data:
    json_dump = models.TextField(blank=True)
    is_set_up_choice = models.IntegerField(
        choices=IS_SETUP_CHOICES,
        default=IS_SETUP_TO_BE_DONE
        )
    set_up_notes = models.CharField(
        max_length=150,
        blank=True
        )
    set_up_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        null=True,
        blank=True
        )    
    customer_status = models.IntegerField(
        choices=CUSTOMER_STATUS_CHOICES,
        default=ENQUIRY
    )

    def __str__(self):
        str_ = (
            self.address_line_1,
            self.address_line_2,
            self.address_line_3,
            # self.post_town,
        )
        str_ = (', '.join(filter(None, str_)), self.postcode)
        return ' '.join(str_)


class CustomerReview(models.Model):
    customer = models.ForeignKey(
        'customers.Customer',
        null=True,
        on_delete=models.CASCADE,
        related_name='reviews'
    )
    review_id = models.IntegerField(blank=False, unique=True)
    name = models.CharField(max_length=255, blank=True)
    stars = models.IntegerField(blank=True)
    date_created = models.DateTimeField(null=True, blank=True)
    review = models.TextField(blank=True)
    email = models.EmailField(blank=True)
    
    class Meta:
        ordering = ['-date_created', ]

    def __str__(self):
        return "{0} {1}".format(self.stars, self.date_created) 


class CustomerWebsiteEnquiry(models.Model):
    date_created = models.DateTimeField(auto_now_add=True)
    session_key = models.CharField(max_length=255, blank=True)
    ip_address = models.CharField(max_length=255, blank=True)
    enquiry_data = models.JSONField(blank=True)
    customer = models.ForeignKey(
        Customer,
        null=True,
        on_delete=models.CASCADE,
    )
    last_modified = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-date_created', ]
        verbose_name_plural = "Website enquiries"
        verbose_name = "Website enquiry"

    def __str__(self):
        return "{0}".format(self.date_created)