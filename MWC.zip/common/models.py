# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.core.validators import MinValueValidator
from django.db import models
from django.utils.text import slugify
from ckeditor.fields import RichTextField
from taggit.managers import TaggableManager
from MWC_APP.widgets import ColorPickerWidget
from django.contrib.auth.models import Group

class EmailTemplate(models.Model):

    title = models.CharField(max_length=255, unique=True)
    step = models.ForeignKey(
        'jobs.WizardStep',
        on_delete=models.SET_NULL,
        null=True,
        blank=True
        )
    option = models.ForeignKey(
        'jobs.WizardOption', on_delete=models.SET_NULL,null=True,blank=True)
    subject = models.CharField(
        max_length=255,
        blank=True,
        null=True
        )
    email_template = RichTextField(default='')
    sms_template = models.TextField(default='', blank=True)
    job_office_notes = models.CharField(
        max_length=255,
        blank=True
        )

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = 'Check-in SMS & Email Template'
        verbose_name_plural = 'Check-in SMS & Email Templates'


class VideoLinkUserView(models.Model):
    user = models.ForeignKey(
        'accounts.User',
        on_delete=models.CASCADE
        )
    video_link = models.ForeignKey(
        'common.VideoLink',
        on_delete=models.CASCADE
        )
    views = models.IntegerField(
        null=False,
        default=0,
        validators=[MinValueValidator(0)]
        )


class ColorField(models.CharField):

    def __init__(self, *args, **kwargs):
        kwargs['max_length'] = 10
        super(ColorField, self).__init__(*args, **kwargs)

    def formfield(self, **kwargs):
        kwargs['widget'] = ColorPickerWidget
        return super(ColorField, self).formfield(**kwargs)


class VideoLinkCategory(models.Model):

    WHITE = '#FFFFFF'
    BLACK = '#000000'
    TEXT_COLOUR_CHOICES = (
        (WHITE, 'White'),
        (BLACK, 'Black'),        
    )
    category = models.CharField(
        max_length=255,
        blank=False
    )
    colour = ColorField(
        max_length=10,
        blank=False,
        default='#28A745'
        )
    text_colour = models.CharField(
        max_length=10,
        blank=False,
        default=BLACK,
        choices=TEXT_COLOUR_CHOICES
    )

    class Meta:
        verbose_name_plural = 'Video categories'
    
    def __str__(self):
        return self.category


class VideoPage(models.Model):
    page=models.CharField(max_length=128, unique=True)
    slug=models.CharField(max_length=255, unique=True)
    order=models.IntegerField(blank=True, null=True)
    franchisor_only = models.BooleanField(default=False)

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.page)
        return super().save(*args, **kwargs)

    def __str__(self):
        return self.page
    
    class Meta:
        ordering = [            
            "order",
            "page",
            ]

class VideoLink(models.Model):

    title = models.CharField(max_length=255)    
    video_page = models.ForeignKey(
        VideoPage,
        on_delete=models.CASCADE,
        blank=True,
        null=True
    )
    description = models.CharField(max_length=255, blank=True)
    link = models.URLField(blank=False)
    tags = TaggableManager(blank=True)
    order = models.IntegerField(null=True)
    user_views = models.ManyToManyField(
        'accounts.User',
        blank=True,
        through='VideoLinkUserView',
        # through_fields=('user', 'video_link'),        
    )
    categories = models.ManyToManyField(
        VideoLinkCategory,
        blank=True,
        related_name='categories'
        )

    def __str__(self):
        return self.title

    class Meta:
        ordering = [
            "video_page",
            "order"
            ]


class NetworkMessage(models.Model):
    title = models.CharField(max_length=50)
    message = models.TextField(blank=False)
    display_from = models.DateTimeField(db_index=True)
    display_until = models.DateTimeField(blank=True, null=True, db_index=True)
    user_groups = models.ManyToManyField(
        Group,
        blank=False,
    )
    aknowledged_users = models.ManyToManyField(
        'accounts.User',
        blank=True,                
    )

    def __str__(self):
        return "{0}: {1}...".format(self.display_from, self.message[:25]) if len(self.message) else "{0}: {1}".format(self.display_from, self.message)
