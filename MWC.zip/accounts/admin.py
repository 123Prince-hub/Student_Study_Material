# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.models import AbstractUser
from .models import (
    User, WindowCleaner, WCCommissionRate,
    Franchisee, Franchisor, LeafletDistributor, Canvasser,
    FranchiseAdmin, AvailabilityHours, CustomerCare
)
from franchises.models import Area
from django.utils.translation import ugettext_lazy as _
from django.contrib.auth.forms import UserCreationForm
from django import forms
from django.db.models import Q
from jobs.models import Job
import re


class UserAdminWithExtraFields(UserAdmin):

    def __init__(self, *args, **kwargs):
        super(UserAdminWithExtraFields, self).__init__(*args, **kwargs)

        abstract_fields = [field.name for field in AbstractUser._meta.fields]
        user_fields = [field.name for field in self.model._meta.fields]

        self.fieldsets += (
            (_('Extra fields'), {
                'fields': [
                    f for f in user_fields if (
                        f not in abstract_fields and
                        f != self.model._meta.pk.name
                    )
                ],
            }),
        )


class AvailabilityHoursInline(admin.TabularInline):
    model = AvailabilityHours
    insert_after = 'date_of_birth'
    extra = 7
    max_num = 7
    can_delete = False


def lower_error(password):
    
    """ Confirm that the password contains at least one
       lower case letter """

    return re.search(r"[a-z]", password)


def upcase_error(password):

    """ Confirm that the password contains at least one
       upper case character. """

    return re.search(r"[A-Z]", password)


def digit_error(password):

    """ Confirm that the password contains at least one
       digit. """

    return re.search(r"\d", password)


def symbol_error(password):

    """ Make sure that the password contains at least one
       of the following special characters: ! @ $ & """
    
    return re.search(r'[£!$%^&*\_\-={};:@#~+<>?,./\|`¬]', password)
    

class UserCreationForm(forms.ModelForm):

    password1 = forms.CharField(
        label='Password',
        widget=forms.PasswordInput(attrs={'autocomplete': 'nope'}),
    )
    password2 = forms.CharField(
        label='Password confirmation',
        widget=forms.PasswordInput(attrs={'autocomplete': 'nope'}),
        help_text='Enter the same password as before, for verification.'
    )

    TITLE_CHOICES = (
        ('', '--Select Title--'),
        ('Mr.', 'Mr.'),
        ('Ms.', 'Ms.'),
        ('Mrs.', 'Mrs.'),
        ('Miss', 'Miss'),
    )

    title = forms.ChoiceField(choices=TITLE_CHOICES, required=True)
    first_name = forms.CharField(required=True)
    last_name = forms.CharField(required=True)
    email = forms.EmailField(
        required=True,
        help_text='A valid email address, please.'
    )

    class Meta:
        model = User
        fields = '__all__'

    def clean_password1(self):
        # Check that the two password entries match
        password1 = self.cleaned_data.get("password1")

        if password1 and (
            lower_error(password1) is None or upcase_error(password1) is None
            ):
            raise forms.ValidationError('must contain a mix of uppercase and lowercase letters.')

        if password1 and (
            digit_error(password1) is None or symbol_error(password1) is None
            ):
            raise forms.ValidationError('must contain at least one digit and one symbol (@!£$% etc.).')

        if password1 and len(password1) < 8:
            raise forms.ValidationError('must contain at least 8 characters.')

        return password1

    def clean_password2(self):
        # Check that the two password entries match
        password1 = self.cleaned_data.get("password1")
        password2 = self.cleaned_data.get("password2")

        if password2 and (
            lower_error(password2) is None or upcase_error(password2) is None
                ):
            raise forms.ValidationError('must contain a mix of uppercase and lowercase letters.')

        if password2 and (
            digit_error(password2) is None or symbol_error(password2) is None
            ):
            raise forms.ValidationError('must contain at least one digit and one symbol (@!£$% etc.).')

        if password2 and len(password2) < 8:
            raise forms.ValidationError(
                'must contain at least 8 characters.'
                )

        elif password1 and password2 and password1 != password2:
            raise forms.ValidationError(
                "The two passwords do not match"
                )

        return password2

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data["password1"])
        if commit:
            user.save()
        return user


class UserChangeForm(forms.ModelForm):
    
    def clean_is_active(self):
        is_active = self.cleaned_data.get('is_active')
        instance = getattr(self, 'instance', None)
        if is_active is False:
            window_cleaner_object = WindowCleaner.objects.get(
                        user_id=instance.id)
            
            franchise_area = Area.objects.filter(
                default_cleaner=window_cleaner_object
            )

            job_query_set = Job.objects.select_related('job_status').filter(
                Q(job_status__job_status_description='Allocated') |
                Q(job_status__job_status_description='Booked') |
                (Q(job_status__job_is_done=True) & Q(manual_check_in=True)),
                window_cleaner=window_cleaner_object,
            )
            
            job_query_set_owes = Job.objects.filter(
                Q(owes__isnull=False) & Q(owes__gt=0) & ~Q(payment_status__payment_status_description='MWC owed'),
                window_cleaner=window_cleaner_object
            )

            if len(job_query_set) > 0:
                raise forms.ValidationError('Please check that this window cleaner has no allocated, booked or MCI jobs before setting to inactive')
            elif len(franchise_area) > 0:
                raise forms.ValidationError('This user is the default WC for some franchise areas. Please remove before setting to inactive')
            elif len(job_query_set_owes) > 0:
                raise forms.ValidationError("Cannot set this WC to 'inactive': there are still outstanding owes")

        return is_active

    def save(self, commit=True):
        user = super().save(commit=False)
        if commit:
            user.save()
        return user

from django.contrib import messages
from django.http import HttpResponseRedirect
class UserAdmin(UserAdmin):
    add_form = UserCreationForm
    # form = UserChangeForm
    model = User

    fieldsets = (
        (None, {'fields': ('username', 'password')}),
        (_('Personal info'), {'fields': (
            'title',
            'first_name',
            'middle_name',
            'last_name',
            'nickname',
            'email',
            'picture',
            'ansaphone',
            'home_phone',
            'mobile_phone',
            'date_of_birth',
            'notes'
            )
            }
        ),
        (_('Permissions & Important dates'), {'fields': ('is_active', 'is_staff', 'is_superuser',
                                                         'groups', 'user_permissions', 'last_login', 'date_joined','hide_training_videos')}),
        ('Bank Info', {
            'classes': ('wide',),
            'fields': (
                'bank_name', 'bank_account_holder_name', 'bank_account_sort_code', 'bank_account_number', 'bank_account_notes'
            )}
         ),
         ('Extra Info', {
            'classes': ('wide',),
            'fields': (
                'address_line_1', 'address_line_2', 'address_line_3', 'post_town', 'county', 'postcode',
                'cells_color_code', 'national_insurance_number', 'is_all_day_of_week', 'is_turnover_default_or_diary'
            )}
         ),
    )
    add_fieldsets = (
        ('Personal info', {
            'classes': ('wide',),
            'fields': (
                'username', 'password1', 'password2', 'title', 'first_name', 'middle_name', 'last_name', 'nickname',
                'email', 'picture', 'ansaphone', 'home_phone', 'mobile_phone', 'date_of_birth'
            )}
         ),
        ('Permissions & Important dates', {
            'classes': ('wide',),
            'fields': (
                'is_superuser', 'is_staff', 'is_active', 'groups', 'user_permissions', 'last_login', 'date_joined'
            )}
         ),
        ('Bank Info', {
            'classes': ('wide',),
            'fields': (
                'bank_name', 'bank_account_holder_name', 'bank_account_sort_code', 'bank_account_number', 'bank_account_notes'
            )}
         ),
        ('Extra Info', {
            'classes': ('wide',),
            'fields': (
                'address_line_1', 'address_line_2', 'address_line_3', 'post_town', 'county', 'postcode',
                'cells_color_code', 'national_insurance_number', 'is_all_day_of_week', 'is_turnover_default_or_diary'
            )}
         ),
    )
    inlines = [
        AvailabilityHoursInline
    ]

    ordering = ['last_name', 'first_name']

    def save_model(self, request, obj, form, change):
        if change:
            is_active = form.cleaned_data.get('is_active')
            window_cleaner_exist = WindowCleaner.objects.filter(
                                user_id=obj.id).exists()
            if is_active is False and window_cleaner_exist:
                user_groups = obj.groups.all().values_list('name', flat=True)
                window_cleaner_object = WindowCleaner.objects.get(
                            user_id=obj.id)
                franchise_area = Area.objects.filter(
                    default_cleaner=window_cleaner_object
                )
                job_query_set = Job.objects.select_related('job_status').filter(
                    Q(job_status__job_status_description='Allocated') |
                    Q(job_status__job_status_description='Booked') |
                    Q(job_status__job_is_done=True) & Q(manual_check_in=True),
                    window_cleaner=window_cleaner_object,
                )

                job_query_set_owes = Job.objects.filter(
                    Q(owes__isnull=False) & Q(owes__gt=0),
                    window_cleaner=window_cleaner_object,
                )

                if len(job_query_set) > 0:
                    raise forms.ValidationError('Please check that this window cleaner has no allocated, booked or owed jobs before setting to inactive')
                elif len(franchise_area) > 0:
                    raise forms.ValidationError('This user is the default WC for some franchise areas. Please remove before setting to inactive')
                elif len(job_query_set_owes) > 0:
                    raise forms.ValidationError("Cannot set this WC to 'inactive': there are still outstanding owes")
                
        super().save_model(request, obj, form, change)

    def change_view(self, request, object_id, form_url='', extra_context=None):
        try:
            return super(UserAdmin, self).change_view(request, object_id, form_url, extra_context)
        except Exception as err:
            messages.error(request, err)
            return HttpResponseRedirect(request.path)

    ''' def save_model(self, request, obj, form, change):
        if change:
            users_groups = form.cleaned_data.get("groups")
            for group_of_user in users_groups:
                print(str(group_of_user))
                if group_of_user == 'franchisor':
                    pass
                elif group_of_user == 'franchise_admin':
                    pass
                elif str(group_of_user) == 'franchisee':
                    print('Created Franchisee User')
                    franchisee_obj = Franchisee.objects.create(
                        user_id=obj.id,
                        franchise_id=4
                    )
                    franchisee_obj.save()
                elif group_of_user == 'canvasser':
                    pass
                elif group_of_user == 'leaflet_distributors':
                    pass

        super().save_model(request, obj, form, change) '''
    # exclude = ("groups", )



class FranchisorAdmin(admin.ModelAdmin):

    def get_readonly_fields(self, request, obj=None):
        if obj:  # This is the case when obj is already created i.e. it's an edit
            return ['user']
        else:
            return []
    
    ordering = ['user__first_name']

    list_select_related = ['user']

class CustomerCareAdmin(admin.ModelAdmin):
    
    def get_readonly_fields(self, request, obj=None):
        if obj:  # This is the case when obj is already created i.e. it's an edit
            return ['user']
        else:
            return []
    
    ordering = ['user__first_name']

    list_select_related = ['user']

class FranchiseeAdmin(admin.ModelAdmin):

    def get_readonly_fields(self, request, obj=None):
        if obj:  # This is the case when obj is already created i.e. it's an edit
            return ['user']
        else:
            return []
    
    ordering = ['user__first_name']

    list_select_related = ['user']


class WindowCleanerAdmin(admin.ModelAdmin):

    def get_readonly_fields(self, request, obj=None):
        if obj:  # This is the case when obj is already created i.e. it's an edit
            return ['user']
        else:
            return []
    search_fields = ('user__first_name', 'user__last_name')
    ordering = ['user__last_name']

    list_select_related = ['user']


class FranchiseAdminAdmin(admin.ModelAdmin):

    def get_readonly_fields(self, request, obj=None):
        if obj:  # This is the case when obj is already created i.e. it's an edit
            return ['user']
        else:
            return []
    
    ordering = ['user__first_name']

    list_select_related = ['user']


class LeafletDistributorAdmin(admin.ModelAdmin):

    def get_readonly_fields(self, request, obj=None):
        if obj:  # This is the case when obj is already created i.e. it's an edit
            return ['user']
        else:
            return []
    
    ordering = ['user__first_name']
    list_select_related = ['user']
    list_filter = ['franchise',]


class CanvasserAdmin(admin.ModelAdmin):

    def get_readonly_fields(self, request, obj=None):
        if obj:  # This is the case when obj is already created i.e. it's an edit
            return ['user']
        else:
            return []
    
    ordering = ['user__first_name']

    list_select_related = ['user']
    search_fields = ['user__first_name', 'user__last_name']
    list_filter = ['franchise',]


class WCCommissionRateAdmin(admin.ModelAdmin):
    list_select_related = ('window_cleaner__user',)
    ordering = ('window_cleaner__user', 'valid_from')
    list_display = ('window_cleaner', 'valid_from', 'commission_rate', 'vat_rate')    
    search_fields = ['window_cleaner__user__last_name', 'window_cleaner__user__first_name']
    autocomplete_fields = ['window_cleaner']


admin.site.register(User, UserAdmin)
admin.site.register(WindowCleaner, WindowCleanerAdmin)
admin.site.register(WCCommissionRate, WCCommissionRateAdmin)
admin.site.register(Franchisor, FranchisorAdmin)
admin.site.register(CustomerCare, CustomerCareAdmin)
admin.site.register(Franchisee, FranchiseeAdmin)
admin.site.register(LeafletDistributor, LeafletDistributorAdmin)
admin.site.register(Canvasser, CanvasserAdmin)
admin.site.register(FranchiseAdmin, FranchiseAdminAdmin)
