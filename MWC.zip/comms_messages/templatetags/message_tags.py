from comms_messages.models import (
    Message, ManualMessageTemplate, ManualMessageTemplateCategory
)
from django import template
from django.db.models.functions import Coalesce
from django.db.models import F
from common.utilities import get_user_franchise
from customers.models import Customer
from django.db.models import Q

register = template.Library()


@register.inclusion_tag('customer_messages_tag.html', takes_context=True)
# comms_messages/templates/customer_messages_tag.html
def list_customer_messages(context, customer, customer_email, customer_cc, customer_phone):
    messages = Message.objects.filter(
            customer=customer
            ).select_related(
                'email',
                'sms',
                'customer'
                ).annotate(
                order_time=Coalesce(F('sent_time'),
                                    F('received_time')
                                    )
                ).order_by('-order_time')[:5]
    return {'messages': messages,
            'customer': customer,
            'customer_email': customer_email,
            'customer_cc':customer_cc,
            'customer_phone': customer_phone,
            # pass the request object up the chain
            #  so compose_message can access it:
            'request': context.get('request'),
            }


@register.inclusion_tag('compose_message.html', takes_context=True)
def compose_message(context):
    user = context['request'].user
    franchise = get_user_franchise(user, context['request'])
    franchise = franchise
    type_of_email_lists = ManualMessageTemplate.TYPE_OF_EMAIL_CHOICES
    manual_msg_tpl_categories = ManualMessageTemplateCategory.objects.all().order_by('order')
    return {
        'franchise': franchise,
        'type_of_email_lists':type_of_email_lists,
        'manual_msg_tpl_categories':manual_msg_tpl_categories
    }

@register.inclusion_tag('compose_terms_condition.html', takes_context=True)
def compose_terms_conditions(context):
    user = context['request'].user
    franchise = get_user_franchise(user, context['request'])
    franchise = franchise    
    return {
        'franchise': franchise,        
    }


@register.filter('customer_list_same_email_phone')
def customer_list_same_email_phone(message_obj,email_or_phone):
    try:        
        if message_obj.message_type == 1:
            customer_list = Customer.objects.select_related(
                'booking_road__area__franchise'
            ).filter(
                Q(email=email_or_phone) |
                Q(cc_email=email_or_phone),
                Q(booking_road__area__franchise=message_obj.franchise),
                Q(booking_road__area__is_test_area=False)
            )
        else:
            customer_list = Customer.objects.select_related(
                'booking_road__area__franchise'
            ).filter(
                Q(mobile_phone=email_or_phone) |
                Q(home_phone=email_or_phone),
                Q(booking_road__area__franchise=message_obj.franchise),
                Q(booking_road__area__is_test_area=False)
            )
        list_of_customer = []
        for customer in customer_list:
            if message_obj.customer_id != customer.id:
                list_of_customer.append(customer.address)

        if len(list_of_customer) > 0:    
            return ', '.join(list_of_customer)
        else:
            return ''
    except Customer.DoesNotExist:
        return ''