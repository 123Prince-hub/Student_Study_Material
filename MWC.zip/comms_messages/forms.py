from django import forms
import json
from email_validator import validate_email, EmailNotValidError
import phonenumbers
from comms_messages.models import Contact, ManualMessageTemplate

from common.utilities import get_user_franchise


class SendMessageForm(forms.Form):
    email_JSON = forms.CharField(required=False)
    ccemail_JSON = forms.CharField(required=False)
    bccemail_JSON = forms.CharField(required=False)
    mobile_JSON = forms.CharField(required=False)
    subject = forms.CharField(required=False)
    message_email = forms.CharField(required=False)
    message_sms = forms.CharField(required=False)
    user_id = forms.IntegerField(required=False)
    customer_id = forms.IntegerField(required=False)
    message_type = forms.CharField(required=False)

    def clean(self):
        cleaned_data = super().clean()
        customer_id = cleaned_data.get("customer_id")
        user_id = cleaned_data.get("user_id")
        message_type = cleaned_data.get("message_type")
        email_JSON = json.loads(cleaned_data.get("email_JSON"))
        ccemail_JSON = json.loads(cleaned_data.get("ccemail_JSON"))
        bccemail_JSON = json.loads(cleaned_data.get("bccemail_JSON"))
        mobile_JSON = json.loads(cleaned_data.get("mobile_JSON"))

        if message_type == 'sms' and not bool(mobile_JSON):
            self.add_error(
                'mobile_JSON',
                'Please add a mobile number'
            )
# https://github.com/JoshData/python-email-validator
        if message_type == 'email':
            if not bool(email_JSON):
                self.add_error(
                    'email_JSON',
                    'Please add an email address'
                )
            else:
                for email in email_JSON:
                    try:
                        v = validate_email(email)
                    except EmailNotValidError as e:
                        self.add_error(
                            'email_JSON',
                            'Please enter a valid email address'
                        )
                for email in ccemail_JSON:
                    try:
                        v = validate_email(email)
                    except EmailNotValidError as e:
                        self.add_error(
                            'ccemail_JSON',
                            'Please enter a valid cc: email address'
                        )
                for email in bccemail_JSON:
                    try:
                        v = validate_email(email)
                    except EmailNotValidError as e:
                        self.add_error(
                            'bccemail_JSON',
                            'Please enter a valid bcc: email address'
                        )
        else:  # sms
            for number in mobile_JSON:
                try:
                    n = phonenumbers.parse(number, 'GB')
                    if not phonenumbers.is_valid_number(n):
                        self.add_error(
                            'mobile_JSON',
                            'Please enter a valid phone number'
                        )
                except phonenumbers.NumberParseException:
                    self.add_error(
                            'mobile_JSON',
                            'Please enter a valid phone number'
                        )


class ContactManagementForm(forms.ModelForm):

    opening_hours = forms.CharField(
        required=False, widget=forms.Textarea(attrs={'rows': 4, 'cols': 10})
        )
    notes = forms.CharField(
        required=False, widget=forms.Textarea(attrs={'rows': 4, 'cols': 10})
        )

    class Meta:
        model = Contact
        fields = [
            'title', 'first_name', 'last_name', 'contact_name',
            'home_phone', 'business_phone', 'extension',
            'mobile_phone', 'email',
            'relationship', 'address_line_1', 'address_line_2',
            'address_line_3', 'post_town',
            'county', 'postcode', 'opening_hours', 'picture', 'notes'
        ]

    def __init__(self, user, request, *args, **kwargs):
        # franchise = get_user_franchise(user, request)
        super(ContactManagementForm, self).__init__(*args, **kwargs)
        """ if franchise == None:
            self.fields['franchise'].required = False """


class ManualMessageForm(forms.ModelForm):
    class Meta:
        model = ManualMessageTemplate
        fields = [
            'message_type',
            'type_of_email',
            'title',
            'subject',
            'sms_template',
            'email_template',
            'checked',
        ]
